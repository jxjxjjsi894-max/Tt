#!/bin/bash

while true
do
    echo "Starting shulker..."

    {
        sleep 5
        echo "2"
        sleep 2
        echo "1"
        sleep 3600
    } | ./shulker

done
