const {
    Client,
    GatewayIntentBits,
    PermissionsBitField
} = require("discord.js");

const fs = require("fs");
const path = require("path");

/* =========================================================
   حط Bot Token هنا
   ========================================================= */

const TOKEN = "MTU0NzIzMTI0NTI0MTY4NDAwOQ.GY8gqE.opUlya-lbwN0UX9_7ch4crfpUVakI5pLLMoavs";

/* =========================================================
   CONFIG11
   ========================================================= */

const CONFIG_FILE = path.join(__dirname, "config11.json");

const DEFAULT_CONFIG = {
    prefix: "$",
    statusText: ".gg/zcop - Free Minecraft NFA Alts",
    roleId: "",
    guildId: ""
};

let config;

function loadConfig() {
    try {
        if (fs.existsSync(CONFIG_FILE)) {
            config = JSON.parse(
                fs.readFileSync(CONFIG_FILE, "utf8")
            );
        } else {
            config = { ...DEFAULT_CONFIG };

            fs.writeFileSync(
                CONFIG_FILE,
                JSON.stringify(config, null, 4)
            );
        }
    } catch (err) {
        console.log("❌ Error loading config11.json:", err.message);
        config = { ...DEFAULT_CONFIG };
    }
}

function saveConfig() {
    fs.writeFileSync(
        CONFIG_FILE,
        JSON.stringify(config, null, 4)
    );
}

loadConfig();

/* =========================================================
   DISCORD CLIENT
   ========================================================= */

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildPresences,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent
    ]
});

/* =========================================================
   STATUS CHECK
   ========================================================= */

function hasRequiredStatus(member) {

    if (!member.presence) {
        return false;
    }

    const required =
        String(config.statusText || "")
            .trim()
            .toLowerCase();

    if (!required) {
        return false;
    }

    const activities =
        member.presence.activities || [];

    for (const activity of activities) {

        // Custom Status
        if (activity.type !== 4) {
            continue;
        }

        const status =
            String(activity.state || "")
                .trim()
                .toLowerCase();

        if (status.includes(required)) {
            return true;
        }
    }

    return false;
}

/* =========================================================
   GIVE / REMOVE ROLE
   ========================================================= */

async function updateRole(member) {

    try {

        if (!member) return;
        if (member.user?.bot) return;

        if (!config.roleId) return;

        const role =
            member.guild.roles.cache.get(
                config.roleId
            );

        if (!role) return;

        const botMember =
            member.guild.members.me;

        if (!botMember) return;

        // رتبة البوت لازم تكون أعلى
        if (
            role.position >=
            botMember.roles.highest.position
        ) {
            return;
        }

        const shouldHave =
            hasRequiredStatus(member);

        const hasRole =
            member.roles.cache.has(role.id);

        /* -----------------------------------------
           GIVE
        ----------------------------------------- */

        if (shouldHave && !hasRole) {

            await member.roles.add(
                role,
                `Status matched: ${config.statusText}`
            );

            console.log(
                `✅ GIVE | ${member.user.tag}`
            );

            return;
        }

        /* -----------------------------------------
           REMOVE
        ----------------------------------------- */

        if (!shouldHave && hasRole) {

            await member.roles.remove(
                role,
                `Status removed: ${config.statusText}`
            );

            console.log(
                `❌ REMOVE | ${member.user.tag}`
            );
        }

    } catch (err) {

        console.log(
            `⚠️ Role error: ${err.message}`
        );
    }
}

/* =========================================================
   REAL-TIME STATUS MONITOR
   ========================================================= */

client.on(
    "presenceUpdate",
    async (oldPresence, newPresence) => {

        const member =
            newPresence?.member ||
            oldPresence?.member;

        if (!member) return;

        if (
            config.guildId &&
            member.guild.id !== config.guildId
        ) {
            return;
        }

        await updateRole(member);
    }
);

/* =========================================================
   COMMANDS
   ========================================================= */

client.on(
    "messageCreate",
    async message => {

        try {

            if (message.author.bot) return;
            if (!message.guild) return;

            if (
                !message.content.startsWith(
                    config.prefix
                )
            ) {
                return;
            }

            const args =
                message.content
                    .slice(config.prefix.length)
                    .trim()
                    .split(/\s+/);

            const command =
                args.shift()?.toLowerCase();

            /* =========================================
               $status
            ========================================= */

            if (command === "status") {

                if (
                    !message.member.permissions.has(
                        PermissionsBitField.Flags.ManageGuild
                    )
                ) {
                    return message.reply(
                        "❌ تحتاج صلاحية Manage Server."
                    );
                }

                const status =
                    args.join(" ").trim();

                if (!status) {

                    return message.reply(
                        `📌 الـStatus الحالي:\n\`${config.statusText}\``
                    );
                }

                config.statusText = status;
                config.guildId =
                    message.guild.id;

                saveConfig();

                await message.reply(
                    `✅ تم حفظ الـStatus:\n\`${status}\``
                );

                // إعادة فحص الأعضاء
                for (
                    const member
                    of message.guild.members.cache.values()
                ) {
                    await updateRole(member);
                }

                return;
            }

            /* =========================================
               $role
            ========================================= */

            if (command === "role") {

                if (
                    !message.member.permissions.has(
                        PermissionsBitField.Flags.ManageGuild
                    )
                ) {
                    return message.reply(
                        "❌ تحتاج صلاحية Manage Server."
                    );
                }

                const roleId = args[0];

                if (!roleId) {

                    return message.reply(
                        config.roleId
                            ? `🎖️ الرتبة الحالية: <@&${config.roleId}>`
                            : "❌ لا توجد رتبة محددة."
                    );
                }

                const role =
                    message.guild.roles.cache.get(
                        roleId
                    );

                if (!role) {

                    return message.reply(
                        "❌ لم أجد هذه الرتبة."
                    );
                }

                const botMember =
                    message.guild.members.me;

                if (
                    role.position >=
                    botMember.roles.highest.position
                ) {

                    return message.reply(
                        "❌ رتبة البوت يجب أن تكون أعلى من هذه الرتبة."
                    );
                }

                config.roleId = role.id;
                config.guildId =
                    message.guild.id;

                saveConfig();

                await message.reply(
                    `✅ تم حفظ الرتبة: ${role}`
                );

                // فحص فوري
                for (
                    const member
                    of message.guild.members.cache.values()
                ) {
                    await updateRole(member);
                }

                return;
            }

            /* =========================================
               $setup
            ========================================= */

            if (command === "setup") {

                if (
                    !message.member.permissions.has(
                        PermissionsBitField.Flags.ManageGuild
                    )
                ) {
                    return message.reply(
                        "❌ تحتاج صلاحية Manage Server."
                    );
                }

                return message.reply(
                    [
                        "⚙️ **Status Role System**",
                        "",
                        `📌 Status: \`${config.statusText}\``,
                        `🎖️ Role: ${
                            config.roleId
                                ? `<@&${config.roleId}>`
                                : "غير محددة"
                        }`,
                        `🏠 Server: ${
                            config.guildId ||
                            "غير محدد"
                        }`,
                        "",
                        "لتغيير الـStatus:",
                        "`$status النص`",
                        "",
                        "لتغيير الرتبة:",
                        "`$role ROLE_ID`"
                    ].join("\n")
                );
            }

        } catch (err) {

            console.log(
                "❌ Command error:",
                err.message
            );
        }
    }
);

/* =========================================================
   BOT READY
   ========================================================= */

client.once(
    "ready",
    async () => {

        console.log("");
        console.log(
            "===================================="
        );

        console.log(
            `🤖 Bot: ${client.user.tag}`
        );

        console.log(
            `📌 Status: ${config.statusText}`
        );

        console.log(
            `🎖️ Role: ${
                config.roleId || "Not Set"
            }`
        );

        console.log(
            `🏠 Guild: ${
                config.guildId || "Not Set"
            }`
        );

        console.log(
            "===================================="
        );

        console.log(
            "🚀 Status monitoring is active!"
        );

        /*
         * فحص أولي عند تشغيل البوت
         */

        for (
            const guild
            of client.guilds.cache.values()
        ) {

            if (
                config.guildId &&
                guild.id !== config.guildId
            ) {
                continue;
            }

            try {

                await guild.members.fetch();

                console.log(
                    `🔎 Checking ${guild.memberCount} members...`
                );

                for (
                    const member
                    of guild.members.cache.values()
                ) {
                    await updateRole(member);
                }

                console.log(
                    "✅ Initial check completed."
                );

            } catch (err) {

                console.log(
                    `❌ Startup error: ${err.message}`
                );
            }
        }
    }
);

/* =========================================================
   ERRORS
   ========================================================= */

client.on(
    "error",
    error => {
        console.log(
            "❌ Discord error:",
            error.message
        );
    }
);

process.on(
    "unhandledRejection",
    error => {
        console.log(
            "❌ Unhandled rejection:",
            error
        );
    }
);

/* =========================================================
   LOGIN
   ========================================================= */

if (
    TOKEN === "PUT_BOT_TOKEN_HERE" ||
    !TOKEN
) {

    console.log(
        "❌ ضع Bot Token الحقيقي في متغير TOKEN أعلى الملف."
    );

    process.exit(1);
}

client.login(TOKEN);
