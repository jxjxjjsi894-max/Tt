require("dotenv").config();

const {
  Client,
  GatewayIntentBits,
  PermissionsBitField
} = require("discord.js");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

client.once("ready", () => {
  console.log(`✅ Logged in as ${client.user.tag}`);
});

client.on("messageCreate", async (message) => {
  if (message.author.bot) return;

  if (message.content === "!deleteallinvites") {

    if (!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
      return message.reply("❌ تحتاج صلاحية Manage Server.");
    }

    try {
      const invites = await message.guild.invites.fetch();

      if (invites.size === 0) {
        return message.reply("ℹ️ لا توجد روابط دعوة لحذفها.");
      }

      let deleted = 0;
      let failed = 0;

      for (const invite of invites.values()) {
        try {
          await invite.delete("Deleted by invite cleaner bot");
          deleted++;
        } catch (err) {
          failed++;
          console.log(`❌ Failed: ${invite.code} | ${err.message}`);
        }
      }

      message.reply(
        `✅ تم حذف ${deleted} رابط دعوة.\n` +
        `⚠️ فشل حذف ${failed} رابط.`
      );

    } catch (err) {
      console.error(err);
      message.reply("❌ حدث خطأ أثناء جلب الدعوات.");
    }
  }
});

client.login(process.env.DISCORD_TOKEN);
