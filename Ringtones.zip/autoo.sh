#!/bin/sh

while true
do
    cp /home/admin/combos.txt 2
    cp /home/admin/combos.txt 3
    sleep 10
done
