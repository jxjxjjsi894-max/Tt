
import discord
from discord.ext import commands
from discord.ui import Button, View, Select
from discord import app_commands
import os
import json
import asyncio

# إعدادات البوت
TOKEN = 'MTUzMTcxODIyMzE3Nzg0NzA3Mw.GzTx1h.xW0Q2Kw6vOtDDDB8dKkmNIVmBfNMGWfTJVxXgE'
ADMIN_IDS = [1221156681283145800, 1072236052023349288, 1130516001495208046, 1462575612085538828]

# تعريف Intents
intents = discord.Intents.default()
intents.message_content = True
intents.members = True

# تعريف البوت
bot = commands.Bot(command_prefix="$", intents=intents)

# ملفات حفظ البيانات
TICKET_DATA_FILE = 'open_tickets.json'
CONFIG_FILE = 'config.json'
COUNTER_FILE = 'ticket_counter.json'
POINTS_FILE = 'staff_points.json'
XP_FILE = 'user_xp.json'

# متغيرات البيانات
open_tickets = {}
ticket_roles = []
ticket_counter = 0
staff_points = {}
user_xp = {}
claimed_tickets = set()

# دوال الحفظ والتحميل
def save_data():
    with open(TICKET_DATA_FILE, 'w') as f:
        json.dump(open_tickets, f)
    with open(CONFIG_FILE, 'w') as f:
        json.dump({"ticket_roles": ticket_roles}, f)
    with open(COUNTER_FILE, 'w') as f:
        json.dump({"counter": ticket_counter}, f)
    with open(POINTS_FILE, 'w') as f:
        json.dump(staff_points, f)
    with open(XP_FILE, 'w') as f:
        json.dump(user_xp, f)

def load_data():
    global open_tickets, ticket_roles, ticket_counter, staff_points, user_xp
    if os.path.exists(TICKET_DATA_FILE):
        try:
            with open(TICKET_DATA_FILE, 'r') as f:
                open_tickets = json.load(f)
        except: open_tickets = {}
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                ticket_roles = config.get("ticket_roles", [])
        except: ticket_roles = []
    if os.path.exists(COUNTER_FILE):
        try:
            with open(COUNTER_FILE, 'r') as f:
                data = json.load(f)
                ticket_counter = data.get("counter", 0)
        except: ticket_counter = 0
    if os.path.exists(POINTS_FILE):
        try:
            with open(POINTS_FILE, 'r') as f:
                staff_points = json.load(f)
        except: staff_points = {}
    if os.path.exists(XP_FILE):
        try:
            with open(XP_FILE, 'r') as f:
                user_xp = json.load(f)
        except: user_xp = {}

# مسار صورة البانر
BANNER_IMAGE_PATH = 'warden_ticket_banner.png'

# دوال التحقق
def is_admin_id(user_id):
    return user_id in ADMIN_IDS

def is_staff(member):
    if is_admin_id(member.id): return True
    user_roles = [role.id for role in member.roles]
    return any(role_id in ticket_roles for role_id in user_roles)

def is_admin_check():
    async def predicate(ctx):
        return is_admin_id(ctx.author.id)
    return commands.check(predicate)

def has_ticket_permission():
    async def predicate(ctx):
        return is_staff(ctx.author)
    return commands.check(predicate)

# كلاسات الـ View الدائمة (Persistent Views)
class MemberTicketView(View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.select(
        placeholder="اختر نوع التذكرة...",
        custom_id="member_ticket_select",
        options=[
            discord.SelectOption(label="تقديم إدارة", description="لتقديم طلب الانضمام لإدارة السيرفر", emoji="👑"),
            discord.SelectOption(label="الدعم الفني", description="لطلب المساعدة الفنية أو الإبلاغ عن مشكلة", emoji="🛠️"),
            discord.SelectOption(label="الشكوى على إداري", description="لتقديم شكوى ضد أحد أعضاء الإدارة", emoji="🚨"),
            discord.SelectOption(label="استلام هدايا", description="لاستلام الهدايا والمكافآت", emoji="🎁")
        ]
    )
    async def select_callback(self, interaction: discord.Interaction, select: Select):
        global ticket_counter
        user = interaction.user
        guild = interaction.guild
        if is_staff(user):
            await interaction.response.send_message("عذراً، هذه القائمة للأعضاء فقط.", ephemeral=True)
            return
        if str(user.id) in open_tickets:
            existing_channel = bot.get_channel(open_tickets[str(user.id)])
            if existing_channel:
                await interaction.response.send_message(f"لديك تذكرة مفتوحة بالفعل: {existing_channel.mention}", ephemeral=True)
                return
            else:
                del open_tickets[str(user.id)]
                save_data()
        category = discord.utils.get(guild.categories, name="Tickets")
        if not category:
            category = await guild.create_category("Tickets", overwrites={guild.default_role: discord.PermissionOverwrite(read_messages=False)})
        ticket_counter += 1
        ticket_channel_name = f"ticket-{ticket_counter:03d}"
        save_data()
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(read_messages=False),
            user: discord.PermissionOverwrite(read_messages=True, send_messages=True, attach_files=True),
            guild.me: discord.PermissionOverwrite(read_messages=True, send_messages=True)
        }
        for role_id in ticket_roles:
            role = guild.get_role(role_id)
            if role: overwrites[role] = discord.PermissionOverwrite(read_messages=True, send_messages=True, attach_files=True)
        ticket_channel = await guild.create_text_channel(ticket_channel_name, category=category, overwrites=overwrites)
        open_tickets[str(user.id)] = ticket_channel.id
        save_data()
        embed = discord.Embed(title=f"Warden Ticket - {select.values[0]}", description=f"مرحباً بك {user.mention} في تذكرتك الخاصة.", color=discord.Color.blue())
        claim_button = Button(label="استلام التذكرة", style=discord.ButtonStyle.success, custom_id=f"claim_{ticket_channel.id}")
        close_button = Button(label="إغلاق التذكرة", style=discord.ButtonStyle.danger, custom_id=f"close_{ticket_channel.id}")
        ticket_view = View()
        ticket_view.add_item(claim_button)
        ticket_view.add_item(close_button)
        if os.path.exists(BANNER_IMAGE_PATH):
            file = discord.File(BANNER_IMAGE_PATH, filename="warden_ticket_banner.png")
            embed.set_image(url="attachment://warden_ticket_banner.png")
            await ticket_channel.send(file=file, embed=embed, view=ticket_view)
        else: await ticket_channel.send(embed=embed, view=ticket_view)
        await interaction.response.send_message(f"تم إنشاء تذكرتك: {ticket_channel.mention}", ephemeral=True)

    @discord.ui.button(label="Refresh / إعادة تعيين", style=discord.ButtonStyle.secondary, custom_id="refresh_member_ticket")
    async def refresh_button(self, interaction: discord.Interaction, button: Button):
        await interaction.response.edit_message(view=self)

class StaffTicketView(View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.select(
        placeholder="اختر نوع الدعم (للإدارة فقط)...",
        custom_id="staff_ticket_select",
        options=[discord.SelectOption(label="دعم فني", description="طلب دعم فني خاص بطاقم العمل", emoji="🛠️")]
    )
    async def select_callback(self, interaction: discord.Interaction, select: Select):
        global ticket_counter
        user = interaction.user
        guild = interaction.guild
        if not is_staff(user):
            await interaction.response.send_message("عذراً، هذه القائمة لطاقم العمل فقط.", ephemeral=True)
            return
        if f"staff_{user.id}" in open_tickets:
            existing_channel = bot.get_channel(open_tickets[f"staff_{user.id}"])
            if existing_channel:
                await interaction.response.send_message(f"لديك تذكرة إدارة مفتوحة بالفعل: {existing_channel.mention}", ephemeral=True)
                return
            else:
                del open_tickets[f"staff_{user.id}"]
                save_data()
        category = discord.utils.get(guild.categories, name="Staff Tickets")
        if not category:
            category = await guild.create_category("Staff Tickets", overwrites={guild.default_role: discord.PermissionOverwrite(read_messages=False)})
        ticket_counter += 1
        ticket_channel_name = f"staff-ticket-{ticket_counter:03d}"
        save_data()
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(read_messages=False),
            user: discord.PermissionOverwrite(read_messages=True, send_messages=True, attach_files=True),
            guild.me: discord.PermissionOverwrite(read_messages=True, send_messages=True)
        }
        for admin_id in ADMIN_IDS:
            admin = guild.get_member(admin_id)
            if admin: overwrites[admin] = discord.PermissionOverwrite(read_messages=True, send_messages=True)
        ticket_channel = await guild.create_text_channel(ticket_channel_name, category=category, overwrites=overwrites)
        open_tickets[f"staff_{user.id}"] = ticket_channel.id
        save_data()
        embed = discord.Embed(title="Staff Support Ticket", description=f"مرحباً بك {user.mention} في تذكرة الإدارة.", color=discord.Color.orange())
        close_button = Button(label="إغلاق التذكرة", style=discord.ButtonStyle.danger, custom_id=f"close_{ticket_channel.id}")
        ticket_view = View()
        ticket_view.add_item(close_button)
        if os.path.exists(BANNER_IMAGE_PATH):
            file = discord.File(BANNER_IMAGE_PATH, filename="warden_ticket_banner.png")
            embed.set_image(url="attachment://warden_ticket_banner.png")
            await ticket_channel.send(file=file, embed=embed, view=ticket_view)
        else: await ticket_channel.send(embed=embed, view=ticket_view)
        await interaction.response.send_message(f"تم إنشاء تذكرة الإدارة: {ticket_channel.mention}", ephemeral=True)

    @discord.ui.button(label="Refresh / إعادة تعيين", style=discord.ButtonStyle.secondary, custom_id="refresh_staff_ticket")
    async def refresh_button(self, interaction: discord.Interaction, button: Button):
        await interaction.response.edit_message(view=self)

@bot.event
async def on_ready():
    load_data()
    # تسجيل الـ Views الدائمة لتعمل حتى بعد إعادة التشغيل
    bot.add_view(MemberTicketView())
    bot.add_view(StaffTicketView())
    try:
        await bot.tree.sync()
    except Exception as e: print(f"Sync error: {e}")
    print(f'Bot is ready! Logged in as {bot.user}')

@bot.event
async def on_message(message):
    if message.author.bot: return
    # نظام الـ XP للجميع (أعضاء وإدارة وأونرات)
    user_id = str(message.author.id)
    user_xp[user_id] = user_xp.get(user_id, 0) + 3
    if user_xp[user_id] % 30 == 0: save_data()
    await bot.process_commands(message)

# كلاس View للـ Leaderboard
class LeaderboardView(View):
    def __init__(self, data, title, unit="النقاط"):
        super().__init__(timeout=60)
        self.data = data
        self.title = title
        self.unit = unit
        self.page = 0
        self.max_pages = (len(data) - 1) // 10

    def create_embed(self):
        start = self.page * 10
        end = start + 10
        current_page_data = self.data[start:end]
        description = ""
        for i, (user_id, value) in enumerate(current_page_data, start=start + 1):
            description += f"{i}. <@{user_id}> - {self.unit}: **{value}**\n"
        if not description: description = "لا يوجد بيانات حالياً."
        embed = discord.Embed(title=f"📊 {self.title}", description=description, color=discord.Color.gold())
        embed.set_footer(text=f"الصفحة {self.page + 1} من {self.max_pages + 1}")
        return embed

    @discord.ui.button(label="⬅️", style=discord.ButtonStyle.primary)
    async def prev_button(self, interaction: discord.Interaction, button: Button):
        if self.page > 0:
            self.page -= 1
            await interaction.response.edit_message(embed=self.create_embed(), view=self)

    @discord.ui.button(label="➡️", style=discord.ButtonStyle.primary)
    async def next_button(self, interaction: discord.Interaction, button: Button):
        if self.page < self.max_pages:
            self.page += 1
            await interaction.response.edit_message(embed=self.create_embed(), view=self)

@bot.command(name="تفاعل")
async def leaderboard(ctx):
    sorted_xp = sorted(user_xp.items(), key=lambda x: x[1], reverse=True)
    view = LeaderboardView(sorted_xp, "تفاعل السيرفر العام (XP)", unit="XP")
    await ctx.send(embed=view.create_embed(), view=view)

@bot.command(name="تفاعل_اداره")
@has_ticket_permission()
async def staff_leaderboard(ctx):
    sorted_points = sorted(staff_points.items(), key=lambda x: x[1], reverse=True)
    view = LeaderboardView(sorted_points, "تفاعل الإدارة (تذاكر)", unit="النقاط")
    await ctx.send(embed=view.create_embed(), view=view)

@bot.command()
@is_admin_check()
async def setup_ticket(ctx):
    embed = discord.Embed(title="Warden Ticket System", description="اختر نوع التذكرة لفتحها.", color=discord.Color.dark_blue())
    if os.path.exists(BANNER_IMAGE_PATH):
        file = discord.File(BANNER_IMAGE_PATH, filename="warden_ticket_banner.png")
        embed.set_image(url="attachment://warden_ticket_banner.png")
        await ctx.send(file=file, embed=embed, view=MemberTicketView())
    else: await ctx.send(embed=embed, view=MemberTicketView())
    await ctx.message.delete()

@bot.command()
@is_admin_check()
async def setup_staff(ctx):
    embed = discord.Embed(title="Staff Ticket System", description="هذه القائمة لطاقم العمل فقط.", color=discord.Color.orange())
    if os.path.exists(BANNER_IMAGE_PATH):
        file = discord.File(BANNER_IMAGE_PATH, filename="warden_ticket_banner.png")
        embed.set_image(url="attachment://warden_ticket_banner.png")
        await ctx.send(file=file, embed=embed, view=StaffTicketView())
    else: await ctx.send(embed=embed, view=StaffTicketView())
    await ctx.message.delete()

async def delayed_delete(channel):
    await channel.send("⚠️ سيتم حذف التذكرة نهائياً خلال **5 ثوانٍ**...")
    await asyncio.sleep(5)
    await channel.delete()

@bot.command()
@has_ticket_permission()
async def close(ctx, channel: discord.TextChannel = None):
    channel = channel or ctx.channel
    if "ticket-" in channel.name:
        for uid, cid in list(open_tickets.items()):
            if cid == channel.id:
                del open_tickets[uid]
                save_data()
                break
        await delayed_delete(channel)
    else: await ctx.send("هذه ليست قناة تذكرة.")

@bot.command()
@has_ticket_permission()
async def delete(ctx, channel: discord.TextChannel = None):
    await close(ctx, channel)

@bot.command(name="نقاطي")
async def my_points(ctx):
    points = staff_points.get(str(ctx.author.id), 0)
    xp = user_xp.get(str(ctx.author.id), 0)
    await ctx.send(f"نقاط التذاكر: **{points}** | الـ XP الخاص بك: **{xp}**")

@bot.command()
async def come(ctx, member: discord.Member = None):
    if not member: return
    try:
        await member.send(f"لقد تم استدعاؤك في قناة: {ctx.channel.mention}")
        await ctx.send(f"تم استدعاء {member.mention} بالخاص.")
    except: await ctx.send("تعذر الإرسال بالخاص.")

@bot.event
async def on_interaction(interaction):
    if interaction.type == discord.InteractionType.component:
        custom_id = interaction.data.get('custom_id')
        user = interaction.user
        if custom_id and custom_id.startswith('claim_'):
            ticket_id = custom_id.split('_')[1]
            if not is_staff(user):
                await interaction.response.send_message("طاقم العمل فقط يمكنه الاستلام.", ephemeral=True)
                return
            if ticket_id in claimed_tickets:
                await interaction.response.send_message("تم استلامها بالفعل.", ephemeral=True)
                return
            claimed_tickets.add(ticket_id)
            staff_id = str(user.id)
            staff_points[staff_id] = staff_points.get(staff_id, 0) + 1
            save_data()
            channel = interaction.channel
            for role_id in ticket_roles:
                role = interaction.guild.get_role(role_id)
                if role: await channel.set_permissions(role, read_messages=True, send_messages=False)
            await channel.set_permissions(user, read_messages=True, send_messages=True)
            await interaction.response.send_message(f"تم استلام التذكرة من قبل الإداري: {user.mention}")
            view = View.from_message(interaction.message)
            for item in view.children:
                if item.custom_id == custom_id: item.disabled = True
            await interaction.message.edit(view=view)
        elif custom_id and custom_id.startswith('close_'):
            if not is_staff(user): return
            channel = interaction.channel
            for uid, cid in list(open_tickets.items()):
                if cid == channel.id:
                    del open_tickets[uid]
                    save_data()
                    break
            await interaction.response.send_message("جاري الإغلاق...")
            await delayed_delete(channel)
    await bot.process_commands(interaction)

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound): pass
    else: print(error)

bot.run(TOKEN)
