const mineflayer = require('mineflayer');
const { pathfinder, Movements, goals } = require('mineflayer-pathfinder');

// =========================
// إعدادات البوت
// =========================
const botConfig = {
    host: 'sadmc.top',
    port: 25565,
    username: 'Mohammed998',

    // Minecraft Java 26.1.2
    version: '26.1.2'
};

const bot = mineflayer.createBot(botConfig);

bot.loadPlugin(pathfinder);

let followingPlayer = null;
let followInterval = null;

// =========================
// عند دخول البوت
// =========================
bot.once('spawn', () => {
    console.log('==============================');
    console.log('تم تسجيل دخول البوت بنجاح');
    console.log(`Username: ${bot.username}`);
    console.log(`Version: ${bot.version || 'unknown'}`);
    console.log('==============================');

    // تسجيل الدخول تلقائياً
    setTimeout(() => {
        bot.chat('/login mohammed');
        console.log('تم إرسال /login');
    }, 1000);

    const defaultMove = new Movements(bot);
    bot.pathfinder.setMovements(defaultMove);
});

// =========================
// مراقبة فتح GUI
// =========================
bot.on('windowOpen', (window) => {
    try {
        console.log('==============================');
        console.log('GUI OPENED');
        console.log('Type:', window.type);
        console.log('Title:', window.title);
        console.log('Total slots:', window.slots.length);
        console.log(
            'Container items:',
            window.containerItems().length
        );
        console.log('==============================');
    } catch (err) {
        console.log(
            'GUI information error:',
            err.message
        );
    }
});

// =========================
// مراقبة إغلاق GUI
// =========================
bot.on('windowClose', (window) => {
    try {
        console.log(
            'GUI CLOSED:',
            window.title
        );
    } catch (err) {
        console.log('GUI CLOSED');
    }
});

// =========================
// أوامر الشات
// =========================
bot.on('chat', async (username, message) => {

    // تجاهل رسائل البوت
    if (username === bot.username) return;

    const args = message
        .trim()
        .split(/\s+/);

    const command = args[0].toLowerCase();

    // =========================
    // !follow
    // =========================
    if (command === '!follow') {

        const targetName = args[1] || username;

        const target =
            bot.players[targetName]
                ? bot.players[targetName].entity
                : null;

        if (!target) {
            console.log(
                `اللاعب ${targetName} غير موجود أو خارج النطاق.`
            );
            return;
        }

        followingPlayer = target;

        const movements = new Movements(bot);
        bot.pathfinder.setMovements(movements);

        // إيقاف متابعة قديمة
        if (followInterval) {
            clearInterval(followInterval);
        }

        const followLoop = () => {

            if (!followingPlayer) return;

            const goal =
                new goals.GoalFollow(
                    followingPlayer,
                    2
                );

            bot.pathfinder.setGoal(
                goal,
                true
            );
        };

        followLoop();

        followInterval = setInterval(() => {

            if (!followingPlayer) {

                clearInterval(
                    followInterval
                );

                followInterval = null;

                return;
            }

            followLoop();

        }, 1000);

        console.log(
            `بدأت متابعة ${targetName}`
        );
    }

    // =========================
    // !unfollow
    // =========================
    else if (command === '!unfollow') {

        followingPlayer = null;

        if (followInterval) {

            clearInterval(
                followInterval
            );

            followInterval = null;
        }

        bot.pathfinder.setGoal(null);

        console.log(
            'تم إيقاف المتابعة'
        );
    }

    // =========================
    // !do
    // مثال:
    // !do /team echest
    // =========================
    else if (command === '!do') {

        const fullCommand =
            args.slice(1).join(' ');

        if (fullCommand) {

            console.log(
                `تنفيذ: ${fullCommand}`
            );

            bot.chat(fullCommand);
        }
    }

    // =========================
    // !dropallitems
    // =========================
    else if (command === '!dropallitems') {

        console.log(
            'تم استقبال !dropallitems'
        );

        console.log(
            'سيبدأ الرمي بعد 10 ثواني...'
        );

        setTimeout(async () => {

            console.log(
                'بدأت عملية الرمي...'
            );

            // =========================
            // GUI
            // =========================
            if (bot.currentWindow) {

                console.log(
                    'يوجد GUI مفتوح.'
                );

                try {

                    let safetyCounter = 0;

                    while (
                        bot.currentWindow &&
                        safetyCounter < 200
                    ) {

                        safetyCounter++;

                        const window =
                            bot.currentWindow;

                        const items =
                            window.containerItems();

                        console.log(
                            `GUI items: ${items.length}`
                        );

                        if (items.length === 0) {

                            console.log(
                                'الـGUI فارغ.'
                            );

                            break;
                        }

                        const item = items[0];

                        console.log(
                            `Item: ${item.name} x${item.count}`
                        );

                        console.log(
                            `Slot: ${item.slot}`
                        );

                        try {

                            // أخذ الـstack
                            await bot.clickWindow(
                                item.slot,
                                0,
                                0
                            );

                            await new Promise(
                                resolve =>
                                    setTimeout(
                                        resolve,
                                        200
                                    )
                            );

                            // رميه خارج الـGUI
                            await bot.clickWindow(
                                -999,
                                0,
                                0
                            );

                            await new Promise(
                                resolve =>
                                    setTimeout(
                                        resolve,
                                        200
                                    )
                            );

                        } catch (err) {

                            console.log(
                                'فشل رمي item من GUI:',
                                err.message
                            );

                            break;
                        }
                    }

                } catch (err) {

                    console.log(
                        'GUI error:',
                        err.message
                    );
                }

            } else {

                console.log(
                    'لا يوجد GUI مفتوح.'
                );
            }

            // =========================
            // Inventory
            // =========================
            console.log(
                'بدأ تفريغ Inventory...'
            );

            try {

                const inventoryItems =
                    [...bot.inventory.items()];

                for (
                    const item
                    of inventoryItems
                ) {

                    try {

                        console.log(
                            `رمي ${item.name} x${item.count}`
                        );

                        await bot.tossStack(
                            item
                        );

                        await new Promise(
                            resolve =>
                                setTimeout(
                                    resolve,
                                    100
                                )
                        );

                    } catch (err) {

                        console.log(
                            `فشل رمي ${item.name}:`,
                            err.message
                        );
                    }
                }

            } catch (err) {

                console.log(
                    'Inventory error:',
                    err.message
                );
            }

            console.log(
                'انتهى !dropallitems'
            );

        }, 10000);
    }

    // =========================
    // !attack
    // =========================
    else if (command === '!attack') {

        const entity =
            bot.nearestEntity(
                e =>
                    e.type === 'player' ||
                    e.type === 'mob'
            );

        if (entity) {

            console.log(
                `Attack: ${
                    entity.name ||
                    entity.type
                }`
            );

            bot.attack(entity);
        }
    }

    // =========================
    // !click
    // =========================
    else if (command === '!click') {

        if (bot.currentWindow) {

            try {

                console.log(
                    'Clicking GUI slot 0'
                );

                await bot.clickWindow(
                    0,
                    0,
                    0
                );

            } catch (err) {

                console.log(
                    'Click error:',
                    err.message
                );
            }

        } else {

            try {

                const block =
                    bot.blockAtCursor(4);

                if (block) {

                    console.log(
                        `Activating: ${block.name}`
                    );

                    await bot.activateBlock(
                        block
                    );
                }

            } catch (err) {

                console.log(
                    'Block activation error:',
                    err.message
                );
            }
        }
    }
});

// =========================
// Error
// =========================
bot.on('error', (err) => {

    console.log(
        'BOT ERROR:',
        err
    );
});

// =========================
// Disconnect
// =========================
bot.on('end', () => {

    console.log(
        'انقطع الاتصال بالسيرفر.'
    );

    console.log(
        'إعادة التشغيل بعد 5 ثواني...'
    );

    setTimeout(() => {
        process.exit(1);
    }, 5000);
});
