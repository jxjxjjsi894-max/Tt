const { Client, GatewayIntentBits, EmbedBuilder } = require('discord.js');
const util=require('minecraft-server-util');
const TOKEN='MTUyODg5ODQ2ODU3ODU5MDgyMA.GhT9qy.ZEBhSQT5Hp_qTP37JM8QwqKR8ZDtdaWCm_Ruec';
const VERSION = '1.8-1.26';
const client=new Client({intents:[GatewayIntentBits.Guilds,GatewayIntentBits.GuildMessages,GatewayIntentBits.MessageContent]});
const SERVER={host:'16.170.173.228',port:25565};
client.on('messageCreate',async m=>{
 if(m.author.bot||m.content.toLowerCase()!=='ip')return;
 try{
 const s=await util.status(SERVER.host,SERVER.port);
 const e=new EmbedBuilder().setColor(0x22c55e).setTitle('🛡️ Warden Network').setDescription(`╔════════════════════╗
        🛡️ Warden Network
╚════════════════════╝

🟢 **Status**
> Online

👥 **Players**
> ${s.players.online} / ${s.players.max}

🏓 **Ping**
> ${s.roundTripLatency??'N/A'} ms

📦 **Version**
> ${VERSION}

🌐 **IP**
> ${SERVER.host}

🔌 **Port**
> ${SERVER.port}

────────────────────
✨ Powered by Warden Network`);
 if(s.favicon)e.setThumbnail(s.favicon);
 m.reply({embeds:[e]});
 }catch{
 m.reply({embeds:[new EmbedBuilder().setColor(0xef4444).setTitle('🛡️ Warden Network').setDescription('🔴 Server Offline')]});
 }
});
client.login(TOKEN);
