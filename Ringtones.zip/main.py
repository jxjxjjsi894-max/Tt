"""
Main entry point for running PRIMEX CHECKER GUI
"""
import sys
import os

# Ensure current directory is on python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import prime_Core
import prime_GUI

if __name__ == '__main__':
    print("==================================================")
    print("  PRIMEX CHECKER GUI")
    print("  leaked by NXTPLAYZYT BADDIE LOVER, ITS_LIGHT AND BABATOTAKA :>")
    print("==================================================")
    prime_GUI.launch_gui(prime_Core)
