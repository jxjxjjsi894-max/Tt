import {
  Client,
  GatewayIntentBits,
  PermissionFlagsBits,
  Partials,
} from 'discord.js';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');
const LOG_DIR = path.join(ROOT, 'logs');
// ضع توكن البوت بين علامتي الاقتباس في السطر التالي فقط.
// لا تشارك هذا الملف بعد إضافة التوكن ولا ترفعه إلى GitHub.
const TOKEN = 'MTU0NTc4MzMxNTE0NTk1MzMwMA.G2wteh.AcgKXFDCwCVxf96PUqWe7t5Fh_cI63ilGms6kE';
const GUILD_ID = '1524391697625382942';
const OWNER_IDS = new Set([
  '1462575612085538828',
  '1130516001495208046',
]);
const PREFIX = '$';
const INCLUDE_IDLE_DND = true;
const MAX_RECIPIENTS = 0;
// سقف زمني أقصى 5 محاولات تقريبًا في الثانية.
// عند ظهور 429 يتوقف تلقائيًا ويحترم Retry-After بدل تجاوز حدود Discord.
const DM_DELAY_MS = 200;
const MAX_RETRIES = 3;

if (!TOKEN || TOKEN === 'ضع_توكن_البوت_هنا' || !GUILD_ID || OWNER_IDS.size === 0) {
  console.error('ضع توكن البوت داخل ثابت TOKEN في src/index.js قبل التشغيل.');
  process.exit(1);
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
  partials: [Partials.Channel, Partials.GuildMember, Partials.User],
});

const activeCampaigns = new Map();

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function parsePositiveInt(value, fallback) {
  const n = Number(value);
  return Number.isInteger(n) && n > 0 ? n : fallback;
}

function isTemporaryError(error) {
  return error?.status === 429 || [500, 502, 503, 504].includes(error?.status);
}

function errorReason(error) {
  if (error?.code === 50007) return 'العضو أغلق الرسائل الخاصة';
  if (error?.code === 10007 || error?.code === 10013) return 'العضو غير متاح';
  if (error?.status === 429) return 'حد معدل Discord';
  return error?.message || 'خطأ غير معروف';
}

async function appendLog(campaign) {
  await fs.mkdir(LOG_DIR, { recursive: true });
  const file = path.join(LOG_DIR, `${new Date().toISOString().slice(0, 10)}.jsonl`);
  await fs.appendFile(file, `${JSON.stringify({
    id: campaign.id,
    guildId: campaign.guildId,
    type: campaign.type,
    authorId: campaign.authorId,
    text: campaign.text,
    startedAt: campaign.startedAt,
    finishedAt: campaign.finishedAt,
    target: campaign.target,
    sent: campaign.sent,
    failed: campaign.failed,
    stopped: campaign.stopped,
    failures: campaign.failures,
  })}\n`);
}

function canBroadcast(message) {
  return OWNER_IDS.has(message.author.id) || message.member?.permissions.has(PermissionFlagsBits.ManageGuild);
}

function presenceMatches(member, includeIdleDnd) {
  const status = member.presence?.status;
  if (status === 'online') return true;
  return includeIdleDnd && (status === 'idle' || status === 'dnd');
}

function progressText(campaign, final = false) {
  const processed = campaign.sent + campaign.failed;
  const percent = campaign.target === 0 ? 100 : Math.floor((processed / campaign.target) * 100);
  const remaining = Math.max(0, campaign.target - processed);
  const status = final
    ? (campaign.stopped ? 'تم الإيقاف' : 'اكتملت الحملة')
    : 'جاري الإرسال';
  const elapsed = Math.floor((Date.now() - campaign.startedAtMs) / 1000);
  return [
    `**${status}**`,
    `النوع: \`${campaign.type}\``,
    `تم الإرسال بنجاح: **${campaign.sent} / ${campaign.target}**`,
    `فشل: **${campaign.failed}** | متبقٍ: **${remaining}** | التقدم: **${percent}%**`,
    `الوقت المنقضي: **${elapsed} ثانية**`,
    campaign.stopped ? 'تم إيقاف الطابور بناءً على الطلب.' : 'سيتم تحديث هذه الرسالة مرة كل ثانية.',
  ].join('\n');
}

async function sendWithRetries(member, content) {
  for (let attempt = 0; attempt <= MAX_RETRIES; attempt += 1) {
    try {
      await member.send({ content, allowedMentions: { users: [member.id] } });
      return { ok: true };
    } catch (error) {
      if (!isTemporaryError(error) || attempt === MAX_RETRIES) {
        return { ok: false, reason: errorReason(error) };
      }
      const retryAfter = Number(error?.retryAfter || 0);
      const waitMs = Math.min(60_000, Math.max(DM_DELAY_MS, retryAfter * 1000 || DM_DELAY_MS * (attempt + 2)));
      await sleep(waitMs);
    }
  }
  return { ok: false, reason: 'انتهت محاولات الإعادة' };
}

async function runCampaign(campaign, progressMessage) {
  const timer = setInterval(async () => {
    try {
      await progressMessage.edit(progressText(campaign));
    } catch {
      // The campaign continues if the progress message can no longer be edited.
    }
  }, 1000);

  try {
    for (const member of campaign.members) {
      if (campaign.stopped) break;
      const content = `${campaign.text}\n\n${member}`;
      const result = await sendWithRetries(member, content);
      if (result.ok) campaign.sent += 1;
      else {
        campaign.failed += 1;
        campaign.failures.push({ userId: member.id, username: member.user.username, reason: result.reason });
      }
      await sleep(DM_DELAY_MS);
    }
  } finally {
    clearInterval(timer);
    campaign.finishedAt = new Date().toISOString();
    await progressMessage.edit(progressText(campaign, true)).catch(() => {});
    await appendLog(campaign).catch((error) => console.error('Could not write campaign log:', error.message));
    activeCampaigns.delete(campaign.guildId);
  }
}

client.once('ready', () => {
  console.log(`Logged in as ${client.user.tag}`);
  console.log(`Prefix: ${PREFIX} | Guild: ${GUILD_ID}`);
});

client.on('messageCreate', async (message) => {
  try {
    if (message.author.bot || !message.guild || message.guild.id !== GUILD_ID) return;
    if (!message.content.startsWith(PREFIX)) return;

    const withoutPrefix = message.content.slice(PREFIX.length).trim();
    const firstSpace = withoutPrefix.indexOf(' ');
    const command = (firstSpace === -1 ? withoutPrefix : withoutPrefix.slice(0, firstSpace)).toLowerCase();
    const text = firstSpace === -1 ? '' : withoutPrefix.slice(firstSpace + 1).trim();

    if (command === 'stop') {
      const campaign = activeCampaigns.get(message.guild.id);
      if (!campaign) {
        await message.reply('لا توجد حملة إرسال قيد التشغيل.');
        return;
      }
      if (!canBroadcast(message)) {
        await message.reply('ليس لديك صلاحية إيقاف الحملات.');
        return;
      }
      campaign.stopped = true;
      await message.reply('تم طلب إيقاف الحملة؛ سيتوقف الطابور بعد إنهاء محاولة DM الحالية.');
      return;
    }

    if (!['abc', 'obc'].includes(command)) return;
    if (!canBroadcast(message)) {
      await message.reply('هذا الأمر متاح لمالك البوت أو لمن لديه صلاحية Manage Server فقط.');
      return;
    }
    if (!text) {
      await message.reply(`استخدم الأمر هكذا: \`${PREFIX}${command} نص الرسالة\``);
      return;
    }
    if (text.length > 1900) {
      await message.reply('الرسالة طويلة جدًا. اجعل نص الإعلان أقل من 1900 حرفًا حتى يبقى المنشن في آخر سطر.');
      return;
    }
    if (activeCampaigns.has(message.guild.id)) {
      await message.reply(`توجد حملة قيد التشغيل. استخدم \`${PREFIX}stop\` أولًا إذا أردت إيقافها.`);
      return;
    }

    const allMembers = await message.guild.members.fetch();
    let members = [...allMembers.values()].filter((member) => !member.user.bot && member.id !== client.user.id);
    if (command === 'obc') {
      members = members.filter((member) => presenceMatches(member, INCLUDE_IDLE_DND));
    }
    if (MAX_RECIPIENTS > 0 && members.length > MAX_RECIPIENTS) {
      await message.reply(`تم رفض الحملة لأن عدد المستلمين ${members.length} يتجاوز الحد المحلي ${MAX_RECIPIENTS}.`);
      return;
    }
    if (members.length === 0) {
      await message.reply('لم يتم العثور على أعضاء قابلين للاستهداف في هذه الحملة.');
      return;
    }

    const campaign = {
      id: `${Date.now()}-${message.author.id}`,
      guildId: message.guild.id,
      type: command,
      authorId: message.author.id,
      text,
      members,
      target: members.length,
      sent: 0,
      failed: 0,
      failures: [],
      stopped: false,
      startedAtMs: Date.now(),
      startedAt: new Date().toISOString(),
      finishedAt: null,
    };
    activeCampaigns.set(message.guild.id, campaign);
    const progressMessage = await message.reply(progressText(campaign));
    await runCampaign(campaign, progressMessage);
  } catch (error) {
    console.error('Command error:', error);
    await message.reply('حدث خطأ أثناء بدء الحملة. راجع سجل التشغيل وتأكد من الصلاحيات والـ intents.').catch(() => {});
  }
});

process.on('unhandledRejection', (error) => console.error('Unhandled rejection:', error));
process.on('uncaughtException', (error) => console.error('Uncaught exception:', error));

client.login(TOKEN);
